package com.ekfc.foodcraft.templates;

import org.apache.commons.io.IOUtils;

import java.io.FileInputStream;
import java.io.IOException;

public class EmailTemplate {

public static String CREDIT_CARD_ON_DELIVERY = "Payment using Credit card on delivery.";
public static String ONLINE_PAYMENT = "Online payment using card.";

public static String ORDER_CANCEL_EMAIL_TEMPLATE = "<!DOCTYPE html>\n"+
"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
"<body style=\"margin: 0px 25%;\" leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +		
"\t<div id=\"x_wrapper\" dir=\"ltr\" style=\"background-color:#ffffff; margin:0; padding:70px 0 70px 0; width:100%; padding-top:0px; padding-bottom:0px\">\n" +
"\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" height=\"100%\" width=\"100%\">\n" +
"\t\t\t<tbody>\n" +
"\t\t\t\t<tr>\n" +
"\t\t\t\t\t<td align=\"center\" valign=\"top\">\n" +
"\t\t\t\t\t\t<table id=\"x_template_header_image_container\" style=\"width:100%; background-color:#ffffff\">\n" +
"\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t<tr id=\"x_template_header_image\">\n" +
"\t\t\t\t\t\t\t\t\t<td align=\"center\" valign=\"middle\">\n" +
"\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"x_template_header_image_table\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"center\" valign=\"middle\" style=\"text-align:center; padding-top:0px; padding-bottom:0px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"text-align:center;margin-bottom:0; margin-top:0\"><a href=\"##domainName##\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" style=\"font-weight:normal; color:#000000; display:block; text-decoration:none\" data-linkindex=\"0\"><img data-imagetype=\"External\" src=\"##foodCraftLogo##\" alt=\"Foodcraft\" width=\"193\" style=\"border:none; display:inline; font-weight:bold; height:auto; outline:none; text-decoration:none; text-transform:capitalize; font-size:14px; line-height:24px; max-width:100%; width:193px\"></a></p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"590\" id=\"x_template_container\" style=\"margin:0 25%; background-color:#ffffff; overflow:hidden; border-style:solid; border-color:#000000; border-radius:0px; border-top:0px solid #ffffff; border-right:0px solid #ffffff; border-bottom:0px solid #ffffff; border-left:0px solid #ffffff\">\n" +
"\t\t\t\t\t\t\t<tbody>\n" +
		/*
		 * "\t\t\t\t\t\t\t\t<tr>\n" +
		 * "\t\t\t\t\t\t\t\t\t<td align=\"center\" valign=\"top\">\n" +
		 * "\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"x_template_header\" style=\"border-bottom:0; font-weight:bold; line-height:100%; vertical-align:middle; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; background-color:#ffffff; color:#1ad656\">\n"
		 * + "\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" + "\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
		 * "\t\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"x_header_wrapper\" style=\"padding:36px 48px; display:block; text-align:left; padding-top:10px; padding-bottom:0px; padding-left:48px; padding-right:48px\">\n"
		 * +
		 * "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h1 style=\"margin:0; text-align:left; font-size:30px; line-height:53px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-style:normal; font-weight:200; color:#1ad656\">\n"
		 * + "\t\t\t\t\t\t\t\t\t\t\t\t\t\tOrder Cancelled: ###orderNumber##</h1>\n" +
		 * "\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" + "\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
		 * "\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" + "\t\t\t\t\t\t\t\t\t\t</table>\n" +
		 * "\t\t\t\t\t\t\t\t\t</td>\n" + "\t\t\t\t\t\t\t\t</tr>\n" +
		 */
"\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t<td align=\"center\" valign=\"top\">\n" +
"\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"590\" id=\"x_template_body\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" id=\"x_body_content\" style=\"background-color:#ffffff; padding-top:8px; padding-bottom:0px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"20\" cellspacing=\"0\" width=\"100%\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" style=\"padding:0px 48px 0; padding-left:48px; padding-right:48px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"x_body_content_inner\" style=\"color: rgb(99, 99, 99); text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif, serif, EmojiFont; font-weight: 400;\">\n" +
//"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\">Order Cancellation</p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\">The order ##orderNumber## from <strong>##firstName## ##lastName## </strong>has been cancelled. The order was as follows:</p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div style=\"clear:both; height:1px\"></div>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 style=\"display:block; margin:0 0 18px; text-align:left; font-size:18px; line-height:26px; padding-top:0px; padding-bottom:0px; margin-top:0px; margin-bottom:18px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-weight:700; text-transform:none; color:#000000\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tOrder ###orderNumber## (##deliveryDate##) </h2>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"x_email-spacing-wrap\" style=\"margin-bottom:40px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table class=\"x_td\" cellspacing=\"0\" cellpadding=\"6\" width=\"100%\" border=\"1\" style=\"color:#636363; border:0; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; border-top-width:1px; border-top-style:solid; width:100%; padding-left:0; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<thead>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td\" scope=\"col\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tProduct</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td\" scope=\"col\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; text-align:center\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tQuantity</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td\" scope=\"col\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tPrice</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</thead>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>##orderItems##</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tfoot>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-subtotal\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tSubtotal:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-subtotal\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_woocommerce-Price-amount x_amount\"><span class=\"x_woocommerce-Price-currencySymbol\">AED\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>##subTotal##</span></td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-discount\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tDiscount:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-discount\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t-<span class=\"x_woocommerce-Price-amount x_amount\"><span class=\"x_woocommerce-Price-currencySymbol\">AED\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>##discount##</span> </td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-shipping\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tShipping:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-shipping\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t##shippingCharges##</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-cashondelivery\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tCash on delivery:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-cashondelivery\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_woocommerce-Price-amount x_amount\"><span class=\"x_woocommerce-Price-currencySymbol\">AED\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>##cashOnDelivery##</span></td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-paymentmethod\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tPayment method:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-paymentmethod\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t##paymentMode##</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-total\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTotal:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-total\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_woocommerce-Price-amount x_amount\"><span class=\"x_woocommerce-Price-currencySymbol\">AED\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>##total##</span> <small class=\"x_includes_tax\">(includes <span class=\"x_woocommerce-Price-amount x_amount\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_woocommerce-Price-currencySymbol\">AED </span>##vat##</span> VAT)</small>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-deliverydate\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tDelivery Date:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-deliverydate\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t##deliveryDate##</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<th class=\"x_td x_tlabel-timeslot\" scope=\"row\" colspan=\"2\" style=\"color:#636363; font-weight:bold; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-left:0; text-align:left\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tTime Slot:</th>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_td x_tvalue-timeslot\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; padding-right:0; text-align:right\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t##timeSlot##</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tfoot>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n" +
//"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\"><strong>Street Name and Number:</strong> ##deliveryAddress##</p>\n" +
//"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\"><strong>Landmark:</strong> ##landmark##</p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table id=\"x_addresses\" cellspacing=\"0\" cellpadding=\"0\" border=\"0\" style=\"border-collapse:collapse; width:100%; vertical-align:top; margin-bottom:40px; padding:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_address-container\" valign=\"top\" width=\"50%\" style=\"text-align:left; padding:0; border:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 style=\"display:block; margin:0 0 18px; text-align:left; font-size:18px; line-height:26px; padding-top:0px; padding-bottom:0px; margin-top:0px; margin-bottom:18px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-weight:700; text-transform:none; color:#000000\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tBilling address</h2>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<address class=\"x_address\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" style=\"width:100%; padding:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_address-td\" valign=\"top\" style=\"border:1px solid #e5e5e5; padding:0px; border-width:0px; border-color:#ffffff; border-style:solid; color:#8f8f8f; text-align:left\">##firstName## ##lastName## ##billingAddress##\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</address>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_shipping-address-container\" valign=\"top\" width=\"50%\" style=\"text-align:left; padding:0 0 0 20px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h2 style=\"display:block; margin:0 0 18px; text-align:left; font-size:18px; line-height:26px; padding-top:0px; padding-bottom:0px; margin-top:0px; margin-bottom:18px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-weight:700; text-transform:none; color:#000000\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tShipping address</h2>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<address class=\"x_address\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\" style=\"width:100%; padding:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class=\"x_address-td\" valign=\"top\" style=\"border:1px solid #e5e5e5; padding:0px; border-width:0px; border-color:#ffffff; border-style:solid; color:#8f8f8f; text-align:left\">##firstName## ##lastName## ##shippingAddress##</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</address>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\">Please rate your experience using the link: <a href=\"https://protect-eu.mimecast.com/s/ypMvCVQ1osxAzv8UzIMT-?domain=research.net\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" data-linkindex=\"3\">\n" +
//"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\thttps://www.research.net/r/N3LLD33</a></p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"margin:0 0 16px\">Do follow us on social media to stay updated about our new products and offers:</p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t<td align=\"center\" valign=\"top\"></td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" id=\"x_template_footer_container\">\n" +
"\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" align=\"center\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"10\" cellspacing=\"0\" width=\"590\" id=\"x_template_footer\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" id=\"x_template_footer_inside\" style=\"padding:0; padding-top:48px; padding-bottom:48px; padding-left:150px; padding-right:150px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"10\" cellspacing=\"0\" width=\"100%\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" style=\"padding:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table id=\"x_footersocial\" border=\"0\" cellpadding=\"10\" cellspacing=\"0\" width=\"100%\" style=\"border-bottom-width:0px; border-bottom-color:#ffffff; border-bottom-style:solid\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"middle\" style=\"padding:0; padding-top:0px; padding-bottom:0px; text-align:center; width:50%\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"https://protect-eu.mimecast.com/s/S0FGCWq2pf5BNk8FKw6vN?domain=facebook.com\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" class=\"x_ft-social-link\" style=\"font-weight:normal; color:#1ad656; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; display:block; text-decoration:none\" data-linkindex=\"4\"><img data-imagetype=\"External\" src=\"https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png\" alt=\"facebook\" width=\"24\" style=\"border:none; font-weight:bold; height:auto; outline:none; text-decoration:none; text-transform:capitalize; font-size:14px; line-height:24px; width:24px; max-width:100%; display:inline-block; vertical-align:bottom\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_ft-social-title\" style=\"line-height:24px; padding-left:5px; font-size:px; font-weight:400\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span></a></td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"middle\" style=\"padding:0; padding-top:0px; padding-bottom:0px; text-align:center; width:50%\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"https://protect-eu.mimecast.com/s/ldBNCX53qIXYkJZTkZ0YG?domain=instagram.com\" target=\"_blank\" rel=\"noopener noreferrer\" data-auth=\"NotApplicable\" class=\"x_ft-social-link\" style=\"font-weight:normal; color:#1ad656; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; display:block; text-decoration:none\" data-linkindex=\"5\"><img data-imagetype=\"External\" src=\"https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png\" alt=\"instagram\" width=\"24\" style=\"border:none; font-weight:bold; height:auto; outline:none; text-decoration:none; text-transform:capitalize; font-size:14px; line-height:24px; width:24px; max-width:100%; display:inline-block; vertical-align:bottom\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"x_ft-social-title\" style=\"line-height:24px; padding-left:5px; font-size:px; font-weight:400\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span></a></td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td valign=\"top\" style=\"padding:0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table border=\"0\" cellpadding=\"10\" cellspacing=\"0\" width=\"100%\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td colspan=\"2\" valign=\"middle\" id=\"x_credit\" style=\"padding:0; border:0; line-height:125%; padding-left:0px; padding-right:0px; text-align:center; font-size:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; font-weight:400; color:#555555; padding-top:32px; padding-bottom:0px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p style=\"color:#555555\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t<table class=\"x_gmail-app-fix\" width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" align=\"center\" width=\"590\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td cellpadding=\"0\" cellspacing=\"0\" border=\"0\" height=\"1\" style=\"line-height:1px; min-width:196px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td cellpadding=\"0\" cellspacing=\"0\" border=\"0\" height=\"1\" style=\"line-height:1px; min-width:196px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td cellpadding=\"0\" cellspacing=\"0\" border=\"0\" height=\"1\" style=\"line-height:1px; min-width:196px\">\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t\t\t\t\t</td>\n" +
"\t\t\t\t\t\t\t\t\t\t\t</tr>\n" +
"\t\t\t\t\t\t\t\t\t\t</tbody>\n" +
"\t\t\t\t\t\t\t\t\t</table>\n" +
"\t\t\t\t\t\t\t\t</div>\n" +
"\t\t\t\t\t\t\t\t<img data-imagetype=\"External\" src=\"http://tracking.managedcloudhostingemail.com/tracking/open?msgid=wcCqlQU_Hme40MQYL-TMmg2&amp;c=1331129097727995288\" alt=\"\" style=\"width:1px; height:1px\">\n" +
"\t\t\t\t\t\t\t\t<img data-imagetype=\"External\" src=\"https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNTgxOCZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9NGVlN2JhNDE5YjE2MWFlMzk0MjQ3MGM3MjNkYWVlMjJhYzgyZjhiNWM3Y2M1NjBjZTk1NjMwY2Q2MTliNDgzNg==\" alt=\"\">\n" +
"\t\t\t\t\t\t\t</div>"+
"</body>\n" +
"</html>";

public static String ORDER_COMPLETION_EMAIL_TEMPLATE = "<!DOCTYPE html>\n" +
		"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
		"   <head>\n" +
		"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
		"      <title>Foodcraft</title>\n" +
		"   </head>\n" +
		"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
		"      <p></p>\n" +
		"      <br>\n" +
		"      <p></p>\n" +
		"      <div>\n" +
		"         <div id=wrapper dir=ltr style=\"background-color: #ffffff; margin: 0; padding: 70px 0 70px 0; width: 100%; padding-top: 0px; padding-bottom: 0px; -webkit-text-size-adjust: none;\">\n" +
		"            <table border=0 cellpadding=0 cellspacing=0 height=100% width=100%>\n" +
		"               <tbody>\n" +
		"                  <tr>\n" +
		"                     <td align=center valign=top>\n" +
		"                        <table id=template_header_image_container style=\"width: 100%; background-color: #ffffff;\">\n" +
		"                           <tbody>\n" +
		"                              <tr id=template_header_image>\n" +
		"                                 <td align=center valign=middle>\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header_image_table>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td align=center valign=middle style=\"text-align: center; padding-top: 0px; padding-bottom: 0px;\">\n" +
		"                                                <p style=\"margin-bottom: 0; margin-top: 0;\"><a href=https://protect-eu.mimecast.com/s/jkOiCk7zBInkA8Mt2v76D?domain=foodcraft.ae target=_blank style=\"font-weight: normal; color: #000000; display: block; text-decoration: none;\"><img src=\"##foodCraftLogo##\" alt=Foodcraft width=193 style=\"border: none; display: inline; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; max-width: 100%; width: 193px;\"></a></p>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_container style=\"background-color: #ffffff; overflow: hidden; border-style: solid; border-color: #000000; border-radius: 0px; border-top: 0px solid #ffffff; border-right: 0px solid #ffffff; border-bottom: 0px solid #ffffff; border-left: 0px solid #ffffff; box-shadow: 0 0px 0px 0px rgba(0,0,0,0.1);\">\n" +
		"                           <tbody>\n" +
		/*
		 * "                              <tr>\n" +
		 * "                                 <td align=center valign=top>\n" +
		 * "                                    <!-- Header -->\n" +
		 * "                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header style=\"border-bottom: 0; font-weight: bold; line-height: 100%; vertical-align: middle; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; background-color: #ffffff; color: #1ad656;\">\n"
		 * + "                                       <tbody>\n" +
		 * "                                          <tr>\n" +
		 * "                                             <td id=header_wrapper style=\"padding: 36px 48px; display: block; text-align: left; padding-top: 10px; padding-bottom: 0px; padding-left: 48px; padding-right: 48px;\">\n"
		 * +
		 * "                                                <h1 style=\"margin: 0; text-align: left; font-size: 30px; line-height: 53px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-style: normal; font-weight: 200; color: #1ad656;\">Password Changed</h1>\n"
		 * + "                                             </td>\n" +
		 * "                                          </tr>\n" +
		 * "                                       </tbody>\n" +
		 * "                                    </table>\n" +
		 * "                                    <!-- End Header -->\n" +
		 * "                                 </td>\n" +
		 * "                              </tr>\n" +
		 */
		"                              <tr>\n" +
		"                                 <td align=center valign=top>\n" +
		"                                    <!-- Body -->\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_body>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=body_content style=\"background-color: #ffffff; padding-top: 8px; padding-bottom: 0px;\">\n" +
		"                                                <!-- Content -->\n" +
		"                                                <table border=0 cellpadding=20 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0px 48px 0; padding-left: 48px; padding-right: 48px;\">\n" +
		"                                                            <div id=body_content_inner style=\"color: #636363; text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400;\">\n" +
		//"                                                               <p style=\"margin: 0 0 16px;\">Thank you for shopping with us!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Hi ##firstName##,</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Hope you enjoy our products, and shop with us again. Don't forget to follow us on social media to stay updated on our latest offers and promotions!</p>\n" +
		//"                                                               <p style=\"margin: 0 0 16px;\">Remember to follow us on social media @foodcraftuae to stay updated on our latest offers and promotions!</p>\n" +
		//"                                                               <p style=\"margin: 0 0 16px;\">We look forward to delivering to you again soon.</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Sahtain!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">The Foodcraft Team</p>\n" +
		"                                                            </div>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                                <!-- End Content -->\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                    <!-- End Body -->\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top></td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <!-- End template container -->\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_footer_container>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td valign=top align=center>\n" +
		"                                    <table border=0 cellpadding=10 cellspacing=0 width=590 id=template_footer>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=template_footer_inside style=\"padding: 0; padding-top: 48px; padding-bottom: 48px; padding-left: 150px; padding-right: 150px;\">\n" +
		"                                                <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table id=footersocial border=0 cellpadding=10 cellspacing=0 width=100% style=\"border-bottom-width: 0px; border-bottom-color: #ffffff; border-bottom-style: solid;\">\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/McuUCmyB8h5p8BmCB_gcH?domain=facebook.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=facebook src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/QqajCnOD7fGXgAJCZ25nA?domain=instagram.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=instagram src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td colspan=2 valign=middle id=credit style=\"padding: 0; border: 0; line-height: 125%; padding-left: 0px; padding-right: 0px; text-align: center; font-size: 12px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400; color: #555555; padding-top: 32px; padding-bottom: 0px;\">\n" +
		"                                                                        <p style=\"color: #555555;\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
		"                                                                     </td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table class=gmail-app-fix width=100% border=0 cellpadding=0 cellspacing=0>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td>\n" +
		"                                    <table cellpadding=0 cellspacing=0 border=0 align=center width=590>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                     </td>\n" +
		"                  </tr>\n" +
		"               </tbody>\n" +
		"            </table>\n" +
		"         </div>\n" +
		"         <img src=http://tracking.managedcloudhostingemail.com/tracking/open?msgid=L4QiHHCMKVsrHqA3JB6AVg2&amp;c=1331129097727995288 style=width:1px;height:1px alt> <img src=https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNzY3MSZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9OGRlNDg5ZWYxOWU5OWJmMGFhM2NiMmE2ZGVjMjljM2UxZWE3YWQ5N2JhZTEzM2M2NWNmZDJhZjQ2ZDFhZTAzYQ== alt>\n" +
		"      </div>\n" +
		"   </body>\n" +
		"</html>";


	public static String ORDER_DELIVERED_EMAIL_TEMPLATE = "<!DOCTYPE html>\n" +
			"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
			"   <head>\n" +
			"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
			"      <title>Foodcraft</title>\n" +
			"   </head>\n" +
			"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
			"      <p></p>\n" +
			"      <br>\n" +
			"      <p></p>\n" +
			"      <div>\n" +
			"         <div id=\"x_wrapper\" dir=\"ltr\" style=\"width: 100%; background-color: #ffffff;\">\n" +
			"            <table border=0 cellpadding=0 cellspacing=0 height=100% width=100%>\n" +
			"               <tbody>\n" +
			"                  <tr>\n" +
			"                     <td align=center valign=top>\n" +
			"                        <table id=template_header_image_container style=\"width: 100%; background-color: #ffffff;\">\n" +
			"                           <tbody>\n" +
			"                              <tr id=template_header_image>\n" +
			"                                 <td align=center valign=middle>\n" +
			"                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header_image_table>\n" +
			"                                       <tbody>\n" +
			"                                          <tr>\n" +
			"                                             <td align=center valign=middle style=\"text-align: center; padding-top: 0px; padding-bottom: 0px;\">\n" +
			"                                                <p style=\"margin-bottom: 0; margin-top: 0;\"><a href=\"https://protect-eu.mimecast.com/s/jkOiCk7zBInkA8Mt2v76D?domain=foodcraft.ae\" target=\"_blank\" style=\"font-weight: normal; color: #000000; display: block; text-decoration: none;\"><img src=\"##foodCraftLogo##\" alt=Foodcraft width=193 style=\"border: none; display: inline; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; max-width: 100%; width: 193px;\"></a></p>\n" +
			"                                             </td>\n" +
			"                                          </tr>\n" +
			"                                       </tbody>\n" +
			"                                    </table>\n" +
			"                                 </td>\n" +
			"                              </tr>\n" +
			"                           </tbody>\n" +
			"                        </table>\n" +
			"                        <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_container style=\"background-color: #ffffff; overflow: hidden; border-style: solid; border-color: #000000; border-radius: 0px; border-top: 0px solid #ffffff; border-right: 0px solid #ffffff; border-bottom: 0px solid #ffffff; border-left: 0px solid #ffffff; box-shadow: 0 0px 0px 0px rgba(0,0,0,0.1);\">\n" +
			"                           <tbody>\n" +
			"                              <tr>\n" +
			"                                 <td align=center valign=top>\n" +
			"                                    <!-- Body -->\n" +
			"                                    <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_body>\n" +
			"                                       <tbody>\n" +
			"                                          <tr>\n" +
			"                                             <td valign=top id=body_content style=\"background-color: #ffffff; padding-top: 8px; padding-bottom: 0px;\">\n" +
			"                                                <!-- Content -->\n" +
			"                                                <table border=0 cellpadding=20 cellspacing=0 width=100%>\n" +
			"                                                   <tbody>\n" +
			"                                                      <tr>\n" +
			"                                                         <td valign=top style=\"padding: 0px 48px 0; padding-left: 48px; padding-right: 48px;\">\n" +
			"                                                            <div id=body_content_inner style=\"color: #636363; text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400;\">\n" +
			"                                                               <p style=\"margin: 0 0 16px;\">Hi ##firstName##,</p>\n" +
			"                                                               <h1 style=\"margin: 0 0 16px;\">Your order (##orderNumber##) has been delivered.</h1>\n" +
			"                                                               <p style=\"margin: 0 0 16px;\">Hope you enjoy our products, and shop with us again. Don't forget to follow us on social media to stay updated on our latest offers and promotions!</p>\n" +
			"                                                               <p style=\"margin: 0 0 16px;\">Sahtain!</p>\n" +
			"                                                               <p style=\"margin: 0 0 16px;\">The Foodcraft Team</p>\n" +
			"                                                            </div>\n" +
			"                                                         </td>\n" +
			"                                                      </tr>\n" +
			"                                                   </tbody>\n" +
			"                                                </table>\n" +
			"                                                <!-- End Content -->\n" +
			"                                             </td>\n" +
			"                                          </tr>\n" +
			"                                       </tbody>\n" +
			"                                    </table>\n" +
			"                                    <!-- End Body -->\n" +
			"                                 </td>\n" +
			"                              </tr>\n" +
			"                              <tr>\n" +
			"                                 <td align=center valign=top></td>\n" +
			"                              </tr>\n" +
			"                           </tbody>\n" +
			"                        </table>\n" +
			"                        <!-- End template container -->\n" +
			"                        <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_footer_container>\n" +
			"                           <tbody>\n" +
			"                              <tr>\n" +
			"                                 <td valign=top align=center>\n" +
			"                                    <table border=0 cellpadding=10 cellspacing=0 width=590 id=template_footer>\n" +
			"                                       <tbody>\n" +
			"                                          <tr>\n" +
			"                                             <td valign=top id=template_footer_inside style=\"padding: 0; padding-top: 48px; padding-bottom: 48px; padding-left: 150px; padding-right: 150px;\">\n" +
			"                                                <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
			"                                                   <tbody>\n" +
			"                                                      <tr>\n" +
			"                                                         <td valign=top style=\"padding: 0;\">\n" +
			"                                                            <table id=footersocial border=0 cellpadding=10 cellspacing=0 width=100% style=\"border-bottom-width: 0px; border-bottom-color: #ffffff; border-bottom-style: solid;\">\n" +
			"                                                               <tbody>\n" +
			"                                                                  <tr>\n" +
//			"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/McuUCmyB8h5p8BmCB_gcH?domain=facebook.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=facebook src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
//			"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/QqajCnOD7fGXgAJCZ25nA?domain=instagram.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=instagram src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
			"                                                                  </tr>\n" +
			"                                                               </tbody>\n" +
			"                                                            </table>\n" +
			"                                                         </td>\n" +
			"                                                      </tr>\n" +
			"                                                      <tr>\n" +
			"                                                         <td valign=top style=\"padding: 0;\">\n" +
			"                                                            <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
			"                                                               <tbody>\n" +
			"                                                                  <tr>\n" +
			"                                                                     <td colspan=2 valign=middle id=credit style=\"padding: 0; border: 0; line-height: 125%; padding-left: 0px; padding-right: 0px; text-align: center; font-size: 12px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400; color: #555555; padding-top: 32px; padding-bottom: 0px;\">\n" +
			"                                                                        <p style=\"color: #555555;\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
			"                                                                     </td>\n" +
			"                                                                  </tr>\n" +
			"                                                               </tbody>\n" +
			"                                                            </table>\n" +
			"                                                         </td>\n" +
			"                                                      </tr>\n" +
			"                                                   </tbody>\n" +
			"                                                </table>\n" +
			"                                             </td>\n" +
			"                                          </tr>\n" +
			"                                       </tbody>\n" +
			"                                    </table>\n" +
			"                                 </td>\n" +
			"                              </tr>\n" +
			"                           </tbody>\n" +
			"                        </table>\n" +
			"                        <table class=gmail-app-fix width=100% border=0 cellpadding=0 cellspacing=0>\n" +
			"                           <tbody>\n" +
			"                              <tr>\n" +
			"                                 <td>\n" +
			"                                    <table cellpadding=0 cellspacing=0 border=0 align=center width=590>\n" +
			"                                       <tbody>\n" +
			"                                          <tr>\n" +
			"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
			"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
			"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
			"                                          </tr>\n" +
			"                                       </tbody>\n" +
			"                                    </table>\n" +
			"                                 </td>\n" +
			"                              </tr>\n" +
			"                           </tbody>\n" +
			"                        </table>\n" +
			"                     </td>\n" +
			"                  </tr>\n" +
			"               </tbody>\n" +
			"            </table>\n" +
			"         </div>\n" +
//			"         <img src=http://tracking.managedcloudhostingemail.com/tracking/open?msgid=L4QiHHCMKVsrHqA3JB6AVg2&amp;c=1331129097727995288 style=width:1px;height:1px alt> <img src=https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNzY3MSZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9OGRlNDg5ZWYxOWU5OWJmMGFhM2NiMmE2ZGVjMjljM2UxZWE3YWQ5N2JhZTEzM2M2NWNmZDJhZjQ2ZDFhZTAzYQ== alt>\n" +
			"      </div>\n" +
			"   </body>\n" +
			"</html>";

public static String ORDER_REFUND_EMAIL_TEMPLATE = "<!DOCTYPE html>\n" +
		"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
		"   <head>\n" +
		"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
		"      <title>Foodcraft</title>\n" +
		"   </head>\n" +
		"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
		"      <p></p>\n" +
		"      <br>\n" +
		"      <p></p>\n" +
		"      <div>\n" +
		"         <div id=wrapper dir=ltr style=\"background-color: #ffffff; margin: 0; padding: 70px 0 70px 0; width: 100%; padding-top: 0px; padding-bottom: 0px; -webkit-text-size-adjust: none;\">\n" +
		"            <table border=0 cellpadding=0 cellspacing=0 height=100% width=100%>\n" +
		"               <tbody>\n" +
		"                  <tr>\n" +
		"                     <td align=center valign=top>\n" +
		"                        <table id=template_header_image_container style=\"width: 100%; background-color: #ffffff;\">\n" +
		"                           <tbody>\n" +
		"                              <tr id=template_header_image>\n" +
		"                                 <td align=center valign=middle>\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header_image_table>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td align=center valign=middle style=\"text-align: center; padding-top: 0px; padding-bottom: 0px;\">\n" +
		"                                                <p style=\"margin-bottom: 0; margin-top: 0;\"><a href=https://protect-eu.mimecast.com/s/jkOiCk7zBInkA8Mt2v76D?domain=foodcraft.ae target=_blank style=\"font-weight: normal; color: #000000; display: block; text-decoration: none;\"><img src=\"##foodCraftLogo##\" alt=Foodcraft width=193 style=\"border: none; display: inline; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; max-width: 100%; width: 193px;\"></a></p>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_container style=\"background-color: #ffffff; overflow: hidden; border-style: solid; border-color: #000000; border-radius: 0px; border-top: 0px solid #ffffff; border-right: 0px solid #ffffff; border-bottom: 0px solid #ffffff; border-left: 0px solid #ffffff; box-shadow: 0 0px 0px 0px rgba(0,0,0,0.1);\">\n" +
		"                           <tbody>\n" +
		/*
		 * "                              <tr>\n" +
		 * "                                 <td align=center valign=top>\n" +
		 * "                                    <!-- Header -->\n" +
		 * "                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header style=\"border-bottom: 0; font-weight: bold; line-height: 100%; vertical-align: middle; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; background-color: #ffffff; color: #1ad656;\">\n"
		 * + "                                       <tbody>\n" +
		 * "                                          <tr>\n" +
		 * "                                             <td id=header_wrapper style=\"padding: 36px 48px; display: block; text-align: left; padding-top: 10px; padding-bottom: 0px; padding-left: 48px; padding-right: 48px;\">\n"
		 * +
		 * "                                                <h1 style=\"margin: 0; text-align: left; font-size: 30px; line-height: 53px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-style: normal; font-weight: 200; color: #1ad656;\">Password Changed</h1>\n"
		 * + "                                             </td>\n" +
		 * "                                          </tr>\n" +
		 * "                                       </tbody>\n" +
		 * "                                    </table>\n" +
		 * "                                    <!-- End Header -->\n" +
		 * "                                 </td>\n" +
		 * "                              </tr>\n" +
		 */
		"                              <tr>\n" +
		"                                 <td align=center valign=top>\n" +
		"                                    <!-- Body -->\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_body>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=body_content style=\"background-color: #ffffff; padding-top: 8px; padding-bottom: 0px;\">\n" +
		"                                                <!-- Content -->\n" +
		"                                                <table border=0 cellpadding=20 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0px 48px 0; padding-left: 48px; padding-right: 48px;\">\n" +
		"                                                            <div id=body_content_inner style=\"color: #636363; text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400;\">\n" +
		//"                                                               <p style=\"margin: 0 0 16px;\">Order Refunded: ###orderNumber##</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Hi ##firstName##,</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Your refund has been processed, and you should expect to see the amount appear in your bank account in the next couple of business days.</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">We hope to see you soon!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Sahtain!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">The Foodcraft Team</p>\n" +
		"                                                            </div>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                                <!-- End Content -->\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                    <!-- End Body -->\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top></td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <!-- End template container -->\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_footer_container>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td valign=top align=center>\n" +
		"                                    <table border=0 cellpadding=10 cellspacing=0 width=590 id=template_footer>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=template_footer_inside style=\"padding: 0; padding-top: 48px; padding-bottom: 48px; padding-left: 150px; padding-right: 150px;\">\n" +
		"                                                <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table id=footersocial border=0 cellpadding=10 cellspacing=0 width=100% style=\"border-bottom-width: 0px; border-bottom-color: #ffffff; border-bottom-style: solid;\">\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/McuUCmyB8h5p8BmCB_gcH?domain=facebook.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=facebook src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/QqajCnOD7fGXgAJCZ25nA?domain=instagram.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=instagram src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td colspan=2 valign=middle id=credit style=\"padding: 0; border: 0; line-height: 125%; padding-left: 0px; padding-right: 0px; text-align: center; font-size: 12px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400; color: #555555; padding-top: 32px; padding-bottom: 0px;\">\n" +
		"                                                                        <p style=\"color: #555555;\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
		"                                                                     </td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table class=gmail-app-fix width=100% border=0 cellpadding=0 cellspacing=0>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td>\n" +
		"                                    <table cellpadding=0 cellspacing=0 border=0 align=center width=590>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                     </td>\n" +
		"                  </tr>\n" +
		"               </tbody>\n" +
		"            </table>\n" +
		"         </div>\n" +
		"         <img src=http://tracking.managedcloudhostingemail.com/tracking/open?msgid=L4QiHHCMKVsrHqA3JB6AVg2&amp;c=1331129097727995288 style=width:1px;height:1px alt> <img src=https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNzY3MSZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9OGRlNDg5ZWYxOWU5OWJmMGFhM2NiMmE2ZGVjMjljM2UxZWE3YWQ5N2JhZTEzM2M2NWNmZDJhZjQ2ZDFhZTAzYQ== alt>\n" +
		"      </div>\n" +
		"   </body>\n" +
		"</html>";


public static String ERP_ERROR_EMAIL = "<!DOCTYPE html>\n" +
		"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
		"   <head>\n" +
		"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
		"      <title>Foodcraft</title>\n" +
		"   </head>\n" +
		"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
			"<p>ERP Request : ##ERPRequest##</p>"
		+ "<p>ERP Response : ##ERPResponse##</p>"
		+ "</div>\n"
		+ " </body>\n"
		+ "	</html>";


public static String TICKET_STATUS_EMAIL_TEMPLATE = "<!DOCTYPE html>\n" +
		"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
		"   <head>\n" +
		"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
		"      <title>Foodcraft</title>\n" +
		"   </head>\n" +
		"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
		"      <p></p>\n" +
		"      <br>\n" +
		"      <p></p>\n" +
		"      <div>\n" +
		"         <div id=\"x_wrapper\" dir=\"ltr\" style=\"width: 100%; background-color: #ffffff;\">\n" +
		"            <table border=0 cellpadding=0 cellspacing=0 height=100% width=100%>\n" +
		"               <tbody>\n" +
		"                  <tr>\n" +
		"                     <td align=center valign=top>\n" +
		"                        <table id=template_header_image_container style=\"width: 100%; background-color: #ffffff;\">\n" +
		"                           <tbody>\n" +
		"                              <tr id=template_header_image>\n" +
		"                                 <td align=center valign=middle>\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header_image_table>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td align=center valign=middle style=\"text-align: center; padding-top: 0px; padding-bottom: 0px;\">\n" +
		"                                                <p style=\"margin-bottom: 0; margin-top: 0;\"><a href=\"https://protect-eu.mimecast.com/s/jkOiCk7zBInkA8Mt2v76D?domain=foodcraft.ae\" target=\"_blank\" style=\"font-weight: normal; color: #000000; display: block; text-decoration: none;\"><img src=\"##foodCraftLogo##\" alt=Foodcraft width=193 style=\"border: none; display: inline; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; max-width: 100%; width: 193px;\"></a></p>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_container style=\"background-color: #ffffff; overflow: hidden; border-style: solid; border-color: #000000; border-radius: 0px; border-top: 0px solid #ffffff; border-right: 0px solid #ffffff; border-bottom: 0px solid #ffffff; border-left: 0px solid #ffffff; box-shadow: 0 0px 0px 0px rgba(0,0,0,0.1);\">\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top>\n" +
		"                                    <!-- Body -->\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_body>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=body_content style=\"background-color: #ffffff; padding-top: 8px; padding-bottom: 0px;\">\n" +
		"                                                <!-- Content -->\n" +
		"                                                <table border=0 cellpadding=20 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0px 48px 0; padding-left: 48px; padding-right: 48px;\">\n" +
		"                                                            <div id=body_content_inner style=\"color: #636363; text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400;\">\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Hi ##custEmail##,</p>\n" +
		"                                                               <h1 style=\"margin: 0 0 16px;\">Thank you for contacting FoodCraft customer support</h1>\n"+
		"																<p style=\"margin: 0 0 16px;\">This message is to inform you that we have resolved and closed your support ticket <span style=\"font-weight:bold\">##ticketNumber##</span></p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Please email us if you have any more questions, concerns, or issues.</p>\n"+
		" 																<p style=\"margin: 0 0 16px;\">Don't forget to follow us on social media to stay updated on our latest offers and promotions!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">Sahtain!</p>\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">The Foodcraft Team</p>\n" +
		"                                                            </div>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                                <!-- End Content -->\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                    <!-- End Body -->\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top></td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <!-- End template container -->\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_footer_container>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td valign=top align=center>\n" +
		"                                    <table border=0 cellpadding=10 cellspacing=0 width=590 id=template_footer>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=template_footer_inside style=\"padding: 0; padding-top: 48px; padding-bottom: 48px; padding-left: 150px; padding-right: 150px;\">\n" +
		"                                                <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table id=footersocial border=0 cellpadding=10 cellspacing=0 width=100% style=\"border-bottom-width: 0px; border-bottom-color: #ffffff; border-bottom-style: solid;\">\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
//		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/McuUCmyB8h5p8BmCB_gcH?domain=facebook.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=facebook src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
//		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/QqajCnOD7fGXgAJCZ25nA?domain=instagram.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=instagram src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td colspan=2 valign=middle id=credit style=\"padding: 0; border: 0; line-height: 125%; padding-left: 0px; padding-right: 0px; text-align: center; font-size: 12px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400; color: #555555; padding-top: 32px; padding-bottom: 0px;\">\n" +
		"                                                                        <p style=\"color: #555555;\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
		"                                                                     </td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table class=gmail-app-fix width=100% border=0 cellpadding=0 cellspacing=0>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td>\n" +
		"                                    <table cellpadding=0 cellspacing=0 border=0 align=center width=590>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                     </td>\n" +
		"                  </tr>\n" +
		"               </tbody>\n" +
		"            </table>\n" +
		"         </div>\n" +
//		"         <img src=http://tracking.managedcloudhostingemail.com/tracking/open?msgid=L4QiHHCMKVsrHqA3JB6AVg2&amp;c=1331129097727995288 style=width:1px;height:1px alt> <img src=https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNzY3MSZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9OGRlNDg5ZWYxOWU5OWJmMGFhM2NiMmE2ZGVjMjljM2UxZWE3YWQ5N2JhZTEzM2M2NWNmZDJhZjQ2ZDFhZTAzYQ== alt>\n" +
		"      </div>\n" +
		"   </body>\n" +
		"</html>";



public static String TICKET_STATUS_STACKHOLDER_EMAIL_TEMPLATE = "<!DOCTYPE html>\n" +
		"<html lang=en-US data-woostify-version=2.1.1 data-woostify-pro-version=1.6.9 style=\"height: 100%; position: relative;\">\n" +
		"   <head>\n" +
		"      <meta http-equiv=Content-Type content=\"text/html; charset=utf-8\">\n" +
		"      <title>Foodcraft</title>\n" +
		"   </head>\n" +
		"   <body leftmargin=0 marginwidth=0 topmargin=0 marginheight=0 offset=0 class=\"kt-woo-wrap order-items-light k-responsive-normal title-style-none email-id-cancelled_order\" style=\"height: 100%; position: relative; background-color: #ffffff; margin: 0; padding: 0;\">\n" +
		"      <p></p>\n" +
		"      <br>\n" +
		"      <p></p>\n" +
		"      <div>\n" +
		"         <div id=\"x_wrapper\" dir=\"ltr\" style=\"width: 100%; background-color: #ffffff;\">\n" +
		"            <table border=0 cellpadding=0 cellspacing=0 height=100% width=100%>\n" +
		"               <tbody>\n" +
		"                  <tr>\n" +
		"                     <td align=center valign=top>\n" +
		"                        <table id=template_header_image_container style=\"width: 100%; background-color: #ffffff;\">\n" +
		"                           <tbody>\n" +
		"                              <tr id=template_header_image>\n" +
		"                                 <td align=center valign=middle>\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_header_image_table>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td align=center valign=middle style=\"text-align: center; padding-top: 0px; padding-bottom: 0px;\">\n" +
		"                                                <p style=\"margin-bottom: 0; margin-top: 0;\"><a href=\"https://protect-eu.mimecast.com/s/jkOiCk7zBInkA8Mt2v76D?domain=foodcraft.ae\" target=\"_blank\" style=\"font-weight: normal; color: #000000; display: block; text-decoration: none;\"><img src=\"##foodCraftLogo##\" alt=Foodcraft width=193 style=\"border: none; display: inline; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; max-width: 100%; width: 193px;\"></a></p>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_container style=\"background-color: #ffffff; overflow: hidden; border-style: solid; border-color: #000000; border-radius: 0px; border-top: 0px solid #ffffff; border-right: 0px solid #ffffff; border-bottom: 0px solid #ffffff; border-left: 0px solid #ffffff; box-shadow: 0 0px 0px 0px rgba(0,0,0,0.1);\">\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top>\n" +
		"                                    <!-- Body -->\n" +
		"                                    <table border=0 cellpadding=0 cellspacing=0 width=590 id=template_body>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=body_content style=\"background-color: #ffffff; padding-top: 8px; padding-bottom: 0px;\">\n" +
		"                                                <!-- Content -->\n" +
		"                                                <table border=0 cellpadding=20 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0px 48px 0; padding-left: 48px; padding-right: 48px;\">\n" +
		"                                                            <div id=body_content_inner style=\"color: #636363; text-align: left; font-size: 14px; line-height: 24px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400;\">\n" +
		"                                                               <p style=\"margin: 0 0 16px;\">You have received an Ticket from ##custEmail##.</p>\n" +
		"                                                            </div>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                                <!-- End Content -->\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                    <!-- End Body -->\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                              <tr>\n" +
		"                                 <td align=center valign=top></td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <!-- End template container -->\n" +
		"                        <table border=0 cellpadding=0 cellspacing=0 width=100% id=template_footer_container>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td valign=top align=center>\n" +
		"                                    <table border=0 cellpadding=10 cellspacing=0 width=590 id=template_footer>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td valign=top id=template_footer_inside style=\"padding: 0; padding-top: 48px; padding-bottom: 48px; padding-left: 150px; padding-right: 150px;\">\n" +
		"                                                <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                   <tbody>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table id=footersocial border=0 cellpadding=10 cellspacing=0 width=100% style=\"border-bottom-width: 0px; border-bottom-color: #ffffff; border-bottom-style: solid;\">\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
//		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/McuUCmyB8h5p8BmCB_gcH?domain=facebook.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=facebook src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/facebook.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
//		"                                                                     <td valign=middle style=\"padding: 0; padding-top: 0px; padding-bottom: 0px; text-align: center; width: 50%;\"> <a href=https://protect-eu.mimecast.com/s/QqajCnOD7fGXgAJCZ25nA?domain=instagram.com class=ft-social-link style=\"font-weight: normal; color: #1ad656; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; display: block; text-decoration: none;\"><img alt=instagram src=https://foodcraft.ae/wp-content/plugins/kadence-woocommerce-email-designer/assets/images/black/instagram.png width=24 style=\"border: none; font-weight: bold; height: auto; outline: none; text-decoration: none; text-transform: capitalize; font-size: 14px; line-height: 24px; width: 24px; max-width: 100%; display: inline-block; vertical-align: bottom;\"> <span class=ft-social-title style=\"line-height: 24px; padding-left: 5px; font-size: px; font-weight: 400;\"> </span></a></td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                      <tr>\n" +
		"                                                         <td valign=top style=\"padding: 0;\">\n" +
		"                                                            <table border=0 cellpadding=10 cellspacing=0 width=100%>\n" +
		"                                                               <tbody>\n" +
		"                                                                  <tr>\n" +
		"                                                                     <td colspan=2 valign=middle id=credit style=\"padding: 0; border: 0; line-height: 125%; padding-left: 0px; padding-right: 0px; text-align: center; font-size: 12px; font-family: &quot;Helvetica Neue&quot;, Helvetica, Roboto, Arial, sans-serif; font-weight: 400; color: #555555; padding-top: 32px; padding-bottom: 0px;\">\n" +
		"                                                                        <p style=\"color: #555555;\">Copyright © 2021 | Foodcraft | Emirates Flight Catering</p>\n" +
		"                                                                     </td>\n" +
		"                                                                  </tr>\n" +
		"                                                               </tbody>\n" +
		"                                                            </table>\n" +
		"                                                         </td>\n" +
		"                                                      </tr>\n" +
		"                                                   </tbody>\n" +
		"                                                </table>\n" +
		"                                             </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                        <table class=gmail-app-fix width=100% border=0 cellpadding=0 cellspacing=0>\n" +
		"                           <tbody>\n" +
		"                              <tr>\n" +
		"                                 <td>\n" +
		"                                    <table cellpadding=0 cellspacing=0 border=0 align=center width=590>\n" +
		"                                       <tbody>\n" +
		"                                          <tr>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                             <td cellpadding=0 cellspacing=0 border=0 height=1 style=\"line-height: 1px; min-width: 196px;\"> </td>\n" +
		"                                          </tr>\n" +
		"                                       </tbody>\n" +
		"                                    </table>\n" +
		"                                 </td>\n" +
		"                              </tr>\n" +
		"                           </tbody>\n" +
		"                        </table>\n" +
		"                     </td>\n" +
		"                  </tr>\n" +
		"               </tbody>\n" +
		"            </table>\n" +
		"         </div>\n" +
//		"         <img src=http://tracking.managedcloudhostingemail.com/tracking/open?msgid=L4QiHHCMKVsrHqA3JB6AVg2&amp;c=1331129097727995288 style=width:1px;height:1px alt> <img src=https://foodcraft.ae/wp-json/wp-mail-smtp/v1/e/ZGF0YSU1QmVtYWlsX2xvZ19pZCU1RD0xNzY3MSZkYXRhJTVCZXZlbnRfdHlwZSU1RD1vcGVuLWVtYWlsJmhhc2g9OGRlNDg5ZWYxOWU5OWJmMGFhM2NiMmE2ZGVjMjljM2UxZWE3YWQ5N2JhZTEzM2M2NWNmZDJhZjQ2ZDFhZTAzYQ== alt>\n" +
		"      </div>\n" +
		"   </body>\n" +
		"</html>";

public String logo;

public EmailTemplate() throws IOException {
this.logo = this.getLogoBase64();
}

public String getLogoBase64() throws IOException {
String logo = "";
FileInputStream fis = new FileInputStream("src/main/resources/logo.txt");
logo = IOUtils.toString(fis, "UTF-8");
return logo;
}
}
