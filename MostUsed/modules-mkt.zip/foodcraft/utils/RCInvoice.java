package com.ekfc.foodcraft.utils;

import com.ekfc.foodcraft.model.OrdersDetails;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

public class RCInvoice {
	/**
	 * Constants
	 */
	public static String FONT_FAMILY = "Emirates Medium";
	public static int GENERAL_FONT_SIZE = 11;

	/**
	 * Req Map key names { o_created_on, delivery_date, i_created_on, invoice_id,
	 * userFullName, trn_number, orderNumber, billingAddress, trnNumber,
	 * shippingAmount, paymentAmmount }, oDetails List<OrdersDetails>
	 * 
	 * @param ord
	 * @param ordItms
	 * @return
	 */
	public static String doProcess(Map<String, Object> ord, List<OrdersDetails> ordItms, String tmpFilPat, String invFilPat) {
		System.out.println(ord);
		/**
		 * Load the docx file and then fill the cells by the JSON object, which in turn
		 * is created using the json String.
		 */

		String invoiceID = ord.get("invoice_id").toString();
		String invoiceDate = ord.get("i_created_on").toString();
		String requiredDate = ord.get("delivery_date").toString();
		String customerTRN = ord.get("trnNumber").toString();
		String billingAddress = ord.get("billingAddress").toString();
		String userFullName = ord.get("userFullName").toString();
		double shippingAmount = (double) ord.get("shippingAmount");
		double paymentAmount = (double) ord.get("paymentAmmount");

		try {
			// Load the file
			InputStream fis=new FileInputStream(invFilPat);
			XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(fis));
			fis.close();
			IBodyElement bodyElement = xdoc.getBodyElements().get(0);
			List<XWPFTable> tables = bodyElement.getBody().getTables();
			// Assigning null values so, the memory is refreshed and not much consumed.
			bodyElement = null;
			XWPFTable outerTable = tables.get(0);
			tables = null;

			// Updating Invoice ID
			outerTable.getRow(1).getCell(1).setText("Invoice No: " + invoiceID);

			// updating Inovie Date
			outerTable.getRow(2).getCell(1).setText("Invoice Date: " + invoiceDate);

			// updating Delivery Date
			outerTable.getRow(3).getCell(1).setText("Supply Date: " + requiredDate);

			// Cusotmer Name
			setCellvalueBold(outerTable.getRow(5).getCell(0)).setText(userFullName);

			// Address
			outerTable.getRow(6).getCell(0).setText(billingAddress);

			// Customer TRN
			outerTable.getRow(7).getCell(0).setText(customerTRN);

			// Add Products Information
			XWPFTable pTable = outerTable.getRow(8).getCell(0).getTables().get(0);
			pTable.removeRow(1);
			int tempCount = 0;
			for (int i = 0; i < ordItms.size(); i++) {
				tempCount = i + 1;
				OrdersDetails ordDet = ordItms.get(i);
				double grossItmPrice = ordDet.getQuanity() * ordDet.getSalesprice();
				double vatItmPrice = grossItmPrice - grossItmPrice / 1.05d;
				double netImPrice = grossItmPrice - vatItmPrice;
				XWPFTableRow row = pTable.createRow();
				// S.NO
				row.getCell(0).setText(String.valueOf(i + 1));
				// Product Description
				row.getCell(1).setText(ordDet.getDescription());
				// Quantity
				setCellvalue(row.getCell(2), null, null).setText(String.valueOf((int) ordDet.getQuanity()));
				// Unit Price
				setCellvalue(row.getCell(3), null, null)
						.setText(returnTwoDeciamlPlacesForDouble(ordDet.getSalesprice()));
				// Price Net excl of Tax
				setCellvalue(row.getCell(4), null, null).setText(returnTwoDeciamlPlacesForDouble(netImPrice));
				// Discount
				setCellvalue(row.getCell(5), null, null).setText("0");
				// Rate of Tax
				setCellvalue(row.getCell(6), null, null).setText("5%");
				// Tax Amount
				setCellvalue(row.getCell(7), null, null).setText(returnTwoDeciamlPlacesForDouble(vatItmPrice));
				// Total Amount inclusive of Tax
				setCellvalue(row.getCell(8), null, null).setText(returnTwoDeciamlPlacesForDouble(grossItmPrice));
			}

			// Shipping Entry
			XWPFTableRow shippingRow = pTable.createRow();
			// S.NO
			shippingRow.getCell(0).setText(String.valueOf(tempCount + 1));
			// Product Description
			shippingRow.getCell(1).setText("Shipping Charges");
			// Quantity
			setCellvalue(shippingRow.getCell(2), null, null).setText("1");
			// Unit Price
			setCellvalue(shippingRow.getCell(3), null, null).setText(String.valueOf(shippingAmount));
			// Price Net excl of Tax
			setCellvalue(shippingRow.getCell(4), null, null)
					.setText(returnTwoDeciamlPlacesForDouble((shippingAmount / 1.05d)));
			// Discount
			setCellvalue(shippingRow.getCell(5), null, null).setText("0");
			// Rate of Tax
			setCellvalue(shippingRow.getCell(6), null, null).setText("5%");
			// Tax Amount
			setCellvalue(shippingRow.getCell(7), null, null)
					.setText(returnTwoDeciamlPlacesForDouble(shippingAmount - shippingAmount / 1.05d));
			// Total Amount inclusive of Tax
			setCellvalue(shippingRow.getCell(8), null, null).setText(returnTwoDeciamlPlacesForDouble(shippingAmount));

			// Grand Total Entry
			XWPFTableRow totalEntry = pTable.createRow();

			// Product Description
			setCellvalueBold(totalEntry.getCell(1)).setText("Total");
			// Price Net excl of Tax
			setCellvalueBoldInCenter(totalEntry.getCell(4))
					.setText(returnTwoDeciamlPlacesForDouble(paymentAmount / 1.05d));
			// Discount
			setCellvalueBoldInCenter(totalEntry.getCell(5)).setText("0");
			// Rate of Tax
			// setCellvalueBold(totalEntry.getCell(6)).setText("5");
			// Tax Amount
			setCellvalueBoldInCenter(totalEntry.getCell(7))
					.setText(returnTwoDeciamlPlacesForDouble(paymentAmount - paymentAmount / 1.05d));
			// Total Amount inclusive of Tax
			setCellvalueBoldInCenter(totalEntry.getCell(8)).setText(returnTwoDeciamlPlacesForDouble(paymentAmount));

			// Add Grand Total Information
			XWPFTable tTable = outerTable.getRow(10).getCell(0).getTables().get(0);
			setCellvalueBoldInCenter(tTable.getRow(0).getCell(0)).setText("Grand Total (AED)");
			setCellvalueBoldInCenter(tTable.getRow(0).getCell(2))
					.setText(returnTwoDeciamlPlacesForDouble(paymentAmount));
			FileOutputStream fos = new FileOutputStream(tmpFilPat+invoiceID+".docx", false);
			xdoc.write(fos);
			fos.flush();
			fos.close();
			fos = null;
			// destructing the values

		} catch (IOException e) {
			e.printStackTrace();
			return e.getMessage();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			return e.getMessage();
		}
		return "Created Successfully";

	}

	/**
	 * This method is to set the Cell value, just send the cell in which values are
	 * to be updated.
	 * 
	 * @param cell
	 * @return
	 */
	private static XWPFRun setCellvalue(XWPFTableCell cell, ParagraphAlignment pAlign, TextAlignment tAlign) {
		if (pAlign == null) {
			pAlign = ParagraphAlignment.CENTER;
		}
		if (tAlign == null) {
			tAlign = TextAlignment.TOP;
		}
		cell.setVerticalAlignment(XWPFTableCell.XWPFVertAlign.CENTER);
		XWPFParagraph xwpfParagraph = cell.getParagraphs().get(0);
		xwpfParagraph.setSpacingBeforeLines(0);
		xwpfParagraph.setAlignment(pAlign);
		XWPFRun run = xwpfParagraph.createRun();
		run.setFontFamily(FONT_FAMILY);
		run.setFontSize(GENERAL_FONT_SIZE);
		xwpfParagraph.setWordWrap(true);
		return run;
	}

	/**
	 * This method is to set Cell value with a paragraph with more lines and line
	 * breaks.
	 * 
	 * @param cell
	 * @param adr
	 * @return
	 */
	private static XWPFRun setCellvalueAdr(XWPFTableCell cell, String adr) {
		XWPFParagraph xwpfParagraph = cell.addParagraph();
		// xwpfParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun run = xwpfParagraph.createRun();
		if (adr.contains("\n")) {
			String[] lines = adr.split("\n");
			run.setText(lines[0], 0);
			for (int i = 1; i < lines.length; i++) {
				run.addBreak();
				run.setText(lines[i]);
			}
		}
		run.setFontFamily(FONT_FAMILY);
		run.setFontSize(GENERAL_FONT_SIZE);
		return run;
	}

	/**
	 * This method is to set the cell with Bold values.
	 * 
	 * @param cell
	 * @return
	 */
	private static XWPFRun setCellvalueBold(XWPFTableCell cell) {

		XWPFParagraph xwpfParagraph = cell.getParagraphs().get(0);
		// xwpfParagraph.setAlignment(ParagraphAlignment.LEFT);
		XWPFRun run = xwpfParagraph.createRun();
		run.setFontFamily(FONT_FAMILY);
		run.setFontSize(GENERAL_FONT_SIZE);
		run.setBold(true);
		return run;
	}

	private static XWPFRun setCellvalueBoldInCenter(XWPFTableCell cell) {

		XWPFParagraph xwpfParagraph = cell.getParagraphs().get(0);
		xwpfParagraph.setAlignment(ParagraphAlignment.CENTER);
		XWPFRun run = xwpfParagraph.createRun();
		run.setFontFamily(FONT_FAMILY);
		run.setFontSize(GENERAL_FONT_SIZE);
		run.setBold(true);
		return run;
	}

	/**
	 * This method is to attach the Image to docx file.
	 * 
	 * @param cell
	 * @param bis
	 * @throws InvalidFormatException
	 * @throws IOException
	 */
	private static XWPFPicture setSignatureImage(XWPFTableCell cell, ByteArrayInputStream bis)
			throws InvalidFormatException, IOException {
		XWPFPicture picture = null;
		if (bis != null) {
			XWPFParagraph paragraph1 = cell.addParagraph();
			XWPFRun run1 = paragraph1.createRun();
			// //ByteArrayInputStream bis1 = new
			// ByteArrayInputStream(Base64.getDecoder().decode(ekfcsign.substring(ekfcsign.indexOf(",")+1)));
			picture = run1.addPicture(bis, XWPFDocument.PICTURE_TYPE_PNG, "testsds.png", Units.pixelToEMU(150),
					Units.pixelToEMU(150));
		}
		return picture;
	}

	private static String returnTwoDeciamlPlacesForInt(int value) {
		return String.format("%.2f", value);
	}

	private static String returnTwoDeciamlPlacesForDouble(double value) {
		return String.format("%.2f", value);
	}
}
