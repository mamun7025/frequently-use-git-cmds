package com.ekfc.foodcraft.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import com.ekfc.foodcraft.model.OrdersDetails;

public class EmailsSender {

	public static void main(String[] args) throws IOException {
		byte[] invoiceBytes = Files.readAllBytes(
		Paths.get(".").resolve("invoice").resolve("logo.png"));
		String invoicedInvoice = Base64.getEncoder().encodeToString(invoiceBytes);
		System.out.println("Logo PNG >>> " + invoicedInvoice);
		BufferedWriter writer = new BufferedWriter(new FileWriter("logo.txt"));
	    writer.write(invoicedInvoice);
	    
	    writer.close();
	}

	/**
	 * $$orderNumber$$ $$productDetails$$ $$subTotal$$ $$shippingCost$$
	 * $$vatAmount$$ $$totalAmount$$
	 */

	public static String getMailTemplate(String templateName, Map<String, Object> emailMap) {
		try {
			InputStream inputStream = EmailsSender.class.getResourceAsStream("/mail-templates/" + templateName);
			InputStreamReader streamReader = new InputStreamReader(inputStream, "UTF-8");
			BufferedReader in = new BufferedReader(streamReader);
			StringBuffer sb = new StringBuffer();
			for (String line; (line = in.readLine()) != null;) {
				sb.append(line);
			}
			inputStream.close();
			inputStream = null;
			streamReader.close();
			streamReader = null;
			in.close();
			in = null;
			String s = sb.toString();
			sb = null;
			return constructEmail(emailMap);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static String constructEmail(Map<String, Object> eMp) {
		String tmpBody = "<html><head></head><body><div style=&quot;font-family:Geneva,arial,helvetica;&quot;>Dear ##firstName##,<br/><br/>Your Finefare.ae Order Confirmation<br/><br/><br/>Order Number: <span style=&quot;font-weight:bold;&quot;>##orderNumber##</span><br/><br/>Order Totals: <br/>Sub Total: <span style=&quot;font-weight:bold;&quot;>AED ##subTotal##</span><br/>Shipping Cost: <span style=&quot;font-weight:bold;&quot;>AED ##shippingCost##</span><br/>VAT (5%): <span style=&quot;font-weight:bold;&quot;>AED ##vatAmount##</span><br/>Total Amount: <span style=&quot;font-weight:bold;&quot;>AED ##totalAmount##</span><br/></div><br/><br/><div style=&quot;font-family:Geneva,arial,helvetica;font-weight:bold;&quot;>Regards,<br/>FineFare.ae<br/></div></body></html>";
		System.out.println("email body is >>> " + tmpBody);
		tmpBody.replaceAll("##orderNumber##", eMp.get("orderNumber").toString());
		tmpBody.replaceAll("##subTotal##", eMp.get("totalAmount").toString());
		tmpBody.replaceAll("##shippingCost##", eMp.get("shippingAmount").toString());
		tmpBody.replaceAll("##vatAmount##", eMp.get("vatAmount").toString());
		tmpBody.replaceAll("##totalAmount##", eMp.get("paymentAmmount").toString());

		List<OrdersDetails> oDetails = (List<OrdersDetails>) eMp.get("cartDetails");
		String productsString = "";
		if (FoodcraftCollectionUtils.isNotEmpty(oDetails)) {
			for (OrdersDetails o : oDetails) {
				productsString = productsString
						+ "<div class=\"d-sm-flex justify-content-between align-items-center my-2 pb-3 border-bottom\">"
						+ "<div class=\"d-block d-sm-flex align-items-center text-sm-start\">"
						+ "<a class=\"d-inline-block flex-shrink-0 mr-3 me-sm-3\" href=\"#\"></a>"
						+ "<div class=\"pt-2\">" + "<h3 class=\"product-title fs-base mb-2\"><a href=\"#\">"
						+ o.getDescription() + "</a></h3>"
						+ "<div class=\"fs-sm\"><span class=\"text-muted me-2\">UOM:</span>" + o.getPricingUom()
						+ "</div>" + "<div class=\"fs-sm\"><span class=\"text-muted me-2\">Quantity:</span>"
						+ o.getQuanity() + "</div>" + "<div class=\"fs-lg text-accent pt-2\">AED " + o.getSalesprice()
						+ "</div>" + "</div>" + "</div>" + "</div>";
			}
		}
		tmpBody.replaceAll("$$productDetails$$", productsString);
		tmpBody.replaceAll("##firstName##", eMp.get("firstName").toString());
		return tmpBody;
	}
}
