package com.ekfc.foodcraft.utils;

import org.apache.commons.codec.digest.DigestUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class PaymentUtils {

    public static String getDPToken(final String digiPayHostName) {
        try {

            URL url = new URL(digiPayHostName+ "/dp/api/auth/token-rc");
            SSLUtils.execute();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            String input = "{" +
                    "	\"APIKey\":\"897edfac8a10804acf481331f5c1f8dc16a10b97cf1f1f4d63addccb9ba865ca\",\r\n" +
                    "	\"ClientID\":\"3254851121521\",\r\n" +
                    "	\"SecureHash\":\"40fef67151fee6fb485bbd477199378be2dfc9a1bb66dcb9e64a7896a8cfb93c\"\r\n" +
                    "}";

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new RuntimeException("Unable to get token"
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

            String output;
            StringBuffer rs=new StringBuffer();
            while ((output = br.readLine()) != null) {
                rs.append(output);
            }
            br.close();
            conn.disconnect();
            try{
                LinkedHashMap<String, Object> rsp = (LinkedHashMap<String, Object>)WSUtils.stringToObject(rs.toString(), false);
                rs=null;
                LinkedHashMap<String, Object>  rstr = (LinkedHashMap<String, Object>)rsp.get("mData");
                String strtokn = rstr.get("accessToken").toString();
                System.out.println("The response is :"+strtokn);
                return strtokn;
            }catch(Exception exx){
                System.out.println("Error - 1 >> "+exx.getMessage());
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            System.out.println("Error - 2 >> "+e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error - 3 >> "+e.getMessage());
        }
        return "";
    }

    public static String getSecureHash(TreeMap<String, Object> treeMapData) throws Exception {
        StringBuffer buffer = null;
        String m2aSecureHash = null;
        String secretKey = null;

        try {
            if (treeMapData == null || treeMapData.size() == 0) {
                m2aSecureHash = "";
                return m2aSecureHash;
            }

            secretKey = "d1G!6$i@!o#ma3;m!nmNqd5qY@!f7mb326M";

            buffer = new StringBuffer(secretKey);

            Iterator<Map.Entry<String, Object>> t = treeMapData.entrySet().iterator();
            while (t.hasNext()) {
                Map.Entry<String, Object> entry = t.next();
                buffer.append(entry.getValue());
            }
            m2aSecureHash = DigestUtils.sha256Hex(buffer.toString());

        } finally {

            if (buffer != null)
                buffer = null;

        }
        return m2aSecureHash;
    }
}
