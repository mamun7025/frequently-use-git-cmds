package com.ekfc.foodcraft.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.function.Supplier;

import com.ekfc.foodcraft.dao.OrdersDAO;
import com.ekfc.foodcraft.model.CustomerDetails;
import com.ekfc.foodcraft.model.OrderAddress;
import com.ekfc.foodcraft.model.OrdersDetails;
import com.ekfc.foodcraft.model.OrdersHeader;
import com.ekfc.foodcraft.templates.EmailTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;

public class ERPUtil {
	
	public static boolean callERPAPI(String erpurl, String tkn, String payLoad, int id, String stackHolderList, String domainName, String emailURI, String authHeader) throws Exception {
		
		CompletableFuture<String> future = CompletableFuture.supplyAsync(new Supplier<String>() {
		    @Override
		    public String get() {
		    	String isValid = "true";
					try {
						URL url = new URL(erpurl);
						SSLUtils.execute();
						HttpURLConnection conn = (HttpURLConnection) url.openConnection();
						conn.setDoOutput(true);
						conn.setRequestMethod("POST");
						conn.setRequestProperty("Content-Type", "application/json");
						conn.setRequestProperty("Authorization", "Basic "+tkn);
						conn.setRequestProperty("accept", "application/json");
						/*Gson gson=new Gson();
						String input = "{\"DataSetIn\":"+gson.toJson(payLoad)+"}";gson=null;*/
						String input = payLoad;
						System.out.println("==Input=>"+input);
						//here the request data needs to be stored in fc_erp_integration
						OutputStream os = conn.getOutputStream();
						os.write(input.getBytes());input=null;
						os.flush();
						if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
							BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
							String output;
							StringBuffer rs=new StringBuffer();
							while ((output = br.readLine()) != null) {
								rs.append(output);
							}
							br.close();
							conn.disconnect();
							sendERPErrorEmail(payLoad, rs.toString(),stackHolderList, "ERP API Error", domainName, emailURI, authHeader);
							isValid = "false";
							System.out.println(">> The ERP Error is >> "+rs);rs=null;
							System.out.println("Error - 0 >> "+conn.getResponseCode());
							throw new RuntimeException("#DP#1:NI Error:"
								+ conn.getResponseCode());
						}
						BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

						String output;
						StringBuffer rs=new StringBuffer();
						while ((output = br.readLine()) != null) {
							rs.append(output);
						}
						//here the response data needs to be stored in fc_erp_integration
					//	OrdersDAO ordersDao = new OrdersDAO();
					//	ordersDao.updateERPResponse(id, rs.toString());
						br.close();
						conn.disconnect();
						try{

							System.out.println("The ERP API response is : "+rs.toString());rs=null;
							
						}catch(Exception exx){
							sendERPErrorEmail(payLoad, rs.toString(),stackHolderList, "ERP API Error", domainName, emailURI, authHeader);
							isValid = "false";
							System.out.println("Error - 1 >> "+exx.getMessage());
							
						}
					  } catch (MalformedURLException e) {
							try {
								sendERPErrorEmail(payLoad, e.getMessage().toString(),stackHolderList, "ERP API Error", domainName, emailURI, authHeader);
								isValid = "false";
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						e.printStackTrace();
						System.out.println("Error - 2 >> "+e.getMessage());
					  } catch (IOException e) {
							try {
								sendERPErrorEmail(payLoad, e.toString(),stackHolderList, "ERP API Error", domainName, emailURI, authHeader);
								isValid = "false";
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						e.printStackTrace();
						System.out.println("Error - 3 >> "+e.getMessage());
					  }
		    	return isValid;
		    }
		});

		// Block and get the result of the Future
		String result = future.get();
		System.out.println("ERP response --> "+result);
		return Boolean.parseBoolean(result);
	}

	private static String constructCancelOrderEmail(Map<String, Object> eMp) {
		String tmpBody = EmailTemplate.ORDER_CANCEL_EMAIL_TEMPLATE;

		List<OrdersHeader> odrHeader = (List<OrdersHeader>)eMp.get("orderHeader");
		List<OrderAddress> odrAddr = (List<OrderAddress>)eMp.get("orderAddress");
		List<CustomerDetails> custDetails = (List<CustomerDetails>)eMp.get("custDetails");

		final String orderNumber = odrHeader.get(0).getOrderNumber();
		final String firstName = custDetails.get(0).getFirst_name();
		final String lastName = custDetails.get(0).getLast_name();
		String paymentMode = odrHeader.get(0).getPaymentMode();
		final String total = String.valueOf(odrHeader.get(0).getTotalAmount());
		final String subTotal = String.valueOf(odrHeader.get(0).getPaymentAmmount());
		final String vat = String.valueOf(odrHeader.get(0).getVatAmount());
		final String shippingCharges = String.valueOf(odrHeader.get(0).getShippingAmount());
		final String discount = String.valueOf(odrHeader.get(0).getDiscountAmmount());
	//	final String createdDate = odrHeader.get(0).getCreatedOn();
	//	final String domainName = eMp.get("domainName").toString();
		final String logo = eMp.get("logo").toString();
		final String billingAddress = odrAddr.get(0).getBilling_address();
		final String deliveryDate = odrAddr.get(0).getDelivery_date();
		final String deliverySlot = odrAddr.get(0).getDelivery_slots();
		final String deliveryAddress = odrAddr.get(0).getDelivering_address();

		if(paymentMode.equalsIgnoreCase("cod")){
			paymentMode = EmailTemplate.CREDIT_CARD_ON_DELIVERY;
		}
		if(paymentMode.equalsIgnoreCase("online")){
			paymentMode = EmailTemplate.ONLINE_PAYMENT;
		}

		tmpBody = tmpBody.replaceAll("##foodCraftLogo##", logo);
	//	tmpBody = tmpBody.replaceAll("##domainName##", domainName);
		tmpBody = tmpBody.replaceAll("##lastName##", lastName);
		tmpBody = tmpBody.replaceAll("##orderNumber##", orderNumber);
		tmpBody = tmpBody.replaceAll("##paymentMode##", paymentMode);
		tmpBody = tmpBody.replaceAll("##deliveryDate##", deliveryDate);
		tmpBody = tmpBody.replaceAll("##subTotal##", subTotal);
		tmpBody = tmpBody.replaceAll("##discount##", discount);
		tmpBody = tmpBody.replaceAll("##shippingCharges##","AED" +  shippingCharges);
		tmpBody = tmpBody.replaceAll("##cashOnDelivery##", "AED 0.0");
		tmpBody = tmpBody.replaceAll("##total##", total);
		tmpBody = tmpBody.replaceAll("##vat##", vat);
		tmpBody = tmpBody.replaceAll("##timeSlot##", deliverySlot);
		tmpBody = tmpBody.replaceAll("##notes##", "");
		tmpBody = tmpBody.replaceAll("##deliveryAddress##", deliveryAddress);
		tmpBody = tmpBody.replaceAll("##landmark##", "");
		tmpBody = tmpBody.replaceAll("##billingAddress##", billingAddress);
		tmpBody = tmpBody.replaceAll("##shippingAddress##", billingAddress);

		List<OrdersDetails> oDetails = (List<OrdersDetails>) eMp.get("orderDetails");
		String productsString = "";
		if (FoodcraftCollectionUtils.isNotEmpty(oDetails)) {
			for (OrdersDetails o : oDetails) {
				productsString = productsString
						+"<tr class=\"x_order_item\">" +
						"<td class=\"x_td\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; vertical-align:middle; word-wrap:break-word; padding-left:0; text-align:left\">" +
						o.getDescription() + " </td>" +
						"<td class=\"x_td\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; vertical-align:middle; text-align:center\">" +
						o.getQuanity() + " </td>" +
						"<td class=\"x_td\" style=\"color:#636363; border:0; padding:12px; font-family:&quot;Helvetica Neue&quot;,Helvetica,Roboto,Arial,sans-serif; border-color:#e4e4e4; padding-top:8px; padding-bottom:8px; border-bottom-width:1px; border-bottom-style:solid; vertical-align:middle; padding-right:0; text-align:right\">" +
						"<span class=\"x_woocommerce-Price-amount x_amount\"><span class=\"x_woocommerce-Price-currencySymbol\">AED" +
						"</span>"+o.getQuanity() * o.getSalesprice() +"</span> </td>" +
						"</tr>";
			}
		}
		tmpBody = tmpBody.replaceAll("##orderItems##", productsString);
		tmpBody = tmpBody.replaceAll("##firstName##", firstName);
		return tmpBody;
	}

	public static boolean sendCancelOrderEmail(Map<String, Object> reqMap, String toEmail, String emailSubject, String domain, String orderNumber, String authHeader, String emailURI) throws IOException {
		String emailBody=constructCancelOrderEmail(reqMap);
		Gson gson = new Gson();
		String payLoad = "{" +
				 "\"x1_to\":\"" + toEmail + "\"," +
				 "\"x2_subject\":\"" + emailSubject + "\"," +
				 "\"x3_body\":\"" + gson.toJson(emailBody) + "\"," +
				 "\"x4_attach\":\"" + "N/A" + "\"," +
				 "\"x5_attach_name\":\"" + "N/A" + "\"" +
				 "}";
		System.out.println("sendCancelOrder Email Payload : "+payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic "+authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The sendCancelOrderEmail Error is >> "+rs);rs=null;
				System.out.println("Error - 0 >> "+conn.getResponseCode());
				throw new RuntimeException("#DP#1:sendCancelOrderEmail error code :"
					+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The sendCancelOrderEmail response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("sendCancelOrderEmail Error - 1 >> "+exx.getMessage());
			}
		  } catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("sendCancelOrderEmail Error - 2 >> "+e.getMessage());
		  } catch (IOException e) {
			e.printStackTrace();
			System.out.println("sendCancelOrderEmail Error - 3 >> "+e.getMessage());
		  }
		return false;
	}


	private static String constructRefundOrderEmail(Map<String, Object> eMp) {
		String tmpBody = EmailTemplate.ORDER_REFUND_EMAIL_TEMPLATE;

		List<OrdersHeader> odrHeader = (List<OrdersHeader>)eMp.get("orderHeader");
		List<CustomerDetails> custDetails = (List<CustomerDetails>)eMp.get("custDetails");

		final String orderNumber = odrHeader.get(0).getOrderNumber();
		final String firstName = custDetails.get(0).getFirst_name();
		final String lastName = custDetails.get(0).getLast_name();
		String paymentMode = odrHeader.get(0).getPaymentMode();
		final String logo = eMp.get("logo").toString();

		tmpBody = tmpBody.replaceAll("##foodCraftLogo##", logo);
		tmpBody = tmpBody.replaceAll("##lastName##", lastName);
		tmpBody = tmpBody.replaceAll("##orderNumber##", orderNumber);
		tmpBody = tmpBody.replaceAll("##firstName##", firstName);
		return tmpBody;
	}

	public static boolean sendRefundOrderEmail(Map<String, Object> reqMap, String toEmail, String emailSubject, String domain, String orderNumber, String authHeader, String emailURI) throws IOException {
		String emailBody=constructRefundOrderEmail(reqMap);
		Gson gson = new Gson();
		String payLoad = "{" +
				 "\"x1_to\":\"" + toEmail + "\"," +
				 "\"x2_subject\":\"" + emailSubject + "\"," +
				 "\"x3_body\":\"" + gson.toJson(emailBody) + "\"," +
				 "\"x4_attach\":\"" + "N/A" + "\"," +
				 "\"x5_attach_name\":\"" + "N/A" + "\"" +
				 "}";
		System.out.println("sendRefundOrder Email Payload : "+payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic "+ authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The sendRefundOrderEmail Error is >> "+rs);rs=null;
				System.out.println("Error - 0 >> "+conn.getResponseCode());
				throw new RuntimeException("#DP#1:sendRefundOrderEmail error code :"
					+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The sendRefundOrderEmail response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("sendRefundOrderEmail Error - 1 >> "+exx.getMessage());
			}
		  } catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("sendRefundOrderEmail Error - 2 >> "+e.getMessage());
		  } catch (IOException e) {
			e.printStackTrace();
			System.out.println("sendRefundOrderEmail Error - 3 >> "+e.getMessage());
		  }
		return false;
	}

	private static String constructOrderCompletionEmail(Map<String, Object> eMp) {
		String tmpBody = EmailTemplate.ORDER_COMPLETION_EMAIL_TEMPLATE;

		List<OrdersHeader> odrHeader = (List<OrdersHeader>)eMp.get("orderHeader");
		List<CustomerDetails> custDetails = (List<CustomerDetails>)eMp.get("custDetails");

		final String orderNumber = odrHeader.get(0).getOrderNumber();
		final String firstName = custDetails.get(0).getFirst_name();
		final String lastName = custDetails.get(0).getLast_name();
		final String logo = eMp.get("logo").toString();

		tmpBody = tmpBody.replaceAll("##foodCraftLogo##", logo);
		tmpBody = tmpBody.replaceAll("##lastName##", lastName);
		tmpBody = tmpBody.replaceAll("##orderNumber##", orderNumber);
		tmpBody = tmpBody.replaceAll("##firstName##", firstName);
		return tmpBody;
	}

	public static boolean sendOrderCompletionEmail(Map<String, Object> reqMap, String toEmail, String emailSubject, String domain, String orderNumber, String authHeader, String emailURI) throws IOException {
		String emailBody=constructOrderCompletionEmail(reqMap);
		Gson gson = new Gson();
		String payLoad = "{" +
				 "\"x1_to\":\"" + toEmail + "\"," +
				 "\"x2_subject\":\"" + emailSubject + "\"," +
				 "\"x3_body\":\"" + gson.toJson(emailBody) + "\"," +
				 "\"x4_attach\":\"" + "N/A" + "\"," +
				 "\"x5_attach_name\":\"" + "N/A" + "\"" +
				 "}";
		System.out.println("sendOrderCompletion Email Payload : "+payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic "+ authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The sendOrderCompletionEmail Error is >> "+rs);rs=null;
				System.out.println("Error - 0 >> "+conn.getResponseCode());
				throw new RuntimeException("#DP#1:sendOrderCompletionEmail error code :"
					+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The sendOrderCompletionEmail response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("sendOrderCompletionEmail Error - 1 >> "+exx.getMessage());
			}
		  } catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("sendOrderCompletionEmail Error - 2 >> "+e.getMessage());
		  } catch (IOException e) {
			e.printStackTrace();
			System.out.println("sendOrderCompletionEmail Error - 3 >> "+e.getMessage());
		  }
		return false;
	}


	private static String constructOrderDeliveredEmail(Map<String, Object> eMp) {
		String tmpBody = EmailTemplate.ORDER_DELIVERED_EMAIL_TEMPLATE;

		List<OrdersHeader> odrHeader = (List<OrdersHeader>)eMp.get("orderHeader");
		List<CustomerDetails> custDetails = (List<CustomerDetails>)eMp.get("custDetails");

		final String orderNumber = odrHeader.get(0).getOrderNumber();
		final String firstName = custDetails.get(0).getFirst_name();
		final String lastName = custDetails.get(0).getLast_name();
		final String logo = eMp.get("logo").toString();

		tmpBody = tmpBody.replaceAll("##foodCraftLogo##", logo);
		tmpBody = tmpBody.replaceAll("##lastName##", lastName);
		tmpBody = tmpBody.replaceAll("##orderNumber##", orderNumber);
		tmpBody = tmpBody.replaceAll("##firstName##", firstName);
		return tmpBody;
	}

	public static boolean sendOrderDeliveredEmail(Map<String, Object> reqMap, String toEmail, String emailSubject, String domain, String orderNumber, String authHeader, String emailURI) throws IOException {
		String emailBody=constructOrderDeliveredEmail(reqMap);
		ObjectMapper mapper = new ObjectMapper();
		String jsonMailBody = mapper.writeValueAsString(emailBody);
		String payLoad = "{" +
				"\"x1_to\":\"" + toEmail + "\"," +
				"\"x2_subject\":\"" + emailSubject + "\"," +
				"\"x3_body\":" + jsonMailBody + "," +
				"\"x4_attach\":\"" + reqMap.get("invDocB64String") + "\"," +
//				"\"x4_attach\":\"data:application/pdf;base64," + reqMap.get("invDocB64String") + "\"," +
//				"\"x5_attach_name\":\"" + "Tax_Invoice.pdf" + "\"" +
//				"\"x5_attach_name\":\"FoodCraft_Tax_Invoice_#" + orderNumber +".pdf"+ "\"" +
				"\"x5_attach_name\":\"FoodCraft_Tax_Invoice_#" + orderNumber +".pdf"+ "\"" +
				"}";
		System.out.println("sendOrderCompletion Email Payload : "+payLoad);
//		String json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(payLoad);
//		System.out.println(json);

		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic "+ authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The sendOrderCompletionEmail Error is >> "+rs);rs=null;
				System.out.println("Error - 0 >> "+conn.getResponseCode());
				throw new RuntimeException("#DP#1:sendOrderCompletionEmail error code :"
						+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The sendOrderCompletionEmail response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("sendOrderCompletionEmail Error - 1 >> "+exx.getMessage());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("sendOrderCompletionEmail Error - 2 >> "+e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("sendOrderCompletionEmail Error - 3 >> "+e.getMessage());
		}
		return false;
	}



	public static boolean sendEmailCampaign(String emailBody, String toEmail, String emailSubject, String domain, String authHeader, String emailURI) throws IOException {

		Gson gson = new Gson();
		String payLoad = "{" +
				"\"x1_to\":\"" + toEmail + "\"," +
				"\"x2_subject\":\"" + emailSubject + "\"," +
				"\"x3_body\":" + gson.toJson(emailBody) + "," +
				"\"x4_attach\":\"" + "N/A" + "\"," +
				"\"x5_attach_name\":\"" + "N/A" + "\"" +
				"}";
		System.out.println("Email Campaign Payload : " + payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic "+authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The Email Campaign Error is >> "+rs);rs=null;
				System.out.println("Error - 0 >> "+conn.getResponseCode());
				throw new RuntimeException("#DP#1: Email Campaign error Code is :"
						+ conn.getResponseCode());
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The Email Campaign response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("Email Campaign Error - 1 >> "+exx.getMessage());
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("Email Campaign Error - 2 >> "+e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Email Campaign Error - 3 >> "+e.getMessage());
		}
		return false;
	}
	
	public static boolean sendERPErrorEmail(String input, String error, String toEmail, String emailSubject, String domain, String emailURI, String authHeader) throws IOException {
		String emailBody=constructERPErrorEmail(input, error);
		ObjectMapper mapper = new ObjectMapper();
		String jsonMailBody = mapper.writeValueAsString(emailBody);
		String payLoad = "{" + 
				"\"x1_to\":\"" + toEmail + "\"," +
				"\"x2_subject\":\"" + emailSubject + "\"," +
				"\"x3_body\":" + jsonMailBody + "," +
						 "\"x4_attach\":\"N/A\"," +
						 "\"x5_attach_name\":\"N/A\"" +
						 
						 //commented for not sending the tax invoice
//						 "\"x4_attach\":\"" + attachment + "\"," +
//						 "\"x5_attach_name\":\"FoodCraft_Tax_Invoice_#" + orderNumber +".pdf"+ "\"" +
						 "}";
						 
		System.out.println("Send ERP Payload : "+payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic " + authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The sendERPErrorEmail Error is >> "+rs);
				rs=null;
				
				  System.out.println("Error - 0 >> "+conn.getResponseCode());
				  throw new RuntimeException("#DP#1:sendERPErrorEmail error code :" + conn.getResponseCode());
				 
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The sendERPErrorEmail response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("sendERPErrorEmail Error - 1 >> "+exx.getMessage());
			}
		  } catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("sendERPErrorEmail Error - 2 >> "+e.getMessage());
		  } catch (IOException e) {
			e.printStackTrace();
			System.out.println("sendERPErrorEmail Error - 3 >> "+e.getMessage());
		  }
		return false;
	}
	
	private static String constructERPErrorEmail(String payLoad, String error) {
		
		String tmpBody = EmailTemplate.ERP_ERROR_EMAIL;
		tmpBody = tmpBody.replaceAll("##ERPRequest##", payLoad);
		tmpBody = tmpBody.replaceAll("##ERPResponse##", error);
		return tmpBody;
	}
	
	public static boolean sendTicketStatusEmail(String id, String email, String logo, String toEmail, String emailSubject, String domain, String emailURI, String authHeader) throws IOException {
		String emailBody=constructTicketStatusEmail(id, email, logo);
		ObjectMapper mapper = new ObjectMapper();
		String jsonMailBody = mapper.writeValueAsString(emailBody);
		String payLoad = "{" + 
				"\"x1_to\":\"" + toEmail + "\"," +
				"\"x2_subject\":\"" + emailSubject + "\"," +
				"\"x3_body\":" + jsonMailBody + "," +
						 "\"x4_attach\":\"N/A\"," +
						 "\"x5_attach_name\":\"N/A\"" +
						 
						 //commented for not sending the tax invoice
//						 "\"x4_attach\":\"" + attachment + "\"," +
//						 "\"x5_attach_name\":\"FoodCraft_Tax_Invoice_#" + orderNumber +".pdf"+ "\"" +
						 "}";
						 
		System.out.println("Send Ticket status Payload : "+payLoad);
		try {
			URL url = new URL(domain + emailURI);
			SSLUtils.execute();
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Authorization", "Basic " + authHeader);
			conn.setRequestProperty("accept", "application/json");
			//System.out.println("==Input=>"+payLoad);
			OutputStream os = conn.getOutputStream();
			os.write(payLoad.getBytes());
			os.flush();
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
				String output;
				StringBuffer rs=new StringBuffer();
				while ((output = br.readLine()) != null) {
					rs.append(output);
				}
				br.close();
				conn.disconnect();
				System.out.println(">> The send ticket status Error is >> "+rs);
				rs=null;
				
				  System.out.println("Error - 0 >> "+conn.getResponseCode());
				  throw new RuntimeException("#DP#1:send ticket status error code :" + conn.getResponseCode());
				 
			}
			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			String output;
			StringBuffer rs=new StringBuffer();
			while ((output = br.readLine()) != null) {
				rs.append(output);
			}
			br.close();
			conn.disconnect();
			try{
				System.out.println("The send ticket status response is : "+rs.toString());rs=null;
				return true;
			}catch(Exception exx){
				System.out.println("send ticket status Error - 1 >> "+exx.getMessage());
			}
		  } catch (MalformedURLException e) {
			e.printStackTrace();
			System.out.println("send ticket status Error - 2 >> "+e.getMessage());
		  } catch (IOException e) {
			e.printStackTrace();
			System.out.println("send ticket status Error - 3 >> "+e.getMessage());
		  }
		return false;
	}
	
	private static String constructTicketStatusEmail(String ticketNumber, String custEmail, String logo) {
		
		String tmpBody = EmailTemplate.TICKET_STATUS_EMAIL_TEMPLATE;
		tmpBody = tmpBody.replaceAll("##custEmail##", custEmail);
		tmpBody = tmpBody.replaceAll("##ticketNumber##", ticketNumber);
		tmpBody = tmpBody.replaceAll("##foodCraftLogo##", logo);
		return tmpBody;
	}
	
	
}
