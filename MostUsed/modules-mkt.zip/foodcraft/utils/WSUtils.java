package com.ekfc.foodcraft.utils;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class WSUtils {
    public static List getJsonString2List(String json) throws Exception {
        List list = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            list = (List)mapper.readValue(json, new TypeReference<List>() {

            });
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + "::json:" + json);
        }
        return list;
    }

    public static Object stringToObject(String json, boolean isList) throws Exception {
        Object obj = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            if (isList) {
                obj = mapper.readValue(json, new TypeReference<List<Object>>() {

                });
            } else {
                obj = mapper.readValue(json, new TypeReference<Map<String, Object>>() {

                });
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + ":JSON:" + json);
        }
        return obj;
    }

    public static LinkedHashMap<String, Object> getMap(String json) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        LinkedHashMap<String, Object> map = new LinkedHashMap();
        try {
            map = (LinkedHashMap<String, Object>)mapper.readValue(json, new TypeReference<Map<String, String>>() {

            });
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + ":JSON:" + json);
        }
        return map;
    }

    public static String getJSONString(Object target) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        StringBuffer jsonString = new StringBuffer();
        try {
            jsonString.append(mapper.defaultPrettyPrintingWriter().writeValueAsString(target));
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + ":ObjectJSON:" + target);
        }
        return jsonString.toString();
    }

    public static String getJsonString(Map map) throws Exception {
        String mapAsJson = "";
        try {
            mapAsJson = (new ObjectMapper()).writeValueAsString(map);
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + ":MapObjectJSON:" + map);
        }
        return mapAsJson;
    }

    public static String getJsonStringFlist(List list) throws Exception {
        String jsondata = "";
        try {
            ObjectMapper mapper = new ObjectMapper();
            jsondata = mapper.writeValueAsString(list);
        } catch (Exception ex) {
            throw new Exception(ex.getMessage() + ":ListObjectJSON:" + list);
        }
        return jsondata;
    }
}
