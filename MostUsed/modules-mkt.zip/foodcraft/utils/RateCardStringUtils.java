package com.ekfc.foodcraft.utils;

public class RateCardStringUtils {

    public static boolean isNotBlank(String string){
        if( null != string && string != ""){
            return true;
        }
        return false;
    }
}
