package com.ekfc.foodcraft.utils;

import com.ekfc.foodcraft.dao.CategoryDAO;
import com.ekfc.foodcraft.model.Category;
import com.ekfc.foodcraft.model.Product;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class ProductUtils {

    @Autowired
    private CategoryDAO categoryDAO;

    public void createJsonLoad(final List<Product> menuList) throws IOException {

        final ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        // List<Product> menuList = om.readValue(menu, om.getTypeFactory().constructCollectionType(List.class, Product.class));
        findAndPrintIncompleteInformation(menuList);
        Map<String, List<Map<String, Object>>> finalMenuMap = new HashMap<>();
        for(Product prd: menuList){
            Map<String, Object> menuValue = om.convertValue(prd, Map.class);
            Object image1 = menuValue.get("image1");
            Object image2 = menuValue.get("image2");
            Object image3 = menuValue.get("image3");
            Object image4 = menuValue.get("image4");
            List<String> pathList = new ArrayList<>();
            if(image1 != null){
                pathList.add(image1.toString());
            }
            if(image2 != null){
                pathList.add(image2.toString());
            }
            if(image3 != null){
                pathList.add(image3.toString());
            }
            if(image4 != null){
                pathList.add(image4.toString());
            }

            menuValue.put("path", pathList);
            String category = "unknown";
            String tmpCat = (menuValue.get("categories") != null) ? menuValue.get("categories").toString() : "";

            tmpCat = decodeEncodedValue(tmpCat);
            String[] cSplit = tmpCat.split(">");
            List<String> categoriesList = new ArrayList<>();
            for(String subc: cSplit){
                    if(StringUtils.hasText(subc)){
                        category = subc.strip();
                        String initialCat = (menuValue.get("categories") != null)? menuValue.get("categories").toString(): "";
                        initialCat = decodeEncodedValue(initialCat);
                        menuValue.put("categories_list", getCatListString(initialCat));
                    }
                    List<Map<String, String>> variants = new ArrayList<>();
                    Map<String, String> variant = new HashMap<>();
                    String name = menuValue.get("name").toString();
                    String itemCode = menuValue.get("code").toString();
                    String uom = getUom(name);
                    String price = (menuValue.get("basePrice") != null) ? menuValue.get("basePrice").toString(): "0";
                    String salePrice = (menuValue.get("salesPrice") != null) ? menuValue.get("salesPrice").toString(): "";
                    if(price == ""){
                        price = "AED 0.00";
                    }else{
                        double priceDouble = Double.valueOf(price);
                        price = "AED " + String.format("%.2f", priceDouble);
                    }
                    if(salePrice != ""){
                        double salePriceDouble = Double.valueOf(salePrice);
                        salePrice = "AED " + String.format("%.2f", salePriceDouble);
                    }
                    // adding variant with uom, fcode, price, sale price
                    variant.put("uom", uom);
                    variant.put("sale", salePrice);
                    variant.put("price", price);
                    variant.put("itemCode", itemCode);
                    variants.add(variant);
                    menuValue.put("variant", variants);
                    if(finalMenuMap.containsKey(category)){
                        List<Map<String, Object>> tempList = finalMenuMap.get(category);
                        boolean tempFond = false;
                        for(Map<String, Object> tmpListMap: tempList){
                            if(tmpListMap.get("code").toString().equalsIgnoreCase(menuValue.get("code").toString())){
                                tempFond = true;
                                break;
                            }
                        }
                        if(!tempFond){
                            tempList.add(menuValue);
                        }
                    }else{
                        List<Map<String, Object>> newList = new ArrayList<>();
                        newList.add(menuValue);
                        finalMenuMap.put(category, newList);
                    }
            }
        }
        List<Map<String, Object>> ultimateFinalList = new ArrayList<>();
        for(Map.Entry e: finalMenuMap.entrySet()){
            Map<String, Object> ultiTmpMap = new HashMap<>();
            ultiTmpMap.put("category", e.getKey().toString());
            // sort products based on their order number
            List<Map<String, Object>> vals = (List<Map<String, Object>>) e.getValue();
            ultiTmpMap.put("products", vals);
            ultimateFinalList.add(ultiTmpMap);
        }

        om.writeValue(Paths.get("product_menu.json").toFile(), ultimateFinalList);
    }

    public List<Map<String, Object>> publishJsonLoad(final List<Product> menuList) throws IOException {

        final ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        // List<Product> menuList = om.readValue(menu, om.getTypeFactory().constructCollectionType(List.class, Product.class));
        findAndPrintIncompleteInformation(menuList);
        final List<Map<String, Object>> menuMapList = new ArrayList<>();
        for(Product prd: menuList){
            Map<String, Object> menuValue = om.convertValue(prd, Map.class);
            if(null != prd.getPath()){
                final List<String> pathList = Arrays.asList(prd.getPath().split(","));
                menuValue.put("path", pathList);
            }else{
                menuValue.put("path", new ArrayList<>());
            }
            if(prd.getOrderJson() != null) {
                menuValue.put("orderJson", (Map<String, Integer>) om.readValue(prd.getOrderJson(), Map.class));
            }
            String nutriPath = prd.getNutriFacts();
            if(nutriPath == null){
                nutriPath = "";
            }

            if(null != prd.getDynamicAttributes()) {
                final List<Map<String, Object>> dynamicAttrs = om.readValue(
                        prd.getDynamicAttributes(),
                        om.getTypeFactory().constructCollectionType(List.class, Map.class)
                );
                menuValue.put("dynamicAttributes", dynamicAttrs);
            }else{
                menuValue.put("dynamicAttributes", new ArrayList<>());
            }
            final List<String> nutriList = Arrays.asList(nutriPath.split(","));
            menuValue.put("nutriFacts", nutriList);
            String category = "unknown";
            String tmpCat = (menuValue.get("categories") != null) ? menuValue.get("categories").toString() : "";

            tmpCat = decodeEncodedValue(tmpCat);
            String[] cSplit = tmpCat.split(">");
            List<String> categoriesList = new ArrayList<>();
            for(String subc: cSplit){
                if(StringUtils.hasText(subc)){
                    category = subc.strip();
                    String initialCat = (menuValue.get("categories") != null)? menuValue.get("categories").toString(): "";
                    initialCat = decodeEncodedValue(initialCat);
                    menuValue.put("categories_list", getCatListString(initialCat));
                }
                List<Map<String, String>> variants = new ArrayList<>();
                Map<String, String> variant = new HashMap<>();
                String name = menuValue.get("name").toString();
                String itemCode = menuValue.get("code").toString();
                String uom = getUom(name);
                String price = (menuValue.get("basePrice") != null) ? menuValue.get("basePrice").toString(): "0";
                String salePrice = (menuValue.get("salesPrice") != null) ? menuValue.get("salesPrice").toString(): "";
                if(price == ""){
                    price = "AED 0.00";
                }else{
                    double priceDouble = Double.valueOf(price);
                    price = "AED " + String.format("%.2f", priceDouble);
                }
                if(salePrice != ""){
                    double salePriceDouble = Double.valueOf(salePrice);
                    salePrice = "AED " + String.format("%.2f", salePriceDouble);
                }
                // adding variant with uom, fcode, price, sale price
                variant.put("uom", uom);
                variant.put("sale", salePrice);
                variant.put("price", price);
                variant.put("itemCode", itemCode);
                variants.add(variant);
                menuValue.put("variant", variants);

            }
            menuMapList.add(menuValue);
        }
        // om.writeValue(Paths.get("product_menu.json").toFile(), ultimateFinalList);
        return menuMapList;
    }

    private static void findAndPrintIncompleteInformation(List<Product> menuList) throws JsonProcessingException {
        List<Map<String, String>> fnlList = new ArrayList<>();
        for(Product mp: menuList){
            Map<String, String> mpp = new HashMap<>();
            List<String> reasonList = new ArrayList<>();
            String btmDesc = (mp.getBtmdesc() != null) ? mp.getBtmdesc(): "N/A";
            String mainDesc = (mp.getMaindesc() != null ) ? mp.getMaindesc(): "N/A";
            String stock = (mp.getStock() != null) ? mp.getStock(): "N/A";
            Double price = mp.getBasePrice();
            String categories = (mp.getCategories() != null) ? mp.getCategories(): "N/A";
            String additionInfo = (mp.getAdditioninfo() != null) ? mp.getAdditioninfo(): "N/A";
            // changing the below to to directly fetch from UOM.
            // String uom = getUom(mp.getName());
            String uom = mp.getUom();
            String code = mp.getCode();

            if(uom == "EA"){
                reasonList.add("The UOM is not available");
            }
            if(btmDesc == null || btmDesc == ""){
                reasonList.add("The Bottom Desc(btmdesc) is not available");
            }

            if(mainDesc == null || mainDesc == ""){
                reasonList.add("The Main Desc(maindesc) is not available");
            }
            if(stock == null || stock == ""){
                reasonList.add("The Stock is not available");
            }
            if(price == null || price == 0d){
                reasonList.add("The Regular Price is not available");
            }
            if(categories == null || categories == ""){
                reasonList.add("The Categories are not available");
            }
            if(additionInfo == null || additionInfo == ""){
                reasonList.add("The Additional information or the Information about the ingredients could be missing");
            }

            mpp.put("code", code);
            mpp.put("remarks", String.join(", ", reasonList));
            fnlList.add(mpp);
        }

        ObjectMapper om = new ObjectMapper();
        System.out.println(om.writeValueAsString(fnlList));
    }

    private static String getUom(String name){
        String uom = "EA";
        Pattern p = Pattern.compile("(\\(\\s*\\d*\\s*(Pieces|pieces|piece|Piece)?\\s*[xX]?\\s*\\d*\\.?\\-?\\d*\\s*[gG][mM]\\s*\\)|\\(\\s*\\d*\\s*[xX]?\\s*\\d*\\.?\\s*\\-?\\s*\\d*\\.?\\d*\\s*[kK][gG]\\s*\\)|\\(\\s*\\d*\\s*[xX]?\\s*\\d*\\.?\\-?\\d*\\s*[mM]?[lL]\\s*(tub|Tub|tubs|Tubs)?\\)|\\(\\s*\\d*\\s*(pieces|piece|Piece|Pieces)\\s*\\)|\\(\\s*(serves|serve|Serve|Serves).*\\)|\\d+\\s*(gm|GM|Gm)\\s*\\(\\s*\\d*\\s*(pack|Pack|packs|Packs)\\s*\\)|\\(\\s*\\d*\\s*(pack|Pack|packs|Packs)\\s*\\)|\\(\\s*\\d*\\s*(course meal|Course meal|Course Meal)\\s*\\,?\\s*(serves|serve|Serve|Serves).*\\)|\\d*\\.?\\d*\\s*(gm|Gm|GM|kg|Kg|KG|ML|ml|Ml)\\s*|\\(\\s*\\d*\\s*(cups|Cups|cup|Cup)\\s*\\))");
        Matcher m = p.matcher(name);

        if(m.find()){
            // System.out.println(name + " : : " + m.group(1));
            uom = m.group(1);
        }
        if(uom == "EA"){
            // System.out.println(name);
        }
        return uom;
    }

    private  String getCatListString(String catt){
        String[] cSplit = catt.split(" > ");
        String category = "uncategorized";
        List<String> categoriesList = new ArrayList<>();
        for(String subc: cSplit) {
                String extractedCat = subc.strip();
                category = extractedCat;
                final Category categoryModel = categoryDAO.getCategoryForId(category);
                String categoryName = "Uncategorized";
                if(categoryModel != null){
                    categoryName = categoryModel.getCategoryName();
                }
                categoriesList.add(
                        "<a href='#' class='product-list custom-fc-cat-link' data-menu-cat='" + category + "'>" + categoryName + "</a>"
                );
        }
        return String.join(", ", categoriesList);
    }

    public  String decodeEncodedValue(String val){
        val = val.replaceAll("%u2019", "`");
        val = val.replaceAll("%u2013", "-");
        val = val.replaceAll("%u2014", "-");
        val = val.replaceAll("%u2022", "•");
        val = URLDecoder.decode(val);
        return val;
    }

    public List<Map<String, Object>> transformProducts(final List<Product> menuList) throws IOException {

        final ObjectMapper om = new ObjectMapper();
        om.configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true);
        final List<Map<String, Object>> menuValueList = new ArrayList<>();
        for(Product prd: menuList){
            Map<String, Object> menuValue = om.convertValue(prd, Map.class);
            if(null != prd.getPath()){
                final List<String> pathList = Arrays.asList(prd.getPath().split(","));
                menuValue.put("path", pathList);
            }else{
                menuValue.put("path", new ArrayList<>());
            }
            if(prd.getOrderJson() != null) {
                menuValue.put("orderJson", (Map<String, Integer>) om.readValue(prd.getOrderJson(), Map.class));
            }
            String nutriPath = prd.getNutriFacts();
            if(nutriPath == null){
                nutriPath = "";
            }

            if(null != prd.getDynamicAttributes()) {
                final List<Map<String, Object>> dynamicAttrs = om.readValue(
                        prd.getDynamicAttributes(),
                        om.getTypeFactory().constructCollectionType(List.class, Map.class)
                );
                menuValue.put("dynamicAttributes", dynamicAttrs);
            }else{
                menuValue.put("dynamicAttributes", new ArrayList<>());
            }
            final List<String> nutriList = Arrays.asList(nutriPath.split(","));
            menuValue.put("nutriFacts", nutriList);
            String initialCat = (menuValue.get("categories") != null)? menuValue.get("categories").toString(): "";
            initialCat = decodeEncodedValue(initialCat);
            menuValue.put("categories_list", getCatListString(initialCat));

            List<Map<String, String>> variants = new ArrayList<>();
            Map<String, String> variant = new HashMap<>();
            String name = menuValue.get("name").toString();
            String itemCode = menuValue.get("code").toString();
            String uom = getUom(name);
            String price = (menuValue.get("basePrice") != null) ? menuValue.get("basePrice").toString(): "0";
            String salePrice = (menuValue.get("salesPrice") != null) ? menuValue.get("salesPrice").toString(): "";
            if(price == ""){
                price = "AED 0.00";
            }else{
                double priceDouble = Double.valueOf(price);
                price = "AED " + String.format("%.2f", priceDouble);
            }
            if(salePrice != ""){
                double salePriceDouble = Double.valueOf(salePrice);
                salePrice = "AED " + String.format("%.2f", salePriceDouble);
            }
            // adding variant with uom, fcode, price, sale price
            variant.put("uom", uom);
            variant.put("sale", salePrice);
            variant.put("price", price);
            variant.put("itemCode", itemCode);
            variants.add(variant);
            menuValue.put("variant", variants);
            menuValueList.add(menuValue);
        }
        // om.writeValue(Paths.get("product_menu.json").toFile(), ultimateFinalList);
        return menuValueList;
    }
}
