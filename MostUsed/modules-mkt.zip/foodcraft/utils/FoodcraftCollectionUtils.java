package com.ekfc.foodcraft.utils;

import java.util.List;

public class FoodcraftCollectionUtils {

    public static boolean isNotEmpty(List someList){
        if(someList != null && someList.size() > 0){
            return true;
        }
        return false;
    }
    
    public static double returnTwoDeciamlPlacesForDouble(double value) {
		return Double.valueOf(String.format("%.2f", value));
	}
}
