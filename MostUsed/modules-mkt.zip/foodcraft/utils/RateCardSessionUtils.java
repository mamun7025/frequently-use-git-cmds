package com.ekfc.foodcraft.utils;

import java.util.Map;

public class RateCardSessionUtils {

    public static boolean checkSessionKeysPresent(Map<String, Object> requestData){
        if(requestData.containsKey("user") &&
                requestData.containsKey("guid1") &&
                requestData.containsKey("guid2") &&
                requestData.containsKey("guid3") &&
                requestData.containsKey("guid4")){
            return true;
        }
        return false;
    }
}
