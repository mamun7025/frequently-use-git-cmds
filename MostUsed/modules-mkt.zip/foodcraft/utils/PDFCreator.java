package com.ekfc.foodcraft.utils;


import com.ekfc.foodcraft.model.OrdersDetails;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.util.*;

import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.WebColors;
public class PDFCreator {

	public static void main(String[] args) {
		Map<String, Object> mp=new HashMap<String, Object>();
		mp.put("pdfFileName","C:/GIT/VITE-B2C.wiki/rate-card/invoice/result-test.pdf");
		mp.put("totalAmount","500.33");
		mp.put("invoice_id","Test invoice id123");
		mp.put("totalAmount","4442.44");
		mp.put("user_id","Test user id");
		mp.put("totalAmount","52.55");
		mp.put("vatAmount","22.55");
		mp.put("paymentAmmount","888.555");
		List<OrdersDetails> lst=new ArrayList<OrdersDetails>();
		OrdersDetails od1=new OrdersDetails(1,"Tst itm","Test catering","Test package"
		,"KG","Test brand","test orgin",4,"Test KG",55,"Test Cart 1234", "F324234","Test Created on", "Test item case");
		lst.add(od1);
		mp.put("cartDetails",lst);
		try {
			new PDFCreator().createInvoice(mp);
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("OK");
	}

	/*
	* {
	*pdfFileName
	* totalAmount
	 * invoice_id
	 * totalAmount
	 * user_id
	 * totalAmount
	 * cartDetails = [OrdersDetails]
	 * vatAmount
	 * paymentAmmount
	* }
	* */
	public void createInvoice(Map<String,Object> map) throws DocumentException, IOException {
		
		
		Document document = new Document(PageSize.A4, 60, 60, 60, 60);
          Locale locale = new Locale("fr", "FR");
		  DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.DEFAULT, locale);
		  String date = dateFormat.format(new Date());
		  System.out.print(date);
		  
		  StringBuilder builder = new StringBuilder("Name: Majid Soliman\n");
		  builder.append("Address:  Dubai,UAE\n");
		  builder.append("Company name: Name\n");
		  
		  StringBuilder builder2 = new StringBuilder("Invoice N0: 58755\n");
		  builder2.append("Invoice Date: "+date+"\n");
		  builder2.append("Delivering date: 025/55/2021\n");
		 
	        // 2. Create PdfWriter
	        PdfWriter.getInstance(document, new FileOutputStream(map.get("pdfFileName").toString()));
             
	        // 3. Open document
	        document.open();
	        
	        Paragraph emptyP=new Paragraph("\n");

	        // 4. Add content
	        Image img = Image.getInstance("C:/GIT/VITE-B2C.wiki/rate-card/html-storefront/assets/images/logo/logo-large.png");
	        //img.setAbsolutePosition(10f, 850f);
	        //Scale to new height and new width of image
	        img.scaleAbsolute(60, 40);
	        document.add(img);
	        
	        Font largeBold = new Font(Font.FontFamily.TIMES_ROMAN, 10,Font.BOLD);
	        Font midiamBold = new Font(Font.FontFamily.TIMES_ROMAN, 8,Font.BOLD);
	        Font tableFont = new Font(Font.FontFamily.TIMES_ROMAN,9);
	        Font smallItalic = new Font(Font.FontFamily.TIMES_ROMAN, 10);
	        Font smallItalic2 = new Font(Font.FontFamily.TIMES_ROMAN, 7);
	           
	        Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.ITALIC | Font.UNDERLINE, BaseColor.RED);
            Font blueFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.ITALIC , BaseColor.BLUE);
            Font tableHeaderFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD, BaseColor.BLUE);

            Paragraph mainP=new Paragraph("Tax Invoice",largeBold);
            mainP.setAlignment(Element.ALIGN_CENTER);
	        
	        document.add(mainP);
	        document.add(emptyP);

	        PdfPTable table = new PdfPTable(2);
	        
	        table.setWidthPercentage(100);
	        PdfPCell cell = new PdfPCell(new Phrase(builder.toString(),smallItalic));
	        
	        cell = new PdfPCell(new Phrase("Supplier:  "+map.get("totalAmount").toString(),smallItalic));
	        cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);

	        

	        cell = new PdfPCell(new Phrase("Invoice-ID:  "+map.get("invoice_id").toString(),smallItalic));
	        cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);
	        
          
	        cell = new PdfPCell(new Phrase("Supplier:  "+map.get("totalAmount").toString(),smallItalic));
	        cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);

	        
	        
	        cell = new PdfPCell(new Phrase("Name of cunsomer:  "+map.get("user_id").toString(),smallItalic));
	        cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);

	        
	        cell = new PdfPCell(new Phrase("Customer:  "+map.get("totalAmount").toString(),smallItalic));
	        cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);
		    
		    cell = new PdfPCell(new Phrase("Invoice Date: "+new Date(),smallItalic));
		    cell.setBorder(Rectangle.NO_BORDER);
	        table.addCell(cell);
		    
            cell = new PdfPCell(new Phrase(""));
	 	    cell.setBorder(Rectangle.BOTTOM);
		    cell.setBorderWidthBottom(1f);
	        table.addCell(cell);
  
	        cell = new PdfPCell(new Phrase(""));
	        cell.setBorder(Rectangle.BOTTOM);
		    cell.setBorderWidthBottom(1f);
		    table.addCell(cell);
		    
		    BaseColor headerColor = WebColors.getRGBColor("#D3D3D3");

	        PdfPTable dTable = new PdfPTable(8);
	        dTable.setWidthPercentage(100);
	        
	        PdfPCell dCell = new PdfPCell(new Phrase("Name\n", midiamBold));
	        dCell.setBackgroundColor(headerColor);
	        //dCell.setBorder(Rectangle.NO_BORDER); 	        
	        dCell.setBorder(Rectangle.BOTTOM);
	       // dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	        
	        dCell.setPhrase(new Phrase("Quantity\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
	        //dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	        
	        dCell.setPhrase(new Phrase("Unit price\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
	        //dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	     
	        dCell.setPhrase(new Phrase("Price\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
	        //dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	        
	        dCell.setPhrase(new Phrase("Discount\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
	        //dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	     
	        dCell.setPhrase(new Phrase("Rate of tax\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
	       // dCell.setBorderWidthBottom(1f);
	        dTable.addCell(dCell);
	        
	        dCell.setPhrase(new Phrase("Tax amount\n", midiamBold));
	       // dCell.setBorder(Rectangle.BOTTOM);
	        dTable.addCell(dCell);
	        
	        dCell.setPhrase(new Phrase("Total amount\n", midiamBold));
	        dCell.setBorder(Rectangle.BOTTOM);
			dTable.addCell(dCell);

	    	List<Map<String, Object>> detailsList = (List<Map<String, Object>>) map.get("cartDetails");
			System.out.println("Single details is: "+ ((OrdersDetails)(detailsList.get(0))).getDescription() );
		   
			for(int i=0;i<detailsList.size();i++) {
				dCell.setPhrase(new Phrase(((OrdersDetails)(detailsList.get(i))).getDescription(),smallItalic2));
				dCell.setBorder(Rectangle.BOTTOM);
				
				dCell.setBackgroundColor(BaseColor.WHITE);
				dTable.addCell(dCell);
				
				
				dCell.setPhrase(new Phrase(((OrdersDetails)(detailsList.get(i))).getQuanity()+"",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase(((OrdersDetails)(detailsList.get(i))).getPricingUom()+"",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase(((OrdersDetails)(detailsList.get(i))).getSalesprice()+"",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase("0",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase("0%",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase("400",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
				
				dCell.setPhrase(new Phrase("13000",tableFont));
				dCell.setBackgroundColor(BaseColor.WHITE);
				
				dTable.addCell(dCell);
			}

		PdfPCell eCell;
			   eCell = new PdfPCell(new Phrase("Total-tax :      "+map.get("vatAmount").toString(),smallItalic));
			   eCell.setColspan(8);
			   eCell.setBorder(Rectangle.NO_BORDER);
			   
			   dTable.addCell(eCell);
			   
			   eCell = new PdfPCell(new Phrase("Invoice-total :      "+map.get("totalAmount").toString(),smallItalic));
			   eCell.setColspan(8);
			   eCell.setBorder(Rectangle.NO_BORDER);
			   
			   dTable.addCell(eCell);
			   
			   eCell = new PdfPCell(new Phrase("Total-amount :      "+map.get("paymentAmmount").toString()+"\n",smallItalic));
			   eCell.setColspan(8);
			   eCell.setBorder(Rectangle.NO_BORDER);
			   
			   dTable.addCell(eCell);
		
		       eCell = new PdfPCell(new Phrase(""));
			   eCell.setColspan(8);
			   eCell.setBorder(Rectangle.BOTTOM);
			   eCell.setBorderWidthBottom(1f);
			 
			   dTable.addCell(eCell);
				 
               document.add(table);
	           document.add(emptyP);
	        document.add(dTable);
	        // 5. Close document
	        document.close();


	}

}
