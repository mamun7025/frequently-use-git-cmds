package com.ekfc.foodcraft.model;

public class OrdersDetails {

	private int id;
	private String description;
	private String category;
	private String packaging;
	private String uom;
	private String brand;
	private String orgin;
	private double salesprice;
	private double baseprice;	
	private double quanity;
	private String pricingUom;
	private String cartnumber;
	private String p_code;
	private String created_on;
	
	private String creatd_by;
	private String updaed_on;
	private String updated_by;
	private String itemCase;
	private String status;


	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OrdersDetails(int id,String description, String category, String packaging, String uom,
			String brand, String origin, double quantity, String pricingUom, double salesprice, double baseprice, String cartnumber, String p_code, String created_on,String itemCase ) {
		
		this.id = id;
		this.description = description;
		this.category = category;
		this.packaging = packaging;
		this.uom = uom;
		this.brand = brand;
		this.orgin = origin;
		this.quanity = quantity;
		this.pricingUom = pricingUom;
		this.salesprice = salesprice;
		this.baseprice = baseprice;
		this.cartnumber = cartnumber;
	    this.p_code = p_code;
	    this.created_on = created_on;
	    this.itemCase = itemCase;
		}
	
	public OrdersDetails(int id,String description, String category, String packaging, String uom,
			String brand, String origin, double quantity, String pricingUom, double salesprice, String cartnumber, String p_code, String created_on,String itemCase ) {
		
		this.id = id;
		this.description = description;
		this.category = category;
		this.packaging = packaging;
		this.uom = uom;
		this.brand = brand;
		this.orgin = origin;
		this.quanity = quantity;
		this.pricingUom = pricingUom;
		this.salesprice = salesprice;
		this.cartnumber = cartnumber;
	    this.p_code = p_code;
	    this.created_on = created_on;
	    this.itemCase = itemCase;
		}
	
	public OrdersDetails(String description, String category, String packaging, String uom,
			String brand, String origin, int quantity, String pricingUom, double salesprice, double baseprice, String p_code, int id) {
		this.description = description;
		this.category = category;
		this.packaging = packaging;
		this.uom = uom;
		this.brand = brand;
		this.orgin = origin;
		this.quanity = quantity;
		this.pricingUom = pricingUom;
		this.salesprice = salesprice;
		this.baseprice = baseprice;
		this.p_code = p_code;
	    this.id= id;
		}
	
	public OrdersDetails(String description, String category, String packaging, String uom,
			String brand, String origin, int quantity, String pricingUom, double salesprice, double baseprice, String p_code, int id, String status ) {
		this.description = description;
		this.category = category;
		this.packaging = packaging;
		this.uom = uom;
		this.brand = brand;
		this.orgin = origin;
		this.quanity = quantity;
		this.pricingUom = pricingUom;
		this.salesprice = salesprice;
		this.baseprice = baseprice;
		this.p_code = p_code;
	    this.id= id;
	    this.status = status;
		}
    	//newly added
	public OrdersDetails(String description, String category, String packaging, String uom, String origin, int quantity, String pricingUom, double salesprice, double baseprice, String p_code, int id,String created_on ) {
		this.description = description;
		this.category = category;
		this.packaging = packaging;
		this.uom = uom;
		this.orgin = origin;
		this.quanity = quantity;
		this.pricingUom = pricingUom;
		this.salesprice = salesprice;
		this.baseprice = baseprice;
		this.p_code = p_code;
	    this.id= id;
	    this.created_on = created_on;
		}
    
	//Payment details
	public OrdersDetails(String description ,double salesprice) {
		this.description = description;
		this.salesprice = salesprice;
	}
	
	public OrdersDetails(String description , int quantity, double salesprice) {
		this.description = description;
		this.salesprice = salesprice;
		this.quanity = quantity;
	}

	//get Count for duplicate entry
	public OrdersDetails(String p_code ,String cartnumber, int id, int quanity) {
		this.p_code = p_code;
		this.cartnumber = cartnumber;
		this.id = id;
		this.quanity= quanity;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPackaging() {
		return packaging;
	}

	public void setPackaging(String packaging) {
		this.packaging = packaging;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getOrgin() {
		return orgin;
	}

	public void setOrgin(String orgin) {
		this.orgin = orgin;
	}

	public double getSalesprice() {
		return salesprice;
	}

	public void setSalesprice(double salesprice) {
		this.salesprice = salesprice;
	}

	public String getPricingUom() {
		return pricingUom;
	}

	public void setPricingUom(String pricingUom) {
		this.pricingUom = pricingUom;
	}

	public String getCartnumber() {
		return cartnumber;
	}

	public void setCartnumber(String cartnumber) {
		this.cartnumber = cartnumber;
	}

	
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}	
	public double getQuanity() {
		return quanity;
	}
	public void setQuanity(double quanity) {
		this.quanity = quanity;
	}

	public String getP_code() {
		return p_code;
	}

	public void setP_code(String p_code) {
		this.p_code = p_code;
	}public String getCreated_on() {
		return created_on;
	}

	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}

	public String getCreatd_by() {
		return creatd_by;
	}

	public void setCreatd_by(String creatd_by) {
		this.creatd_by = creatd_by;
	}

	public String getUpdaed_on() {
		return updaed_on;
	}

	public void setUpdaed_on(String updaed_on) {
		this.updaed_on = updaed_on;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	public String getItemCase() {
		return itemCase;
	}

	public void setItemCase(String itemCase) {
		this.itemCase = itemCase;
	}

	public double getBaseprice() {
		return baseprice;
	}

	public void setBaseprice(double baseprice) {
		this.baseprice = baseprice;
	}

	
	
}
