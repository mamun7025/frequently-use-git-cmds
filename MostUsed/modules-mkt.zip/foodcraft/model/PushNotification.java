package com.ekfc.foodcraft.model;

public class PushNotification {

    private Integer notificationId;
    private String title;
    private String description;
    private String redirectUrl;
    private String image64Str;

    private String creationDateTime;

    public PushNotification(){
    }
    public PushNotification(Integer notificationId, String title, String description, String redirectUrl, String image64Str) {
        this.notificationId = notificationId;
        this.title = title;
        this.description = description;
        this.redirectUrl = redirectUrl;
        this.image64Str = image64Str;
    }

    public Integer getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(Integer notificationId) {
        this.notificationId = notificationId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getImage64Str() {
        return image64Str;
    }

    public void setImage64Str(String image64Str) {
        this.image64Str = image64Str;
    }

    public String getCreationDateTime() {
        return creationDateTime;
    }

    public void setCreationDateTime(String creationDateTime) {
        this.creationDateTime = creationDateTime;
    }
}
