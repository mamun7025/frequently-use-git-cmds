package com.ekfc.foodcraft.model;

public class OrderReport {
	private int orderNumber;
	private String deliverySlots;
	private String deliveryDate;
	private String paymentMode;
	private String status;
	private String firstName;
	private String lastName;
	private double totalAmount;
	private String createdOn;
	private String note;
	private double deliverFee;
	private double processingFee;
	private String shippingAddress;
	private String streetName;
	private String landmark;
	private String city;
	private String productCode;
	private String productDesc;
	private String quantity;
	private String price;
	
	
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public int getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getDeliverySlots() {
		return deliverySlots;
	}
	public void setDeliverySlots(String deliverySlots) {
		this.deliverySlots = deliverySlots;
	}
	public String getDeliveryDate() {
		return deliveryDate;
	}
	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	
	public OrderReport(int orderNumber, String deliverySlots, String deliveryDate, String paymentMode, String status,
			String firstName, String lastName, double totalAmount, String createdOn) {
		super();
		this.orderNumber = orderNumber;
		this.deliverySlots = deliverySlots;
		this.deliveryDate = deliveryDate;
		this.paymentMode = paymentMode;
		this.status = status;
		this.firstName = firstName;
		this.lastName = lastName;
		this.totalAmount = totalAmount;
		this.createdOn = createdOn;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public double getDeliverFee() {
		return deliverFee;
	}
	public void setDeliverFee(double deliverFee) {
		this.deliverFee = deliverFee;
	}
	public double getProcessingFee() {
		return processingFee;
	}
	public void setProcessingFee(double processingFee) {
		this.processingFee = processingFee;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public OrderReport(int orderNumber, String deliverySlots, String deliveryDate, String paymentMode,
			double totalAmount, String createdOn, String note, double deliverFee, double processingFee,
			String shippingAddress, String streetName, String landmark, String city, String productCode, String productDesc, String quantity, String price) {
		super();
		this.orderNumber = orderNumber;
		this.deliverySlots = deliverySlots;
		this.deliveryDate = deliveryDate;
		this.paymentMode = paymentMode;
		this.totalAmount = totalAmount;
		this.createdOn = createdOn;
		this.note = note;
		this.deliverFee = deliverFee;
		this.processingFee = processingFee;
		this.shippingAddress = shippingAddress;
		this.streetName = streetName;
		this.landmark = landmark;
		this.city = city;
		this.productCode = productCode;
		this.productDesc = productDesc;
		this.quantity = quantity;
		this.price = price;
	}
	
	
	
}
