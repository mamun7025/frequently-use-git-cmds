package com.ekfc.foodcraft.model;


public class Wallet {

    private Integer walletId;
    private String walletEmail;
    private Double balance;

    // logs
    private String creationDateTime;
    private String creationUser;
    private String lastUpdateDateTime;
    private String lastUpdateUser;

    public Wallet(){
    }

    public Wallet(Integer walletId, String walletEmail, Double balance, String creationDateTime, String creationUser, String lastUpdateDateTime, String lastUpdateUser) {
        this.walletId = walletId;
        this.walletEmail = walletEmail;
        this.balance = balance;
        this.creationDateTime = creationDateTime;
        this.creationUser = creationUser;
        this.lastUpdateDateTime = lastUpdateDateTime;
        this.lastUpdateUser = lastUpdateUser;
    }

    public Integer getWalletId() {
        return walletId;
    }

    public void setWalletId(Integer walletId) {
        this.walletId = walletId;
    }

    public String getWalletEmail() {
        return walletEmail;
    }

    public void setWalletEmail(String wallet_email) {
        this.walletEmail = wallet_email;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }

    public String getCreationDateTime() {
        return creationDateTime;
    }

    public void setCreationDateTime(String creationDataTime) {
        this.creationDateTime = creationDataTime;
    }

    public String getCreationUser() {
        return creationUser;
    }

    public void setCreationUser(String creationUser) {
        this.creationUser = creationUser;
    }

    public String getLastUpdateDateTime() {
        return lastUpdateDateTime;
    }

    public void setLastUpdateDateTime(String lastUpdateDateTime) {
        this.lastUpdateDateTime = lastUpdateDateTime;
    }

    public String getLastUpdateUser() {
        return lastUpdateUser;
    }

    public void setLastUpdateUser(String lastUpdateUser) {
        this.lastUpdateUser = lastUpdateUser;
    }


}
