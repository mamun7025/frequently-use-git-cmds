package com.ekfc.foodcraft.model;

public class LoyaltyEarnBurnModel {

	private int id;
	private String type;
	private double points;
	private double price;
	private boolean active;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getPoints() {
		return points;
	}
	public void setPoints(double points) {
		this.points = points;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public boolean getActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	
	public LoyaltyEarnBurnModel(int id, String type, double points, double price, boolean active) {
		super();
		this.id = id;
		this.type = type;
		this.points = points;
		this.price = price;
		this.active = active;
	}

	public LoyaltyEarnBurnModel(double points, double price, boolean active, String type) {
		super();
		this.points = points;
		this.price = price;
		this.active = active;
		this.type= type;
	}
	
	
	@Override
	public String toString() {
		return "LoyaltyEarnBurnModel [id=" + id + ", type=" + type + ", points=" + points + ", price=" + price
				+ ", active=" + active + "]";
	}
	public LoyaltyEarnBurnModel() {};
	
}
