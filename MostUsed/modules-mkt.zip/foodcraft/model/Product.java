package com.ekfc.foodcraft.model;

public class Product {

    private long id;
    private String code;
    private String type;
    private String name;
    private String image1;
    private String image1Hdr;
    private String image2;
    private String image2Hdr;
    private String image3;
    private String image3Hdr;
    private String image4;
    private String image4Hdr;
    private String primaryImage;
    private String primaryImageHdr;
    private String uom;
    private double basePrice;
    private double salesPrice;
    private String tag;
    private String categories;
    private String categoriesList;
    private String stock;
    private String inStock;
    private String taxStatus;
    private boolean isFeatured;
    private boolean isLive;
    private boolean isVisible;
    private boolean isPublished;
    private String upSells;
    private String crossSells;
    private String groupedProducts;
    private String attribute1Name;
    private String additioninfo;
    private String btmdesc;
    private String maindesc;
    private String lengthCm;
    private String widthCm;
    private String heightCm;
    private String weightKg;
    private String position;
    private String shippingClass;
    private String rating;
    private String popularity;
    private String path;
    private String nutriFacts;
    private int minOrderedQty;
    private int maxOrderedQty;
    private int minOrderedValue;
    private int maxOrderedValue;
    private String dynamicAttributes;
    private String orderJson;

    public Product() {
    }

    public Product(long id, String code, String type, String name, String image1, String image1Hdr,
                   String image2, String image2Hdr, String image3, String image3Hdr, String image4, String image4Hdr,
                   String primaryImage, String primaryImageHdr, String uom, double basePrice, double salesPrice,
                   String tag, String categories, String categoriesList, String stock, String inStock, String taxStatus,
                   boolean isFeatured, boolean isLive, boolean isVisible, boolean isPublished, String upSells,
                   String crossSells, String groupedProducts, String attribute1Name, String additioninfo,
                   String btmdesc, String maindesc, String lengthCm, String widthCm, String heightCm,
                   String weightKg, String position, String shippingClass, String rating, String popularity, String path,
                   String nutriFacts, int minOrderedQty, int maxOrderedQty, int minOrderedValue, int maxOrderedValue, String dynamicAttributes,
                   String orderJson) {
        this.id = id;
        this.code = code;
        this.type = type;
        this.name = name;
        this.image1 = image1;
        this.image1Hdr = image1Hdr;
        this.image2 = image2;
        this.image2Hdr = image2Hdr;
        this.image3 = image3;
        this.image3Hdr = image3Hdr;
        this.image4 = image4;
        this.image4Hdr = image4Hdr;
        this.primaryImage = primaryImage;
        this.primaryImageHdr = primaryImageHdr;
        this.uom = uom;
        this.basePrice = basePrice;
        this.salesPrice = salesPrice;
        this.tag = tag;
        this.categories = categories;
        this.categoriesList = categoriesList;
        this.stock = stock;
        this.inStock = inStock;
        this.taxStatus = taxStatus;
        this.isFeatured = isFeatured;
        this.isLive = isLive;
        this.isVisible = isVisible;
        this.isPublished = isPublished;
        this.upSells = upSells;
        this.crossSells = crossSells;
        this.groupedProducts = groupedProducts;
        this.attribute1Name = attribute1Name;
        this.additioninfo = additioninfo;
        this.btmdesc = btmdesc;
        this.maindesc = maindesc;
        this.lengthCm = lengthCm;
        this.widthCm = widthCm;
        this.heightCm = heightCm;
        this.weightKg = weightKg;
        this.position = position;
        this.shippingClass = shippingClass;
        this.rating = rating;
        this.popularity = popularity;
        this.path = path;
        this.nutriFacts = nutriFacts;
        this.minOrderedQty = minOrderedQty;
        this.maxOrderedQty = maxOrderedQty;
        this.minOrderedValue = minOrderedValue;
        this.maxOrderedValue = maxOrderedValue;
        this.dynamicAttributes = dynamicAttributes;
        this.orderJson = orderJson;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage1() {
        return image1;
    }

    public void setImage1(String image1) {
        this.image1 = image1;
    }

    public String getImage1Hdr() {
        return image1Hdr;
    }

    public void setImage1Hdr(String image1Hdr) {
        this.image1Hdr = image1Hdr;
    }

    public String getImage2() {
        return image2;
    }

    public void setImage2(String image2) {
        this.image2 = image2;
    }

    public String getImage2Hdr() {
        return image2Hdr;
    }

    public void setImage2Hdr(String image2Hdr) {
        this.image2Hdr = image2Hdr;
    }

    public String getImage3() {
        return image3;
    }

    public void setImage3(String image3) {
        this.image3 = image3;
    }

    public String getImage3Hdr() {
        return image3Hdr;
    }

    public void setImage3Hdr(String image3Hdr) {
        this.image3Hdr = image3Hdr;
    }

    public String getImage4() {
        return image4;
    }

    public void setImage4(String image4) {
        this.image4 = image4;
    }

    public String getImage4Hdr() {
        return image4Hdr;
    }

    public void setImage4Hdr(String image4Hdr) {
        this.image4Hdr = image4Hdr;
    }

    public String getPrimaryImage() {
        return primaryImage;
    }

    public void setPrimaryImage(String primaryImage) {
        this.primaryImage = primaryImage;
    }

    public String getPrimaryImageHdr() {
        return primaryImageHdr;
    }

    public void setPrimaryImageHdr(String primaryImageHdr) {
        this.primaryImageHdr = primaryImageHdr;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    public double getSalesPrice() {
        return salesPrice;
    }

    public void setSalesPrice(double salesPrice) {
        this.salesPrice = salesPrice;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
       this.tag = tag;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
       this.categories = categories;
    }

    public String getCategoriesList() {
        return categoriesList;
    }

    public void setCategoriesList(String categoriesList) {
        this.categoriesList = categoriesList;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getInStock() {
        return inStock;
    }

    public void setInStock(String inStock) {
        this.inStock = inStock;
    }

    public String getTaxStatus() {
        return taxStatus;
    }

    public void setTaxStatus(String taxStatus) {
        this.taxStatus = taxStatus;
    }

    public boolean isFeatured() {
        return isFeatured;
    }

    public void setFeatured(boolean featured) {
        isFeatured = featured;
    }

    public boolean isLive() {
        return isLive;
    }

    public void setLive(boolean live) {
        isLive = live;
    }

    public boolean isVisible() {
        return isVisible;
    }

    public void setVisible(boolean visible) {
        isVisible = visible;
    }

    public boolean isPublished() {
        return isPublished;
    }

    public void setPublished(boolean published) {
        isPublished = published;
    }

    public String getUpSells() {
        return upSells;
    }

    public void setUpSells(String upSells) {
        this.upSells = upSells;
    }

    public String getCrossSells() {
        return crossSells;
    }

    public void setCrossSells(String crossSells) {
        this.crossSells = crossSells;
    }

    public String getGroupedProducts() {
        return groupedProducts;
    }

    public void setGroupedProducts(String groupedProducts) {
        this.groupedProducts = groupedProducts;
    }

    public String getAttribute1Name() {
        return attribute1Name;
    }

    public void setAttribute1Name(String attribute1Name) {
        this.attribute1Name = attribute1Name;
    }

    public String getAdditioninfo() {
        return additioninfo;
    }

    public void setAdditioninfo(String additioninfo) {
        this.additioninfo = additioninfo;
    }

    public String getBtmdesc() {
        return btmdesc;
    }

    public void setBtmdesc(String btmdesc) {
        this.btmdesc = btmdesc;
    }

    public String getMaindesc() {
        return maindesc;
    }

    public void setMaindesc(String maindesc) {
        this.maindesc = maindesc;
    }

    public String getLengthCm() {
        return lengthCm;
    }

    public void setLengthCm(String lengthCm) {
        this.lengthCm = lengthCm;
    }

    public String getWidthCm() {
        return widthCm;
    }

    public void setWidthCm(String widthCm) {
        this.widthCm = widthCm;
    }

    public String getHeightCm() {
        return heightCm;
    }

    public void setHeightCm(String heightCm) {
        this.heightCm = heightCm;
    }

    public String getWeightKg() {
        return weightKg;
    }

    public void setWeightKg(String weightKg) {
        this.weightKg = weightKg;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getShippingClass() {
        return shippingClass;
    }

    public void setShippingClass(String shippingClass) {
        this.shippingClass = shippingClass;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getPopularity() {
        return popularity;
    }

    public void setPopularity(String popularity) {
        this.popularity = popularity;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getNutriFacts() {
        return nutriFacts;
    }

    public void setNutriFacts(String nutriFacts) {
        this.nutriFacts = nutriFacts;
    }

    public int getMinOrderedQty() {
        return minOrderedQty;
    }

    public void setMinOrderedQty(int minOrderedQty) {
        this.minOrderedQty = minOrderedQty;
    }

    public int getMaxOrderedQty() {
        return maxOrderedQty;
    }

    public void setMaxOrderedQty(int maxOrderedQty) {
        this.maxOrderedQty = maxOrderedQty;
    }

    public int getMinOrderedValue() {
        return minOrderedValue;
    }

    public void setMinOrderedValue(int minOrderedValue) {
        this.minOrderedValue = minOrderedValue;
    }

    public int getMaxOrderedValue() {
        return maxOrderedValue;
    }

    public void setMaxOrderedValue(int maxOrderedValue) {
        this.maxOrderedValue = maxOrderedValue;
    }

    public String getDynamicAttributes() {
        return dynamicAttributes;
    }

    public void setDynamicAttributes(String dynamicAttributes) {
        this.dynamicAttributes = dynamicAttributes;
    }

    public String getOrderJson() {
        return orderJson;
    }

    public void setOrderJson(String orderJson) {
        this.orderJson = orderJson;
    }
}
