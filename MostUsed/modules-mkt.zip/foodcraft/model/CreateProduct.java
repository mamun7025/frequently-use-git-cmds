package com.ekfc.foodcraft.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class CreateProduct {

    private String code;
    private String name;
    private String type;
    private String uom;
    private double sellingPrice;
    private double basePrice;
    private String crossSells;
    private String upSells;
    private boolean live;
    private String btmdesc;
    private String maindesc;
    private String additioninfo;
    private String user;
    private String categories;
    private String categoriesList;
    private String minOrderedQty;
    private String maxOrderedQty;
    private String minOrderedValue;
    private String maxOrderedValue;
    private String dynamicAttributes;
    private List<ImageModel> nutriFacts; 

    public CreateProduct() {
    }

    public CreateProduct(String code, String name, String type, String uom, double sellingPrice, double basePrice, String crossSells, String upSells, boolean live, String btmdesc, String maindesc, String additioninfo, String user, String categories, String categoriesList,
                         String minOrderedQty, String maxOrderedQty, String minOrderedValue, String maxOrderedValue, String dynamicAttributes, List<ImageModel> nutriFacts) {
        this.code = code;
        this.name = name;
        this.type = type;
        this.uom = uom;
        this.sellingPrice = sellingPrice;
        this.basePrice = basePrice;
        this.crossSells = crossSells;
        this.upSells = upSells;
        this.live = live;
        this.btmdesc = btmdesc;
        this.maindesc = maindesc;
        this.additioninfo = additioninfo;
        this.user = user;
        this.categories = categories;
        this.categoriesList = categoriesList;
        this.minOrderedQty = minOrderedQty;
        this.maxOrderedQty = maxOrderedQty;
        this.minOrderedValue = minOrderedValue;
        this.maxOrderedValue = maxOrderedValue;
        this.dynamicAttributes = dynamicAttributes;
        this.nutriFacts = nutriFacts;

    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUom() {
        return uom;
    }

    public void setUom(String uom) {
        this.uom = uom;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public double getBasePrice() {
        return basePrice;
    }

    public void setBasePrice(double basePrice) {
        this.basePrice = basePrice;
    }

    public String getCrossSells() {
        return crossSells;
    }

    public void setCrossSells(String crossSells) {
        this.crossSells = crossSells;
    }

    public String getUpSells() {
        return upSells;
    }

    public void setUpSells(String upSells) {
        this.upSells = upSells;
    }

    public boolean isLive() {
        return live;
    }

    public void setLive(boolean live) {
        this.live = live;
    }

    public String getBtmdesc() {
        return btmdesc;
    }

    public void setBtmdesc(String btmdesc) {
        this.btmdesc = btmdesc;
    }

    public String getMaindesc() {
        return maindesc;
    }

    public void setMaindesc(String maindesc) {
        this.maindesc = maindesc;
    }

    public String getAdditioninfo() {
        return additioninfo;
    }

    public void setAdditioninfo(String additioninfo) {
        this.additioninfo = additioninfo;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getCategoriesList() {
        return categoriesList;
    }

    public void setCategoriesList(String categoriesList) {
        this.categoriesList = categoriesList;
    }

    public String getMinOrderedQty() {
        return minOrderedQty;
    }

    public void setMinOrderedQty(String minOrderedQty) {
        this.minOrderedQty = minOrderedQty;
    }

    public String getMaxOrderedQty() {
        return maxOrderedQty;
    }

    public void setMaxOrderedQty(String maxOrderedQty) {
        this.maxOrderedQty = maxOrderedQty;
    }

    public String getMinOrderedValue() {
        return minOrderedValue;
    }

    public void setMinOrderedValue(String minOrderedValue) {
        this.minOrderedValue = minOrderedValue;
    }

    public String getMaxOrderedValue() {
        return maxOrderedValue;
    }

    public void setMaxOrderedValue(String maxOrderedValue) {
        this.maxOrderedValue = maxOrderedValue;
    }

    public String getDynamicAttributes() {
        return dynamicAttributes;
    }

    public void setDynamicAttributes(String dynamicAttributes) {
        this.dynamicAttributes = dynamicAttributes;
    }
    
	public List<ImageModel> getNutriFacts() {
		return nutriFacts;
	}

	public void setNutriFacts(List<ImageModel> nutriFacts) {
		this.nutriFacts = nutriFacts;
	}
}
