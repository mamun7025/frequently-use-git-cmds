package com.ekfc.foodcraft.model;

public class Tickets {

}
