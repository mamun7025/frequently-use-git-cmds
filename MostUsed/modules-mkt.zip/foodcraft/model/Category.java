package com.ekfc.foodcraft.model;

public class Category {

    private String categoryId;
    private String categoryName;
    private boolean enabled;
    private String parent;
    private boolean header;
    private boolean filter;
    private String shortDesc;
    private String longDesc;
    private String image;
    private int orderNumber;

    public int getOrderNumber() {
		return orderNumber;
	}



	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}



	public Category(String categoryId, String categoryName, boolean enabled, String parent, boolean header, boolean filter,
    		String longDesc, String shortDesc, String image, int orderNumber) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
        this.enabled = enabled;
        this.parent = parent;
        this.header = header;
        this.filter = filter;
        this.longDesc = longDesc;
        this.shortDesc = shortDesc;
        this.image = image;
        this.orderNumber = orderNumber;
    }
    
    

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public boolean isHeader() {
        return header;
    }

    public void setHeader(boolean header) {
        this.header = header;
    }

    public boolean isFilter() {
        return filter;
    }

    public void setFilter(boolean filter) {
        this.filter = filter;
    }

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public String getLongDesc() {
		return longDesc;
	}

	public void setLongDesc(String longDesc) {
		this.longDesc = longDesc;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
    
    
}

