package com.ekfc.foodcraft.model;

import java.util.List;

public class EmailCampaignRequest {

    private String emailBody;

    private List<String> toEmail;

    private String emailSubject;

    public EmailCampaignRequest() {
    }

    public EmailCampaignRequest(String emailBody, List<String> toEmail, String emailSubject) {
        this.emailBody = emailBody;
        this.toEmail = toEmail;
        this.emailSubject = emailSubject;
    }

    public String getEmailBody() {
        return emailBody;
    }

    public void setEmailBody(String emailBody) {
        this.emailBody = emailBody;
    }

    public List<String> getToEmail() {
        return toEmail;
    }

    public void setToEmail(List<String> toEmail) {
        this.toEmail = toEmail;
    }

    public String getEmailSubject() {
        return emailSubject;
    }

    public void setEmailSubject(String emailSubject) {
        this.emailSubject = emailSubject;
    }
}
