package com.ekfc.foodcraft.model;

public class Address {
    private int id;
    private String firstName;
    private String lastName;
    private String streetAddress;
    private String streetName;
    private String apartment;
    private String landmark;
    private String city;
    private String area;
    private boolean primaryCheck;
    private String userId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getApartment() {
		return apartment;
	}
	public void setApartment(String apartment) {
		this.apartment = apartment;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public boolean isPrimaryCheck() {
		return primaryCheck;
	}
	public void setPrimaryCheck(boolean primaryCheck) {
		this.primaryCheck = primaryCheck;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Address(int id, String firstName, String lastName, String streetAddress, String streetName, String apartment,
			String landmark, String city, String area, boolean primaryCheck, String userId) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.streetAddress = streetAddress;
		this.streetName = streetName;
		this.apartment = apartment;
		this.landmark = landmark;
		this.city = city;
		this.area = area;
		this.primaryCheck = primaryCheck;
		this.userId = userId;
	}
    
	public Address() {}
    
}
