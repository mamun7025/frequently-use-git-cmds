package com.ekfc.foodcraft.model;

public class OrderAddress {
	private int id;
	private String orderNumber;
	private String billing_address;
	private String delivering_address;
	private String delivery_date;
	private String delivery_slots;
	private String phone;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getBilling_address() {
		return billing_address;
	}
	public void setBilling_address(String billing_address) {
		this.billing_address = billing_address;
	}
	public String getDelivery_slots() {
		return delivery_slots;
	}
	public void setDelivery_slots(String delivery_slots) {
		this.delivery_slots = delivery_slots;
	}
	public String getDelivering_address() {
		return delivering_address;
	}
	public void setDelivering_address(String delivering_address) {
		this.delivering_address = delivering_address;
	}
	public String getDelivery_date() {
		return delivery_date;
	}
	public void setDelivery_date(String delivery_date) {
		this.delivery_date = delivery_date;
	}
	public OrderAddress(int id, String orderNumber, String billing_address, String delivering_address,
			String delivery_date) {
		super();
		this.id = id;
		this.orderNumber = orderNumber;
		this.billing_address = billing_address;
		this.delivering_address = delivering_address;
		this.delivery_date = delivery_date;
	}
	
	public OrderAddress(String delivering_address, String delivery_date, String phone, String delivery_slots) {
		super();
		this.delivering_address = delivering_address;
		this.delivery_date = delivery_date;
		this.phone = phone;
		this.delivery_slots = delivery_slots;
	}
	
	public OrderAddress(String delivering_address, String billing_address, String delivery_date, String delivery_slots, String phone) {
		super();
		this.delivering_address = delivering_address;
		this.delivery_date = delivery_date;
		this.billing_address = billing_address;
		this.delivery_slots = delivery_slots;
		this.phone = phone;
	}

	
	
}
