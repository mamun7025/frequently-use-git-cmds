package com.ekfc.foodcraft.model.homepage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class OurMenuModel {

	 private long id;
	    private String title;
	    private String actionName;
	    private String actionUrl;
	    private String imgPath;
	    private boolean active;
	    private String imgData;
	    private String products;
	    private String contents;
	    private int orderNumber;
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getActionName() {
			return actionName;
		}
		public void setActionName(String actionName) {
			this.actionName = actionName;
		}
		public String getActionUrl() {
			return actionUrl;
		}
		public void setActionUrl(String actionUrl) {
			this.actionUrl = actionUrl;
		}
		public String getImgPath() {
			return imgPath;
		}
		public void setImgPath(String imgPath) {
			this.imgPath = imgPath;
		}
		public boolean isActive() {
			return active;
		}
		public void setActive(boolean active) {
			this.active = active;
		}
		public String getImgData() {
			return imgData;
		}
		public void setImgData(String imgData) {
			this.imgData = imgData;
		}
		public String getProducts() {
			return products;
		}
		public void setProducts(String products) {
			this.products = products;
		}
		public String getContents() {
			return contents;
		}
		public void setContents(String contents) {
			this.contents = contents;
		}
		public int getOrderNumber() {
			return orderNumber;
		}
		public void setOrderNumber(int orderNumber) {
			this.orderNumber = orderNumber;
		}
		
		public OurMenuModel() {};
		
		public OurMenuModel(long id, String title, String actionName, String actionUrl, String contents,
				String products, String imgPath, boolean active,   int orderNumber) {
			super();
			this.id = id;
			this.title = title;
			this.actionName = actionName;
			this.actionUrl = actionUrl;
			this.imgPath = imgPath;
			this.active = active;
			this.products = products;
			this.contents = contents;
			this.orderNumber = orderNumber;
		}

}
