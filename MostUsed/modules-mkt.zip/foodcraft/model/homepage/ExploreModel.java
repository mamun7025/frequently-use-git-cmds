package com.ekfc.foodcraft.model.homepage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class ExploreModel {

    private long id;
    private String dataMenuCat;
    private String imgPath;
    private String title;
    private boolean active;
    private String imgData;
    private int orderNumber;

    public ExploreModel() {
    }

    public ExploreModel(long id, String dataMenuCat, String imgPath, String title, boolean active, int orderNumber) {
        this.id = id;
        this.dataMenuCat = dataMenuCat;
        this.imgPath = imgPath;
        this.title = title;
        this.active = active;
        this.orderNumber = orderNumber;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    public int getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getDataMenuCat() {
        return dataMenuCat;
    }

    public void setDataMenuCat(String dataMenuCat) {
        this.dataMenuCat = dataMenuCat;
    }

    public String getImgPath() {
        return imgPath;
    }

    public void setImgPath(String imgPath) {
        this.imgPath = imgPath;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getImgData() {
        return imgData;
    }

    public void setImgData(String imgData) {
        this.imgData = imgData;
    }
}
