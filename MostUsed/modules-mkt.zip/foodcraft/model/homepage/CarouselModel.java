package com.ekfc.foodcraft.model.homepage;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class CarouselModel {

    private long id;

    private String titleM;

    private String actionName;

    private String href;

    private String titleD;

    private String imgPathDesktop;

    private String imageDataDesktop;

    private boolean active;

    private String imgPathMobile;
    
    private String imageDataMobile;
    
    private int orderNumber;


    public CarouselModel(long id, String titleM, String actionName, String href, String titleD, String imgPathDesktop, String imgPathMobile, boolean active, int orderNumber) {
        this.id = id;
        this.titleM = titleM;
        this.actionName = actionName;
        this.href = href;
        this.titleD = titleD;
        this.imgPathDesktop = imgPathDesktop;
        this.active = active;
        this.imgPathMobile = imgPathMobile;
        this.orderNumber = orderNumber;
        }

    public CarouselModel(long id, String titleM, String actionName, String href, String titleD, String imgPathDesktop, String imageDataDesktop, boolean active, String imageDataMobile) {
        this.id = id;
        this.titleM = titleM;
        this.actionName = actionName;
        this.href = href;
        this.titleD = titleD;
        this.imgPathDesktop = imgPathDesktop;
        this.imageDataDesktop = imageDataDesktop;
        this.active = active;
        this.imgPathMobile = imgPathDesktop;
        this.imageDataMobile = imageDataMobile;
    }

    public CarouselModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    public long getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(int orderNumber) {
        this.orderNumber = orderNumber;
    }

    public String getTitleM() {
        return titleM;
    }

    public void setTitleM(String titleM) {
        this.titleM = titleM;
    }

    public String getActionName() {
        return actionName;
    }

    public void setActionName(String actionName) {
        this.actionName = actionName;
    }

    public String getHref() {
        return href;
    }

    public void setHref(String href) {
        this.href = href;
    }

    public String getTitleD() {
        return titleD;
    }

    public void setTitleD(String titleD) {
        this.titleD = titleD;
    }

    public String getImgPathDesktop() {
        return imgPathDesktop;
    }

    public void setImgPathDesktop(String imgPathDesktop) {
        this.imgPathDesktop = imgPathDesktop;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

	public String getImageDataDesktop() {
		return imageDataDesktop;
	}

	public void setImageDataDesktop(String imageDataDesktop) {
		this.imageDataDesktop = imageDataDesktop;
	}

	public String getImgPathMobile() {
		return imgPathMobile;
	}

	public void setImgPathMobile(String imgPathMobile) {
		this.imgPathMobile = imgPathMobile;
	}

	public String getImageDataMobile() {
		return imageDataMobile;
	}

	public void setImageDataMobile(String imageDataMobile) {
		this.imageDataMobile = imageDataMobile;
	}
}
