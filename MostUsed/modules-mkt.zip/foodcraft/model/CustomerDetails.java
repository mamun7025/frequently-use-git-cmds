package com.ekfc.foodcraft.model;

public class CustomerDetails {

    private int id;
    private String ordernumber;
    private String first_name;
    private String last_name;
    private String phone;
    private String email;
    private String trn_number;
    private String company_name;
    private String billing_address;
    private String delivery_address;
	private String emirate;
    private String area;
    private String box_num;
    private String delivery_date;
    private String delivery_slots;
    private String delivery_location;
    private String notes;
    private String deliveryLatLng;

    public CustomerDetails(String ordernumber, String first_name, String last_name, String phone, String email, String trn_number, String company_name, String billing_address, String delivery_address, String emirate, String box_num, String delivery_date, String delivery_slots, String delivery_location, String notes, String area) {
        this.ordernumber = ordernumber;
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone = phone;
        this.email = email;
        this.trn_number = trn_number;
        this.company_name = company_name;
        this.billing_address = billing_address;
        this.emirate = emirate;
        this.box_num = box_num;
        this.delivery_date = delivery_date;
        this.delivery_slots = delivery_slots;
        this.delivery_location = delivery_location;
        this.delivery_address= delivery_address;
        this.notes = notes;
        this.area = area;
    }

    
    public CustomerDetails(String ordernumber, String first_name, String last_name, String phone, String email, String trn_number, String company_name, String billing_address, String delivery_address, String emirate, String box_num, String delivery_date, String delivery_slots, String delivery_location, String notes, String area, String deliveryLatLng) {
        this.ordernumber = ordernumber;
        this.first_name = first_name;
        this.last_name = last_name;
        this.phone = phone;
        this.email = email;
        this.trn_number = trn_number;
        this.company_name = company_name;
        this.billing_address = billing_address;
        this.emirate = emirate;
        this.box_num = box_num;
        this.delivery_date = delivery_date;
        this.delivery_slots = delivery_slots;
        this.delivery_location = delivery_location;
        this.delivery_address= delivery_address;
        this.notes = notes;
        this.area = area;
        this.deliveryLatLng = deliveryLatLng;
    }
    
    public CustomerDetails() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOrdernumber() {
        return ordernumber;
    }

    public void setOrdernumber(String ordernumber) {
        this.ordernumber = ordernumber;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTrn_number() {
        return trn_number;
    }

    public void setTrn_number(String trn_number) {
        this.trn_number = trn_number;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getBilling_address() {
        return billing_address;
    }

    public void setBilling_address(String billing_address) {
        this.billing_address = billing_address;
    }

    public String getEmirate() {
        return emirate;
    }

    public void setEmirate(String emirate) {
        this.emirate = emirate;
    }

    public String getBox_num() {
        return box_num;
    }

    public void setBox_num(String box_num) {
        this.box_num = box_num;
    }

    public String getDelivery_date() {
        return delivery_date;
    }

    public void setDelivery_date(String delivery_date) {
        this.delivery_date = delivery_date;
    }

    public String getDelivery_slots() {
        return delivery_slots;
    }

    public void setDelivery_slots(String delivery_slots) {
        this.delivery_slots = delivery_slots;
    }

    public String getDelivery_location() {
        return delivery_location;
    }

    public void setDelivery_location(String delivery_location) {
        this.delivery_location = delivery_location;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

    public String getDelivery_address() {
		return delivery_address;
	}

	public void setDelivery_address(String delivery_address) {
		this.delivery_address = delivery_address;
	}


	public String getDeliveryLatLng() {
		return deliveryLatLng;
	}


	public void setDeliveryLatLng(String deliveryLatLng) {
		this.deliveryLatLng = deliveryLatLng;
	}
    
	public CustomerDetails(int id, String ordernumber, String phone, String email, String billing_address,
			String delivering_address, String deliveryDate) {
		super();
		this.id = id;
		this.ordernumber = ordernumber;
		this.phone = phone;
		this.email = email;
		this.billing_address = billing_address;
		this.delivery_address = delivering_address;
		this.delivery_date = deliveryDate;
	}
	public CustomerDetails(String email, String billing_address,
			String delivering_address, String deliveryDate, String phone) {
		super();
		this.phone = phone;
		this.email = email;
		this.billing_address = billing_address;
		this.delivery_address = delivering_address;
		this.delivery_date = deliveryDate;
	}
	
	public CustomerDetails(String email, String billing_address,
			String delivering_address, String deliveryDate, String phone,String first_name, String last_name,
			String delivery_slots, String trn_number) {
		super();
		this.phone = phone;
		this.email = email;
		this.billing_address = billing_address;
		this.delivery_address = delivering_address;
		this.delivery_date = deliveryDate;
		this.delivery_slots = delivery_slots;
		this.first_name = first_name;
		this.last_name = last_name;
		this.trn_number = trn_number;
	}
	
	public CustomerDetails(String first_name, String last_name, String email) {
		super();
		this.first_name =first_name;
		this.last_name = last_name;
		this.email = email;
	}


	public CustomerDetails(int id, String ordernumber, String first_name, String last_name, String phone, String email,
			String trn_number, String company_name, String billing_address, String delivery_address, String emirate,
			String area, String box_num, String delivery_date, String delivery_slots, String delivery_location,
			String notes, String deliveryLatLng) {
		super();
		this.id = id;
		this.ordernumber = ordernumber;
		this.first_name = first_name;
		this.last_name = last_name;
		this.phone = phone;
		this.email = email;
		this.trn_number = trn_number;
		this.company_name = company_name;
		this.billing_address = billing_address;
		this.delivery_address = delivery_address;
		this.emirate = emirate;
		this.area = area;
		this.box_num = box_num;
		this.delivery_date = delivery_date;
		this.delivery_slots = delivery_slots;
		this.delivery_location = delivery_location;
		this.notes = notes;
		this.deliveryLatLng = deliveryLatLng;
	}
	
	
	
}
