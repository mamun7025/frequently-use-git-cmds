package com.ekfc.foodcraft.model;

public class OrdersHeader {

	private int id;
	private String cartnumber;
	private String userid;
	private String createdOn;
	private String createdBy;
	private String status;
	private String deliveryaddress;
	private String phone;
	private String orderNumber;
	private double vatAmount;


	private double shippingAmount;
	private double totalAmount;
	private double paymentAmmount;
	private double discountAmmount;
	private double processingFee;
	

	private String invoice;

	private String paymentMode;

	private String trackingUrl;
	
	private double walletAmount;
	private double loyaltyAmount;
	private String loyaltyCalculated;
	
	private int invoiceId;
	
	
 
	public double getLoyaltyAmount() {
		return loyaltyAmount;
	}

	public void setLoyaltyAmount(double loyaltyAmount) {
		this.loyaltyAmount = loyaltyAmount;
	}

	public int getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getLoyaltyCalculated() {
		return loyaltyCalculated;
	}

	public void setLoyaltyCalculated(String loyaltyCalculated) {
		this.loyaltyCalculated = loyaltyCalculated;
	}
	
	public double getLoyaltyAmout() {
		return loyaltyAmount;
	}

	public void setLoyaltyAmout(double loyaltyAmout) {
		this.loyaltyAmount = loyaltyAmout;
	}

	public double getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(double processingFee) {
		this.processingFee = processingFee;
	}

	//Order and Cart numbers Only
	public OrdersHeader(String orderNumber, String cartNumber) {
		this.orderNumber = orderNumber;
		this.cartnumber = cartNumber;
	}
	//orderNumber, user_id, created_on, created_by,status
	public OrdersHeader(String orderNumber, String userid, String createdOn, String createdBy, String status) {
		this.orderNumber = orderNumber;
		this.userid =userid;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.status = status;
	}

	//orderNumber,cartnumber, user_id, created_on, created_by,status
	public OrdersHeader(String orderNumber,String cartnumber, String userid, String createdOn, String createdBy, String status) {
		this.orderNumber = orderNumber;
		this.cartnumber = cartnumber;
		this.userid =userid;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.status = status;
	}


	public OrdersHeader(String orderNumber, String userid, String createdOn, String createdBy, String status,double vatAmount,double shippingAmount,double totalAmount,double paymentAmmount) {
		this.orderNumber = orderNumber;
		this.userid =userid;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.status = status;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;

	}

	public OrdersHeader(String orderNumber, String userid, String createdOn, String createdBy, String status,double vatAmount,double shippingAmount,double totalAmount,double paymentAmmount, String invoice) {
		this.orderNumber = orderNumber;
		this.userid =userid;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.status = status;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.invoice = invoice;
	}

	public OrdersHeader(String orderNumber, String userid, String createdOn, String createdBy, String status,double vatAmount,double shippingAmount,double totalAmount,double paymentAmmount, String invoice, String trackingUrl) {
		this.orderNumber = orderNumber;
		this.userid =userid;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.status = status;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.invoice = invoice;
		this.trackingUrl = trackingUrl;
	}

	public OrdersHeader(String orderNumber, double vatAmount,double shippingAmount,double totalAmount,double paymentAmmount, String createdOn) {
		this.orderNumber = orderNumber;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.createdOn = createdOn;

	}
	
	

	public OrdersHeader( String orderNumber, double vatAmount, double shippingAmount,
			double totalAmount, double paymentAmmount, double discountAmmount,String createdOn) {
		this.createdOn = createdOn;
		this.orderNumber = orderNumber;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.discountAmmount = discountAmmount;
	}

	public OrdersHeader( String orderNumber, double vatAmount, double shippingAmount,
						 double totalAmount, double paymentAmmount, double discountAmmount,String createdOn, String paymentMode) {
		this.createdOn = createdOn;
		this.orderNumber = orderNumber;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.discountAmmount = discountAmmount;
		this.paymentMode = paymentMode;
	}
	public OrdersHeader( String orderNumber, double vatAmount, double shippingAmount,
			 double totalAmount, double paymentAmmount, double discountAmmount,double processingFee,double walletAmount, String createdOn, String paymentMode,double loyaltyAmount) {
this.createdOn = createdOn;
this.orderNumber = orderNumber;
this.vatAmount = vatAmount;
this.shippingAmount = shippingAmount;
this.totalAmount = totalAmount;
this.paymentAmmount = paymentAmmount;
this.discountAmmount = discountAmmount;
this.processingFee=processingFee;
this.paymentMode = paymentMode;
this.walletAmount = walletAmount;
this.loyaltyAmount=loyaltyAmount;
}
	public OrdersHeader(String userid) {
		this.userid = userid;
	}


	public String getCartnumber() {
		return cartnumber;
	}

	public void setCartnumber(String cartnumber) {
		this.cartnumber = cartnumber;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public OrdersHeader() {

	}


	public OrdersHeader(int id) {
		this.id = id;
	}
	


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getDeliveryaddress() {
		return deliveryaddress;
	}


	public void setDeliveryaddress(String deliveryaddress) {
		this.deliveryaddress = deliveryaddress;
	}


	public String getPhone() {
		return phone;
	}


	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}


	public String getOrderNumber() {
		return orderNumber;
	}


	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public double getVatAmount() {
		return vatAmount;
	}


	public void setVatAmount(double vatAmount) {
		this.vatAmount = vatAmount;
	}


	public double getShippingAmount() {
		return shippingAmount;
	}


	public void setShippingAmount(double shippingAmount) {
		this.shippingAmount = shippingAmount;
	}


	public double getTotalAmount() {
		return totalAmount;
	}


	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public double getPaymentAmmount() {
		return paymentAmmount;
	}


	public void setPaymentAmmount(double paymentAmmount) {
		this.paymentAmmount = paymentAmmount;
	}

	public String getInvoice() {
		return invoice;
	}

	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}

	public double getDiscountAmmount() {
		return discountAmmount;
	}

	public void setDiscountAmmount(double discountAmmount) {
		this.discountAmmount = discountAmmount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getTrackingUrl() {
		return trackingUrl;
	}

	public void setTrackingUrl(String trackingUrl) {
		this.trackingUrl = trackingUrl;
	}

	public double getWalletAmount() {
		return walletAmount;
	}

	public void setWalletAmount(double walletAmount) {
		this.walletAmount = walletAmount;
	}
	
	public OrdersHeader(String paymentMode, double vatAmount, double shippingAmount,
			double totalAmount, double paymentAmmount, double discountAmmount,String createdOn, String invoice,double loyaltyAmount,String loyaltyCalculated) {
		this.paymentMode = paymentMode;
		this.createdOn = createdOn;
		this.vatAmount = vatAmount;
		this.shippingAmount = shippingAmount;
		this.totalAmount = totalAmount;
		this.paymentAmmount = paymentAmmount;
		this.discountAmmount = discountAmmount;
		this.invoice =  invoice;
		this.loyaltyAmount = loyaltyAmount;
		this.loyaltyCalculated = loyaltyCalculated;
	}
	
	
}
