package com.ekfc.foodcraft.model;

public class CustomersData {
	private String email;
	private String firstName;
	private String lastName;
	private String password;
	private String phone;
	private String communicatioPreferences;
	private String streetAddress;
	private String streetName;
	private String apartment;
	private String landmark;
	private String city;
	private boolean primaryCheck;
	private int addressId;
	private String createdOn;
	
	
	
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCommunicatioPreferences() {
		return communicatioPreferences;
	}
	public void setCommunicatioPreferences(String communicatioPreferences) {
		this.communicatioPreferences = communicatioPreferences;
	}
	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getStreetName() {
		return streetName;
	}
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}
	public String getApartment() {
		return apartment;
	}
	public void setApartment(String apartment) {
		this.apartment = apartment;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public boolean isPrimaryCheck() {
		return primaryCheck;
	}
	public void setPrimaryCheck(boolean primaryCheck) {
		this.primaryCheck = primaryCheck;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public CustomersData(String email, String firstName, String lastName, String password, String phone,
			String communicatioPreferences, String streetAddress, String streetName, String apartment, String landmark,
			String city, boolean primaryCheck, int addressId, String createdOn) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.phone = phone;
		this.communicatioPreferences = communicatioPreferences;
		this.streetAddress = streetAddress;
		this.streetName = streetName;
		this.apartment = apartment;
		this.landmark = landmark;
		this.city = city;
		this.primaryCheck = primaryCheck;
		this.addressId = addressId;
		this.createdOn = createdOn;
	}
	public CustomersData(String email, String firstName, String lastName, String password, String phone,
			String communicatioPreferences, String createdOn) {
		super();
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.password = password;
		this.phone = phone;
		this.communicatioPreferences = communicatioPreferences;
		this.createdOn = createdOn;
	}
	
	
}
