package com.ekfc.foodcraft.model;

import java.sql.Date;

public class SupportTicketHeader {

    private int id;
    private String user;
    private String subject;
    private String type;
    private String priority;
    private String status;
    private Date createdOn;
    private Date updatedOn;
    private String imagePath;
    private String issue;

    public SupportTicketHeader(int id, String user, String subject, String type, String priority, String status, Date createdOn, Date updatedOn, String imagePath, String issue) {
        this.id = id;
        this.user = user;
        this.subject = subject;
        this.type = type;
        this.priority = priority;
        this.status = status;
        this.createdOn = createdOn;
        this.updatedOn = updatedOn;
        this.imagePath = imagePath;
        this.issue = issue;
    }
    
    

    public String getIssue() {
		return issue;
	}



	public void setIssue(String issue) {
		this.issue = issue;
	}



	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}
    
    
}
