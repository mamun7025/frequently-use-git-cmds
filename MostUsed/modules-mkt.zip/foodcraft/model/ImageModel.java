package com.ekfc.foodcraft.model;

public class ImageModel {

    private String header;
    private String value;
    private String path;

    public ImageModel(String header, String value, String path) {
        this.header = header;
        this.value = value;
        this.path = path;
    }

    public ImageModel() {
    }

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
