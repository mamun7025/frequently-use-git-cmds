package com.ekfc.foodcraft.model;

import java.util.List;

public class UpdateProductMedia {

    private String code;
    private List<ImageModel> products;

    public UpdateProductMedia(String code, List<ImageModel> products) {
        this.code = code;
        this.products = products;
    }

    public UpdateProductMedia() {
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<ImageModel> getProducts() {
        return products;
    }

    public void setProducts(List<ImageModel> products) {
        this.products = products;
    }
}
