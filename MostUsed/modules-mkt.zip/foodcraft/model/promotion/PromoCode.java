package com.ekfc.foodcraft.model.promotion;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(value = JsonInclude.Include.NON_NULL)
public class PromoCode {
    private long id;
    private String code;
    private Double discount;
    private String discountType;
    private Date validFrom;
    private Date validTill;
    private boolean active;
    private boolean allowedForGuestUser;
    private boolean excludeSaleTime;
    private String usageLimit;

    public PromoCode() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTill() {
        return validTill;
    }

    public void setValidTill(Date validTill) {
        this.validTill = validTill;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isAllowedForGuestUser() {
        return allowedForGuestUser;
    }

    public void setAllowedForGuestUser(boolean allowedForGuestUser) {
        this.allowedForGuestUser = allowedForGuestUser;
    }

    public boolean isExcludeSaleTime() {
        return excludeSaleTime;
    }

    public void setExcludeSaleTime(boolean excludeSaleTime) {
        this.excludeSaleTime = excludeSaleTime;
    }

    public String getUsageLimit() {
        return usageLimit;
    }

    public void setUsageLimit(String usageLimit) {
        this.usageLimit = usageLimit;
    }

    public PromoCode(long id, String code, Double discount, String discountType, Date validFrom, Date validTill, boolean excludeSaleTime, String usageLimit,boolean active, boolean allowedForGuestUser) {
        this.id = id;
        this.code = code;
        this.discount = discount;
        this.discountType = discountType;
        this.validFrom = validFrom;
        this.validTill = validTill;
        this.active = active;
        this.allowedForGuestUser = allowedForGuestUser;
        this.excludeSaleTime = excludeSaleTime;
        this.usageLimit = usageLimit;


    }
}
