package com.ekfc.foodcraft.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoyaltyUser {
	private long id;
	private String userId;
	private int points;
	public LoyaltyUser() {}
	public LoyaltyUser(long id, String userId, int points) {
		super();
		this.id = id;
		this.userId = userId;
		this.points = points;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	@Override
	public String toString() {
		return "LoyaltyUser [id=" + id + ", userId=" + userId + ", points=" + points + "]";
	}
	
	

}
