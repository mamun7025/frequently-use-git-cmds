package com.ekfc.foodcraft.model.reports;


public class OrderQuanityDTO {
	String productCode;
	String productDescription;
	int orderQuantity;
	public OrderQuanityDTO() {
		super();
	}
	public OrderQuanityDTO(String productCode, String productDescription, int orderQuantity) {
		super();
		this.productCode = productCode;
		this.productDescription = productDescription;
		this.orderQuantity = orderQuantity;
	}
	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	@Override
	public String toString() {
		return "OrderQuanityDTO [productCode=" + productCode + ", productDescription=" + productDescription
				+ ", orderQuantity=" + orderQuantity + "]";
	}
	
	

}
