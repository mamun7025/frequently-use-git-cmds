package com.ekfc.foodcraft.model.reports;


public class RptRequestDTO {

    private String rptFileName;
    private String outputFileName;
    private String reportFormat;

    private String rptSubFolderName;

    public RptRequestDTO(String rptFileName, String outputFileName, String reportFormat) {
        this.rptFileName = rptFileName;
        this.outputFileName = outputFileName;
        this.reportFormat = reportFormat;
    }

    public String getRptFileName() {
        return rptFileName;
    }

    public void setRptFileName(String rptFileName) {
        this.rptFileName = rptFileName;
    }

    public String getOutputFileName() {
        return outputFileName;
    }

    public void setOutputFileName(String outputFileName) {
        this.outputFileName = outputFileName;
    }

    public String getReportFormat() {
        return reportFormat;
    }

    public void setReportFormat(String reportFormat) {
        this.reportFormat = reportFormat;
    }

    public String getRptSubFolderName() {
        return rptSubFolderName;
    }

    public void setRptSubFolderName(String rptSubFolderName) {
        this.rptSubFolderName = rptSubFolderName;
    }
}
