package com.ekfc.foodcraft.model.reports;

public class OrderRptBean {

    private String orderNumber;
    private String orderStatus;
    private String orderPlaceTime;
    private String paymentAmount;

	private String deliveryDate;
    private String deliverySlots;
    private String shippingAddress;
    private String paymentMode;

    // customer info
    private String customerId;
    private String customerFirstName;
    private String customerLastName;
    private String customerPhone;

    private double totalAmount;
    private double deliverFee;
    private double processingFee;
    private String streetName;
    private String landmark;
    private String city;

    // product info
    private String productDescription;
    private String productCode;
    private String productCategory;
    private double quantity;
    private double saleAmount;
    
    private String orderDate;
    private String customerType;
    private String erpStatus;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }
    
    

    public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderPlaceTime() {
        return orderPlaceTime;
    }

    public void setOrderPlaceTime(String orderPlaceTime) {
        this.orderPlaceTime = orderPlaceTime;
    }

    public String getDeliverySlots() {
        return deliverySlots;
    }

    public void setDeliverySlots(String deliverySlots) {
        this.deliverySlots = deliverySlots;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCustomerFirstName() {
        return customerFirstName;
    }

    public void setCustomerFirstName(String customerFirstName) {
        this.customerFirstName = customerFirstName;
    }

    public String getCustomerLastName() {
        return customerLastName;
    }

    public void setCustomerLastName(String customerLastName) {
        this.customerLastName = customerLastName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getDeliverFee() {
        return deliverFee;
    }

    public void setDeliverFee(double deliverFee) {
        this.deliverFee = deliverFee;
    }

    public double getProcessingFee() {
        return processingFee;
    }

    public void setProcessingFee(double processingFee) {
        this.processingFee = processingFee;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public double getSaleAmount() {
        return saleAmount;
    }

    public void setSaleAmount(double saleAmount) {
        this.saleAmount = saleAmount;
    }
    
    public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	
	


    public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public OrderRptBean(){
    }
    public OrderRptBean(String orderNumber, String orderStatus, String orderPlaceTime, String deliverySlots, String deliveryDate, String paymentMode, String customerId, String customerFirstName, String customerLastName, String customerPhone, double totalAmount, double deliverFee, double processingFee, String shippingAddress, String streetName, String landmark, String city, String productDescription, String productCategory, double quantity, double saleAmount) {
        this.orderNumber = orderNumber;
        this.orderStatus = orderStatus;
        this.orderPlaceTime = orderPlaceTime;
        this.deliverySlots = deliverySlots;
        this.deliveryDate = deliveryDate;
        this.paymentMode = paymentMode;
        this.customerId = customerId;
        this.customerFirstName = customerFirstName;
        this.customerLastName = customerLastName;
        this.customerPhone = customerPhone;
        this.totalAmount = totalAmount;
        this.deliverFee = deliverFee;
        this.processingFee = processingFee;
        this.shippingAddress = shippingAddress;
        this.streetName = streetName;
        this.landmark = landmark;
        this.city = city;
        this.productDescription = productDescription;
        this.productCategory = productCategory;
        this.quantity = quantity;
        this.saleAmount = saleAmount;
    }

	public String getErpStatus() {
		return erpStatus;
	}

	public void setErpStatus(String erpStatus) {
		this.erpStatus = erpStatus;
	}

    

}
