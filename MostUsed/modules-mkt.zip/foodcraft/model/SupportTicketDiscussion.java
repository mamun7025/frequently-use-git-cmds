package com.ekfc.foodcraft.model;

import java.sql.Date;

public class SupportTicketDiscussion {

    private int id;
    private int ticketId;
    private boolean customer;
    private boolean employee;
    private String description;
    private Date createdOn;


    public SupportTicketDiscussion(int id, int ticketId, boolean customer, boolean employee, String description, Date createdOn) {
        this.id = id;
        this.ticketId = ticketId;
        this.customer = customer;
        this.employee = employee;
        this.description = description;
        this.createdOn = createdOn;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public boolean isCustomer() {
        return customer;
    }

    public void setCustomer(boolean customer) {
        this.customer = customer;
    }

    public boolean isEmployee() {
        return employee;
    }

    public void setEmployee(boolean employee) {
        this.employee = employee;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }
}
