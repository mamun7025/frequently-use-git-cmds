package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.PromotionDAO;
import com.ekfc.foodcraft.model.promotion.PromoCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class PromotionService {

    @Autowired
    private PromotionDAO promotionDAO;


    public Map<String, Object> getAllPromotions() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<PromoCode> promoCodeList = promotionDAO.getAllPromotions();
            resultMap.put("result", promoCodeList);
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process");
        }
        return resultMap;
    }

    public Map<String, Object> updatePromotion(PromoCode promoCode) {
        final Map<String, Object> resultMap = new HashMap<>();
        // TODO, write validators to check if the valid from and valid till are accepted date values

        final boolean  updated = promotionDAO.updatePromotion(promoCode);

        if(updated){
            resultMap.put("result", "Updated the Promotion successfully");
        }else{
            resultMap.put("error", "Unable to Process");
        }

        return resultMap;
    }

    public Map<String, Object> addPromotion(PromoCode promoCode) {
        final Map<String, Object> resultMap = new HashMap<>();
        // TODO, write validators to check if the valid from and valid till are accepted date values

        final boolean  added = promotionDAO.addPromoCode(promoCode);

        if(added){
            resultMap.put("result", "Added the Promotion successfully");
        }else{
            resultMap.put("error", "Unable to Process");
        }

        return resultMap;
    }
}
