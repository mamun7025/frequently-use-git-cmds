package com.ekfc.foodcraft.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.dao.LoyaltyConfigDAO;
import com.ekfc.foodcraft.model.LoyaltyEarnBurnModel;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class LoyaltyConfigService {

	@Autowired
	private LoyaltyConfigDAO loyaltyDAO;
	
	public Map<String, Object> getLoyaltyConfig(Map<String, Object> reqMap){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		final List<LoyaltyEarnBurnModel> model = loyaltyDAO.getAllLoyaltyDetails();
		resultMap.put("result", model);
		return resultMap;
	}
	
	public Map<String, Object> saveLoyaltyConfig(Map<String, Object> reqMap){
		Map<String, Object> resultMap = new HashMap<String, Object>();
		final List<LoyaltyEarnBurnModel> tempModel = loyaltyDAO.getLoyaltyDetailsByType(reqMap.get("type").toString());
		ObjectMapper om = new ObjectMapper();
		boolean isSaved = false;
		final LoyaltyEarnBurnModel model = om.convertValue(reqMap, LoyaltyEarnBurnModel.class);
		if(tempModel == null) {
			isSaved = loyaltyDAO.createEarnBurnConfig(model);			
		}
		else if(tempModel.size() > 0) {
			isSaved = loyaltyDAO.updateEarnBurnConfig(model);
		}
		else {
			
		}
		resultMap.put("result", isSaved);
		return resultMap;
	}
	
}
