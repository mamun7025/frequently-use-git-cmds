package com.ekfc.foodcraft.services.report.impl;

import com.ekfc.foodcraft.dao.SalesReportDAO;
import com.ekfc.foodcraft.model.generic.PaginatedResponse;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.reports.OrderRptBean;
import com.ekfc.foodcraft.services.report.AllOrderInfoDataService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Map;

@Service
public class AllOrderInfoDataServiceImpl implements AllOrderInfoDataService {

    private static final Logger logger = LoggerFactory.getLogger(AllOrderInfoDataServiceImpl.class);

    private final SalesReportDAO salesReportDAO;
    
	public final static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static final String[] HEADERs = { "Order Number","FCode","Product Name","Quantity","Price","Order Date","City","Delivery date","Delivery timeslot","Payment Method","Total amount (Inc. VAT)","Cash on delivery fee","Delivery charges","Delivery Address","Customer Type","ERP Status" };
	  static final String SHEET = "Orders";
	  
    @Autowired
    public AllOrderInfoDataServiceImpl(SalesReportDAO salesReportDAO) {
        this.salesReportDAO = salesReportDAO;
    }

    @Override
    public ResponseEntity<?> getOrderInfoDataPaginated(Map<String, String> filterParams, HttpServletRequest servletRequest) {
        try {
            Map<String, Object> dataPage = salesReportDAO.getAllOrderInfoDataPaginated(filterParams);
            PaginatedResponse response = new PaginatedResponse(
                    true,
                    HttpStatus.OK.value(),
                    "Success",
                    (Integer)dataPage.get("totalElements"),
                    (Integer)dataPage.get("totalPages"),
                    (Integer)dataPage.get("currentPage") ,
                    (Integer)dataPage.get("pageSize") ,
                    dataPage.get("content")
            );
            return ResponseEntity.ok(response);
        } catch (Exception ex){
			ex.printStackTrace();
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


	public String getAllOrderInfoExcelData(Map<String, String> filterParams, HttpServletRequest servletRequest){
		try(Workbook workbook = new XSSFWorkbook()){

			Sheet sheet = workbook.createSheet(SHEET);
			Row headerRow = sheet.createRow(0);
			for(int col =0; col<HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}
			int rowIdx = 1;
			List<OrderRptBean> orderReport = salesReportDAO.getAllOrderInfoForExcel(filterParams);
			//	String orderId = null;
			for(OrderRptBean od : orderReport) {
				double price = (od.getQuantity() * od.getSaleAmount());

				Row row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(od.getOrderNumber());
				row.createCell(1).setCellValue(od.getProductCode());
				row.createCell(2).setCellValue(od.getProductDescription());
				row.createCell(3).setCellValue(od.getQuantity());
				row.createCell(4).setCellValue(price);
				row.createCell(5).setCellValue(od.getOrderDate());
				row.createCell(6).setCellValue(od.getCity());
				row.createCell(7).setCellValue(od.getDeliveryDate());
				row.createCell(8).setCellValue(od.getDeliverySlots());
				row.createCell(9).setCellValue(od.getPaymentMode());
				row.createCell(10).setCellValue(od.getPaymentAmount());
				row.createCell(11).setCellValue(od.getProcessingFee());
				row.createCell(12).setCellValue(od.getDeliverFee());
				row.createCell(13).setCellValue(od.getShippingAddress());
				row.createCell(14).setCellValue(od.getCustomerType());
				row.createCell(14).setCellValue(od.getErpStatus());
    				/*if(orderId != null && orderId.equalsIgnoreCase(od.getOrderNumber())) {

    					sheet.addMergedRegion(new CellRangeAddress(1,2,1,1));
    				}
    				orderId = od.getOrderNumber();*/
			}
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);
			sheet.autoSizeColumn(6);
			sheet.autoSizeColumn(7);
			sheet.autoSizeColumn(8);
			sheet.autoSizeColumn(9);
			sheet.autoSizeColumn(10);
			sheet.autoSizeColumn(11);
			sheet.autoSizeColumn(12);
			sheet.autoSizeColumn(13);
			sheet.autoSizeColumn(14);
			sheet.autoSizeColumn(15);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			workbook.write(out);
			byte[] excelBytes = out.toByteArray();
			return Base64.getEncoder().encodeToString(excelBytes);
		}
		catch(IOException ex) {
			ex.printStackTrace();
			return null;
		}
	}


}
