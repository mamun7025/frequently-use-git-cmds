package com.ekfc.foodcraft.services.report.impl;

import com.ekfc.foodcraft.dao.SalesReportDAO;
import com.ekfc.foodcraft.model.generic.GenericModel;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.report.OrderInfoRptCommonService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OrderInfoRptCommonServiceImpl implements OrderInfoRptCommonService {

    private static final Logger logger = LoggerFactory.getLogger(OrderInfoRptCommonServiceImpl.class);

    private final SalesReportDAO salesReportDAO;

    @Autowired
    public OrderInfoRptCommonServiceImpl(SalesReportDAO salesReportDAO) {
        this.salesReportDAO = salesReportDAO;
    }

    @Override
    public ResponseEntity<?> getOrderInfoSummaryRptByStatus() {
        try {
            List<GenericModel> dataList = salesReportDAO.getOrderInfoSummaryRptDataByStatus();
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", dataList));
        } catch (Exception ex){
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


}
