package com.ekfc.foodcraft.services.report.impl;

import com.ekfc.foodcraft.dao.SalesReportDAO;
import com.ekfc.foodcraft.model.generic.GenericModel;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.report.SalesRptByCategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SalesRptByCategoryServiceImpl implements SalesRptByCategoryService {

    private static final Logger logger = LoggerFactory.getLogger(SalesRptByCategoryServiceImpl.class);

    private final SalesReportDAO salesReportDAO;

    @Autowired
    public SalesRptByCategoryServiceImpl(SalesReportDAO salesReportDAO) {
        this.salesReportDAO = salesReportDAO;
    }

    @Override
    public ResponseEntity<?> getRptData() {
        try {
            List<GenericModel> dataList = salesReportDAO.getSalesRptDataByPC();
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", dataList));
        } catch (Exception ex){
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


}
