package com.ekfc.foodcraft.services.report.impl;

import com.ekfc.foodcraft.dao.ProductDAO;
import com.ekfc.foodcraft.model.Product;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.report.ProductsInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Service
public class ProductsInfoServiceImpl implements ProductsInfoService {

    private static final Logger logger = LoggerFactory.getLogger(ProductsInfoServiceImpl.class);
    private final ProductDAO productDAO;

    @Autowired
    public ProductsInfoServiceImpl(ProductDAO productDAO) {
        this.productDAO = productDAO;
    }

    @Override
    public ResponseEntity<?> getAllProductData(Map<String, String> filterParams, HttpServletRequest servletRequest) {
        try {
            List<Product> productList = this.productDAO.getAllProductData();
            ResponseModel response = new ResponseModel(
                    true,
                    HttpStatus.OK.value(),
                    "Success",
                    productList
            );
            return ResponseEntity.ok(response);
        } catch (Exception ex){
            ex.printStackTrace();
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    @Override
    public ResponseEntity<?> getAllProductDataExcel(Map<String, String> filterParams, HttpServletRequest servletRequest) {
        return null;
    }



}
