package com.ekfc.foodcraft.services.report;

import org.springframework.http.ResponseEntity;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface AllOrderInfoDataService {
    ResponseEntity<?> getOrderInfoDataPaginated(Map<String, String> filterParams, HttpServletRequest servletRequest);
    String getAllOrderInfoExcelData(Map<String, String> filterParams, HttpServletRequest servletRequest);
}
