package com.ekfc.foodcraft.services.report;

import org.springframework.http.ResponseEntity;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

public interface ProductsInfoService {
    ResponseEntity<?> getAllProductData(Map<String, String> filterParams, HttpServletRequest servletRequest);

    ResponseEntity<?> getAllProductDataExcel(Map<String, String> filterParams, HttpServletRequest servletRequest);
}
