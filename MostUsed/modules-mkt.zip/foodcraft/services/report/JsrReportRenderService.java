package com.ekfc.foodcraft.services.report;

import com.ekfc.foodcraft.model.reports.RptRequestDTO;
import com.zaxxer.hikari.HikariDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.FileSystems;
import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

@Service
public class JsrReportRenderService {

    @Autowired
    private Environment env;
    private final HikariDataSource dataSource;
    private final Map<String, Object> rptParameter;

    public JsrReportRenderService(HikariDataSource dataSource) {
        this.dataSource = dataSource;
        this.rptParameter = new HashMap<>();
    }


    public void validation(RptRequestDTO rptRequestDTO) throws Exception {

        String rptFileName = rptRequestDTO.getRptFileName();
        if(rptFileName == null || rptFileName.equals("")){
            throw new Exception("Please provide jasper report name");
        }

    }

    public Map<String, Object> setReportParameters(Map<String, Object>parameters){
        // common params
        try {
//            File fileLogo = ResourceUtils.getFile("classpath:reports/image/ekfc-logo.png");
            String reportRootPath = env.getProperty("cms.reports.root.path");
            File fileLogo = ResourceUtils.getFile(reportRootPath+"/image/ekfc-logo.png");
            parameters.put("LOGO_IMG",fileLogo);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        if(this.rptParameter != null){
            for (Map.Entry<String, Object> entry : this.rptParameter.entrySet()) {
                parameters.put(entry.getKey(), entry.getValue());
            }
        }
        return parameters;
    }
    public void setReportParametersExt(Map<String, Object>parametersMap){
        for (Map.Entry<String, Object> entry : parametersMap.entrySet()) {
            this.rptParameter.put(entry.getKey(), entry.getValue());
        }
    }


    public JasperPrint generateReport(RptRequestDTO rptRequestDTO) throws Exception {

        this.validation(rptRequestDTO);
        String rptFileName = rptRequestDTO.getRptFileName();
        String rptSubFolderName = rptRequestDTO.getRptSubFolderName();

        try {

//            File file = ResourceUtils.getFile("classpath:reports");
//            /*Get absolute path*/
//            String baseReportFolderPath = file.getAbsolutePath();
//            System.out.println("Base report folder path : "+baseReportFolderPath);
//            String fileSeparator = FileSystems.getDefault().getSeparator();
//            String targetReportPath = baseReportFolderPath + fileSeparator + rptFileName;
//            if(rptSubFolderName != null && !rptSubFolderName.equals("")) targetReportPath = baseReportFolderPath + fileSeparator + rptSubFolderName + fileSeparator + rptFileName;
//            System.out.println("Target report path is : "+targetReportPath);
//            JasperReport jasperReport = JasperCompileManager.compileReport( targetReportPath + ".jrxml" );

            String reportRootPath = env.getProperty("cms.reports.root.path");
            String baseReportFolderPath = reportRootPath;
            String fileSeparator = FileSystems.getDefault().getSeparator();
            String targetReportPath = baseReportFolderPath + fileSeparator + rptFileName;
            JasperReport jasperReport = JasperCompileManager.compileReport( targetReportPath + ".jrxml" );

            // Add parameters
            Map<String, Object> parameters = new HashMap<>();
            parameters = this.setReportParameters(parameters);
            parameters.put("SUBREPORT_DIR", baseReportFolderPath + fileSeparator);

            Connection dbConn = dataSource.getConnection();
            // Fill the report
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameters, dbConn);
            dbConn.close();

            return jasperPrint;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }


    public JasperPrint generateReport_withFilterParams(RptRequestDTO rptRequestDTO, Map<String, String> requestMap) throws Exception {

        // for order info report start ----------------------------
        this.rptParameter.put("P_ORDER_NUM", null);
        this.rptParameter.put("P_CUST_NAMW", null);
        this.rptParameter.put("P_CUST_PHONE", null);
        this.rptParameter.put("P_DELIVERY_FROM_DATE", null);
        this.rptParameter.put("P_DELIVERY_TO_DATE", null);

        if(requestMap.containsKey("filterKey")){
            String filterKey = requestMap.get("filterKey");
            String searchValue = requestMap.get("searchValue");
            if(filterKey != null && filterKey.equals("byOrderNum")) {
                if(searchValue != null && !searchValue.isEmpty()){
                    this.rptParameter.put("P_ORDER_NUM", Integer.parseInt(searchValue));
                }
            }
            if(filterKey != null && filterKey.equals("byCustomer")) {
                if(searchValue != null && !searchValue.isEmpty()){
                    this.rptParameter.put("P_CUST_NAME", searchValue);
                }
            }
            if(filterKey != null && filterKey.equals("byPhone")) {
                if(searchValue != null && !searchValue.isEmpty()){
                    this.rptParameter.put("P_CUST_PHONE", searchValue);
                }
            }
            if(filterKey != null && filterKey.equals("byDDate")) {
                if(searchValue != null && !searchValue.isEmpty()){
                    this.rptParameter.put("P_DELIVERY_FROM_DATE", searchValue);
                }
                String searchValue_temp_2d = requestMap.get("searchValue_temp_2d");
                if(searchValue != null && !searchValue.isEmpty()){
                    this.rptParameter.put("P_DELIVERY_FROM_DATE", searchValue);
                }
            }
        }
        // for order info report end -----------------------------

        // Others
//        parameters.put("start_date", startDate);
//        parameters.put("end_date", endDate);

        return this.generateReport(rptRequestDTO);
    }


}
