package com.ekfc.foodcraft.services.report;

import org.springframework.http.ResponseEntity;

public interface SalesRptByCategoryService {
    ResponseEntity<?> getRptData();
}
