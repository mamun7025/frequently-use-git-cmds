package com.ekfc.foodcraft.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekfc.foodcraft.dao.LoyaltyDAO;
import com.ekfc.foodcraft.model.LoyaltyEarnBurnModel;
import com.ekfc.foodcraft.model.LoyaltyUser;

@Service
public class LoyaltyService {
	
	@Autowired
	private LoyaltyDAO loyaltyDAO;

	public List<LoyaltyEarnBurnModel> getLoyaltyData() {
		return loyaltyDAO.getLoyaltyData();
	}
	public List<LoyaltyUser> getUserLoyaltyPoints(String userId){
		return loyaltyDAO.getUserLoyaltyPoints(userId);
	}

}
