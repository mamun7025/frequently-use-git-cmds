package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.HomepageDAO;
import com.ekfc.foodcraft.dao.ProductDAO;
import com.ekfc.foodcraft.model.Product;
import com.ekfc.foodcraft.model.homepage.CarouselModel;
import com.ekfc.foodcraft.model.homepage.CustFavoriteFullModel;
import com.ekfc.foodcraft.model.homepage.CustFavoriteModel;
import com.ekfc.foodcraft.model.homepage.ExploreModel;
import com.ekfc.foodcraft.model.homepage.OurMenuModel;
import com.ekfc.foodcraft.utils.ProductUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.luciad.imageio.webp.WebPWriteParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.List;

@Component
public class HomepageService {

    @Autowired
    private HomepageDAO homepageDAO;

    @Autowired
    private Environment env;

    @Autowired
    private ProductUtils productUtils;

    @Autowired
    private ProductDAO productDAO;

    private static final int[] RGB_MASKS = {0xFF0000, 0xFF00, 0xFF};
    private static final ColorModel RGB_OPAQUE =
            new DirectColorModel(32, RGB_MASKS[0], RGB_MASKS[1], RGB_MASKS[2]);

    public Map<String, Object> getHomePageCarouselComponents() {
        final Map<String, Object> resultMap = new HashMap<>();

        final List<CarouselModel> courousels = homepageDAO.getHomepageCarouselComponents();

        resultMap.put("result", courousels);

        return resultMap;
    }

    public Map<String, Object> addCarouselBanner(CarouselModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final boolean downloadedDesktop = writeCarouselImage(requestObj.getImageDataDesktop(), requestObj.getImgPathDesktop());
        final boolean downloadedMobile = writeCarouselImage(requestObj.getImageDataMobile(), requestObj.getImgPathMobile());
        if(downloadedDesktop && downloadedMobile) {
            final boolean created = homepageDAO.addCarouselBanner(requestObj);
            if (created) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Unable to Process, please try again later");
        }
        return resultMap;
    }

    private boolean writeCarouselImage(String data, String path) {
        final StringBuilder sb = new StringBuilder();

        final String[] pathSplit = path.split("/");
        final String imageName = pathSplit[pathSplit.length - 1];
        final String formatName = imageName.split("\\.")[1];
        final byte[] data1 = Base64.getDecoder().decode(data.getBytes(StandardCharsets.UTF_8));
        InputStream targetStream = new ByteArrayInputStream(data1);
        try {
            resizeAndDownloadHomePageCarouselImage(targetStream, imageName, formatName);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private String resizeAndDownloadHomePageCarouselImage(final InputStream stream, final String name, final String format) throws IOException, InterruptedException {
        System.out.println("Downloading file " + name + ".....");
        final String productImagePath = env.getProperty("cms.path.homepage.carousel.images");
        final String productImagePathOutput = env.getProperty("cms.path.homepage.carousel.images.output");
        // Obtain an image to encode from somewhere
        BufferedImage image = ImageIO.read(stream);

        // Image img = ImageIO.read(stream);
        Image img = image.getScaledInstance(2000,740, Image.SCALE_SMOOTH);

        PixelGrabber pg = new PixelGrabber(img, 0, 0, 2000, 740, true);
        pg.grabPixels();
        int width = pg.getWidth(), height = pg.getHeight();

        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

        // ImageIO.write(bi, format, new File(productImagePath+name));
        // Obtain a WebP ImageWriter instance
        ImageWriter writer = ImageIO.getImageWritersByMIMEType("image/" + format.toLowerCase()).next();

        // Configure encoding parameters
         WebPWriteParam writeParam = new WebPWriteParam(writer.getLocale());
         writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
         writeParam.setCompressionType("Lossless");

        // Configure the output on the ImageWriter
         writer.setOutput(new FileImageOutputStream(new File(productImagePath + name)));
         writer.setOutput(new FileImageOutputStream(new File(productImagePathOutput + name)));

        // Encode
         writer.write(null, new IIOImage(image, null, null), writeParam);
        return "";
    }

    public Map<String, Object> removeCarouselBanner(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("id")) {
            final int id = Integer.valueOf(reqMap.get("id").toString());
            final boolean removed = homepageDAO.removeCarouselBanner(id);
            if (removed) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }

    public Map<String, Object> updateCarouselBanner(CarouselModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final String imageDataDesktop = requestObj.getImageDataDesktop();
        final String imageDataMobile = requestObj.getImageDataMobile();
        if(imageDataDesktop != "" && imageDataDesktop != null && imageDataMobile != "" && imageDataMobile != null){
            final boolean downloadedDesktop = writeCarouselImage(requestObj.getImageDataDesktop(), requestObj.getImgPathDesktop());
            final boolean downloadedMobile = writeCarouselImage(requestObj.getImageDataMobile(), requestObj.getImgPathMobile());
            if(downloadedDesktop && downloadedMobile) {
                final boolean updated = homepageDAO.updateCarouselBanner(requestObj);
                if (updated) {
                    resultMap.put("result", true);
                } else {
                    resultMap.put("error", "Unable to Process, please try again later");
                }
            }else{
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }
        else{
            final boolean updated = homepageDAO.updateCarouselBanner(requestObj);
            if (updated) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }

        return resultMap;
    }

    public Map<String, Object> publishCarouselBanner() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<CarouselModel> activeCarousel = homepageDAO.getActiveHomepageCarouselComponents();
            final String jsonPathPrefix = env.getProperty("cms.path.homepage.carousel.json", "");

            File file = Paths.get(jsonPathPrefix + "home_carousel.js").toFile();
            Gson gson = new Gson();
            FileWriter writer = new FileWriter(file);
            StringBuffer strBuffer = new StringBuffer();
            strBuffer.append("var mainBannerList").append(" = ").append(gson.toJson(activeCarousel));
            writer.write(strBuffer.toString());
            writer.flush();
            writer.close();
            resultMap.put("result", "Homepage active carousel components are published to home_carousel.js");
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please try again.");
        }

        return resultMap;
    }

    public Map<String, Object> getExploreOurMenuComponents() {
        final Map<String, Object> resultMap = new HashMap<>();

        final List<ExploreModel> exploreModels = homepageDAO.getExploreOurMenuComponents();

        resultMap.put("result", exploreModels);

        return resultMap;
    }

    public Map<String, Object> addExploreMenu(ExploreModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
        if(downloaded) {
            final boolean created = homepageDAO.addExploreMenu(requestObj);
            if (created) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Unable to Process, please try again later");
        }
        return resultMap;
    }

    private boolean writeGifImage_noResize(String imgFormat, String imgName, byte[] imgData, String dstFolder){
        if(imgFormat.equalsIgnoreCase("gif")){
            Path dstFilePath = Paths.get(dstFolder, imgName);
            try {
                // BufferedImage image = ImageIO.read(stream);
                // ImageIO.write(image, "gif", new File(productImagePath + name));
                Files.write(dstFilePath, imgData);
                return true;
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        return false;
    }

    private boolean writeExploreMenuImage(String data, String path) {
        final StringBuilder sb = new StringBuilder();

        final String[] pathSplit = path.split("/");
        final String imageName = pathSplit[pathSplit.length - 1];
        final String formatName = imageName.split("\\.")[1];
        final byte[] data1 = Base64.getDecoder().decode(data.getBytes(StandardCharsets.UTF_8));
        // check GIF image
        if(formatName.equalsIgnoreCase("gif")){
            writeGifImage_noResize(formatName, imageName, data1, env.getProperty("cms.path.homepage.explore.images"));
            return writeGifImage_noResize(formatName, imageName, data1, env.getProperty("cms.path.homepage.explore.images.output"));
        }
        InputStream targetStream = new ByteArrayInputStream(data1);
        try {
            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.homepage.explore.images");
            targetStream = new ByteArrayInputStream(data1);
            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.homepage.explore.images.output");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private String resizeAndDownloadGenericImage(final InputStream stream, final String name, final String format, int width, int height, String confPath) throws IOException, InterruptedException {
        System.out.println("Downloading file " + name + ".....");
        final String productImagePath = env.getProperty(confPath);

        // Obtain an image to encode from somewhere
        BufferedImage image = ImageIO.read(stream);

        // Image img = ImageIO.read(stream);
        Image img = image.getScaledInstance(width,height, Image.SCALE_SMOOTH);

        PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);
        pg.grabPixels();

        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

        // ImageIO.write(bi, format, new File(productImagePath+name));
        // Obtain a WebP ImageWriter instance
        ImageWriter writer = ImageIO.getImageWritersByMIMEType("image/" + format.toLowerCase()).next();

        // Configure encoding parameters
        WebPWriteParam writeParam = new WebPWriteParam(writer.getLocale());
        writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        writeParam.setCompressionType("Lossless");

        // Configure the output on the ImageWriter
        writer.setOutput(new FileImageOutputStream(new File(productImagePath + name)));

        // Encode
        writer.write(null, new IIOImage(image, null, null), writeParam);
        return "";
    }

    public Map<String, Object> updateExploreMenu(ExploreModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final String imageData = requestObj.getImgData();
        if(imageData != "" && imageData != null){
            final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
            if(downloaded) {
                final boolean updated = homepageDAO.updateExploreMenu(requestObj);
                if (updated) {
                    resultMap.put("result", true);
                } else {
                    resultMap.put("error", "Unable to Process, please try again later");
                }
            }else{
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }
        else{
            final boolean updated = homepageDAO.updateExploreMenu(requestObj);
            if (updated) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }

        return resultMap;
    }

    public Map<String, Object> removeExploreMenu(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("id")) {
            final int id = Integer.valueOf(reqMap.get("id").toString());
            final boolean removed = homepageDAO.removeExploreMenu(id);
            if (removed) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }

    public Map<String, Object> publishExploreMenu() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<ExploreModel> activeCarousel = homepageDAO.getActiveExploreOurMenuComponents();
            final String jsonPathPrefix = env.getProperty("cms.path.homepage.explore.json", "");
            File file = Paths.get(jsonPathPrefix + "home_explore.js").toFile();
            Gson gson = new Gson();
            FileWriter writer = new FileWriter(file);
            StringBuffer strBuffer = new StringBuffer();
            strBuffer.append("var exploreOurRangeList").append(" = ").append(gson.toJson(activeCarousel));
            writer.write(strBuffer.toString());
            writer.flush();
            writer.close();
            resultMap.put("result", "Homepage active explore components are published to home_explore.js");
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please try again.");
        }

        return resultMap;
    }

    public Map<String, Object> getAllCustomerFavorites() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<CustFavoriteModel> custFavorites = homepageDAO.getAllCustomerFavorites();
            resultMap.put("result", custFavorites);
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please contact IT helpdesk to resolve your issue.");
        }
        return resultMap;
    }
    
    public Map<String, Object> getCampProducts(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<CustFavoriteModel> custFavorites = homepageDAO.getCustomerFavoritesbyId(reqMap);
            resultMap.put("result", custFavorites.get(0));
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please contact IT helpdesk to resolve your issue.");
        }
        return resultMap;
    }
    
    public Map<String, Object> delCamp(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            boolean isdeleted = homepageDAO.delCustomerFavoritesbyId(reqMap);
            resultMap.put("result", isdeleted);
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please contact IT helpdesk to resolve your issue.");
        }
        return resultMap;
    }

    public Map<String, Object> addCustomerFavorites(CustFavoriteModel customerFavModel) {
        final Map<String, Object> resultMap = new HashMap<>();
        final boolean added = homepageDAO.addCustomerFavorites(customerFavModel);
        if(added){
            resultMap.put("result", "Customer Favorites Added successfully");
        }else{
            resultMap.put("error", "Unable to process, please contact the helpdesk to resolve your issue.");
        }
        return resultMap;
    }

    public Map<String, Object> updateCustomerFavorites(CustFavoriteModel customerFavModel) {
        final Map<String, Object> resultMap = new HashMap<>();
        final boolean updated = homepageDAO.updateCustomerFavorites(customerFavModel);
        if(updated){
            resultMap.put("result", "Customer Favorites Updated successfully");
        }else{
            resultMap.put("error", "Unable to process, please contact the helpdesk to resolve your issue.");
        }
        return resultMap;
    }

    public Map<String, Object> publishCustomerFavorites() {
        final Map<String, Object> resultMap = new HashMap<>();

        final List<CustFavoriteModel> custFavoriteModels = homepageDAO.getAllActiveCustomerFavorites();
        final List<CustFavoriteFullModel> finalCustList = new ArrayList<>();

        custFavoriteModels.forEach(
                customerFavModel -> {
                    final List<Product> finalProductsList = new ArrayList<>();
                    CustFavoriteFullModel fullCustModel = new CustFavoriteFullModel();
                    fullCustModel.setActive(customerFavModel.isActive());
                    fullCustModel.setName(customerFavModel.getName());
                    fullCustModel.setContent(customerFavModel.getContent());
                    fullCustModel.setTemplate(customerFavModel.getTemplate());
                    fullCustModel.setId(customerFavModel.getId());
                    final String products = customerFavModel.getProducts();
                    if(products != "" && products != null){
                        final String[] productsArray = products.split(",");
                        for(int i=0; i < productsArray.length; i++){
                            String prdCode = productsArray[i].strip();
                            if(prdCode != ""){
                                final Product prdModel = productDAO.getProductForCode(prdCode);
                                if(prdModel != null){
                                    finalProductsList.add(prdModel);
                                }
                            }
                        }
                        try{
                            List<Map<String, Object>> prdList = productUtils.transformProducts(finalProductsList);
                            fullCustModel.setProducts(prdList);
                            finalCustList.add(fullCustModel);
                        }catch(Exception ex){
                            ex.printStackTrace();
                            resultMap.put("error", "Unable to Process, please contact IT helpdesk to resolve your issue.");
                        }
                    }
                }
        );
        resultMap.put("result", finalCustList);

        if(!resultMap.containsKey("error")){
            try{
                final String jsonPathPrefix = env.getProperty("cms.path.homepage.favorites.json", "");
                File file = Paths.get(jsonPathPrefix + "home_cust_favorites.js").toFile();
                Gson gson = new Gson();
                FileWriter writer = new FileWriter(file);
                StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("var custFavJsonList").append(" = ").append(gson.toJson(finalCustList));
                writer.write(strBuffer.toString());
                writer.flush();
                writer.close();
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please contact IT helpdesk to resolve your issue.");
            }
        }
        return resultMap;
    }

    public void changeVersion() {
        try {
            final String filePathPrefix = env.getProperty("cms.path.index.html");
            final String indexFilePath = filePathPrefix + "/index.html";
            System.out.println("Reading the HTML file to update the version of the Assets");
            final Integer version = homepageDAO.getVersionNumber();
            int subVersion = 0;
            if(version != null){
                subVersion = version;
            }
            final Integer newVersion = homepageDAO.setVersionNumber(subVersion);
            File file = new File(indexFilePath);
            FileReader fr=new FileReader(file);   //reads the file
            BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream
            StringBuffer sb=new StringBuffer();    //constructs a string buffer with no characters
            String line;
            while((line=br.readLine())!=null)
            {
                line = line.replaceAll("\\?v?V?\\=\\d+", "?v=" + newVersion);
                sb.append(line);      //appends line to string buffer
                sb.append("\n");     //line feed
            }
            fr.close();    //closes the stream and release the resources
            BufferedWriter bwr = new BufferedWriter(new FileWriter(new File(indexFilePath)));

            System.out.println("Updating the version of the index.html assets");
            bwr.write(sb.toString());

            //flush the stream
            bwr.flush();

            //close the stream
            bwr.close();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public Map<String, Object> updateExploreOurMenuSorting(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryList")){

        	final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
            try{
                for(Map<String, Object> category: categoryList){
                    this.updateExploreOurRangeOrder(category);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateExploreOurRangeOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            int order = (int)reqMap.get("order");
            try {

                final boolean isUpdated = homepageDAO.updateOrder(code, order);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCarouselOurMenuSorting(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryList")){

        	final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
            try{
                for(Map<String, Object> category: categoryList){
                    this.updateCarouselOrder(category);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCarouselOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            int order = (int)reqMap.get("order");
            try {

                final boolean isUpdated = homepageDAO.updateCarouselOrder(code, order);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    public Map<String, Object> getCraftPerfectMealsComponents() {
        final Map<String, Object> resultMap = new HashMap<>();

        final List<ExploreModel> exploreModels = homepageDAO.getCraftPerfectMealsComponents();

        resultMap.put("result", exploreModels);

        return resultMap;
    }

    public Map<String, Object> addCraftPerfectMeals(ExploreModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
        if(downloaded) {
            final boolean created = homepageDAO.addCraftPerfectMeals(requestObj);
            if (created) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Unable to Process, please try again later");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCraftPerfectMealsSorting(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryList")){

        	final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
            try{
                for(Map<String, Object> category: categoryList){
                    this.updateCraftPerfectMealsOrder(category);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCraftPerfectMealsOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            int order = (int)reqMap.get("order");
            try {

                final boolean isUpdated = homepageDAO.updateCraftPerfectMealsOrder(code, order);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCraftPerfectMeals(ExploreModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final String imageData = requestObj.getImgData();
        if(imageData != "" && imageData != null){
            final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
            if(downloaded) {
                final boolean updated = homepageDAO.updateCraftPerfectMeals(requestObj);
                if (updated) {
                    resultMap.put("result", true);
                } else {
                    resultMap.put("error", "Unable to Process, please try again later");
                }
            }else{
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }
        else{
            final boolean updated = homepageDAO.updateCraftPerfectMeals(requestObj);
            if (updated) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }

        return resultMap;
    }

    public Map<String, Object> removeCraftPerfectMeals(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("id")) {
            final int id = Integer.valueOf(reqMap.get("id").toString());
            final boolean removed = homepageDAO.removeCraftPerfectMeals(id);
            if (removed) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }

    public Map<String, Object> publishCraftPerfectMeals() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<ExploreModel> activeCarousel = homepageDAO.getActiveCraftPerfectMealsComponents();
            final String jsonPathPrefix = env.getProperty("cms.path.homepage.craft.meals.json", "");
            File file = Paths.get(jsonPathPrefix + "home_craft_meals.js").toFile();
            Gson gson = new Gson();
            FileWriter writer = new FileWriter(file);
            StringBuffer strBuffer = new StringBuffer();
            strBuffer.append("var craftPerfectMealsList").append(" = ").append(gson.toJson(activeCarousel));
            writer.write(strBuffer.toString());
            writer.flush();
            writer.close();
            resultMap.put("result", "Homepage active craft meals components are published to home_craft_meals.js");
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please try again.");
        }

        return resultMap;
    }
    
    public Map<String, Object> getOurMenuComponents() {
        final Map<String, Object> resultMap = new HashMap<>();

        final List<OurMenuModel> exploreModels = homepageDAO.getOurMenuComponents();

        resultMap.put("result", exploreModels);

        return resultMap;
    }

    public Map<String, Object> addOurMenuComponents(Map<String, Object> reqMap) {
    	ObjectMapper obj = new ObjectMapper();
    	OurMenuModel requestObj = obj.convertValue(reqMap, OurMenuModel.class);
        final Map<String, Object> resultMap = new HashMap<>();

        final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
        if(downloaded) {
            final boolean created = homepageDAO.addOurMenuComponents(requestObj);
            if (created) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Unable to Process, please try again later");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateOurMenuComponentsSorting(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryList")){

        	final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
            try{
                for(Map<String, Object> category: categoryList){
                    this.updateOurMenuComponentsOrder(category);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateOurMenuComponentsOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            int order = (int)reqMap.get("order");
            try {

                final boolean isUpdated = homepageDAO.updateCraftPerfectMealsOrder(code, order);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    public Map<String, Object> updateOurMenuComponents(OurMenuModel requestObj) {
        final Map<String, Object> resultMap = new HashMap<>();

        final String imageData = requestObj.getImgData();
        if(imageData != "" && imageData != null){
            final boolean downloaded = writeExploreMenuImage(requestObj.getImgData(), requestObj.getImgPath());
            if(downloaded) {
                final boolean updated = homepageDAO.updateOurMenuComponents(requestObj);
                if (updated) {
                    resultMap.put("result", true);
                } else {
                    resultMap.put("error", "Unable to Process, please try again later");
                }
            }else{
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }
        else{
            final boolean updated = homepageDAO.updateOurMenuComponents(requestObj);
            if (updated) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }

        return resultMap;
    }

    public Map<String, Object> removeOurMenuComponents(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("id")) {
            final int id = Integer.valueOf(reqMap.get("id").toString());
            final boolean removed = homepageDAO.removeCraftPerfectMeals(id);
            if (removed) {
                resultMap.put("result", true);
            } else {
                resultMap.put("error", "Unable to Process, please try again later");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }

    public Map<String, Object> publishOurMenuComponents() {
        final Map<String, Object> resultMap = new HashMap<>();

        try {
            final List<OurMenuModel> activeCarousel = homepageDAO.getActiveOurMenuComponents();
            final String jsonPathPrefix = env.getProperty("cms.path.homepage.craft.meals.json", "");
            File file = Paths.get(jsonPathPrefix + "home_craft_meals.js").toFile();
            Gson gson = new Gson();
            FileWriter writer = new FileWriter(file);
            StringBuffer strBuffer = new StringBuffer();
            strBuffer.append("var craftPerfectMealsList").append(" = ").append(gson.toJson(activeCarousel));
            writer.write(strBuffer.toString());
            writer.flush();
            writer.close();
            resultMap.put("result", "Homepage active craft meals components are published to home_craft_meals.js");
        }catch (Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "Unable to Process, Please try again.");
        }

        return resultMap;
    }

    
}
