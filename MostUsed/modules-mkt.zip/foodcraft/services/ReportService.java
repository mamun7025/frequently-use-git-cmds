package com.ekfc.foodcraft.services;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.dao.ReportDAO;
import com.ekfc.foodcraft.model.OrdersDetails;
import com.ekfc.foodcraft.model.reports.OrderQuanityDTO;

@Component
public class ReportService {

	@Autowired
	private ReportDAO reportDAO;
	
public List<OrderQuanityDTO> getOrderQuantityByCodes(Map<String,Object> reqMap) {
		
		return reportDAO.getOrderQuantityByCodes(reqMap.get("startDate").toString(),reqMap.get("endDate").toString(),reqMap.get("productCodes").toString());
	}
	public List<OrdersDetails> getOrderDetailsForProductCode(Map<String,Object> reqMap) {
		
		
		return reportDAO.getOrderDetailsForProductCode(reqMap.get("startDate").toString(),reqMap.get("endDate").toString(),reqMap.get("productCodes").toString());
	}
	public Map<String, Object> getOrderHistoryByDeliveryDate(Map<String, Object> reqBody){
		return reportDAO.getOrderHistory(reqBody.get("delivery_date").toString());
	}
	
	public ByteArrayInputStream load(String deliveryDate) {
		return reportDAO.downloadExcel(deliveryDate);
	}
}
