package com.ekfc.foodcraft.services;

import java.util.Map;
import com.ekfc.foodcraft.model.OrdersHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.ekfc.foodcraft.dao.OrdersDAO;

@Component
public class OrderService {

	@Autowired
	OrdersDAO ordersDAO;
	
//	public Map<String, Object> getOrderHistory(Map<String, Object> reqMap){
//		return ordersDAO.getOrderHistory(reqMap);
//	}
	
	public Map<String, Object> getOrderDetails(Map<String, Object> reqMap){
		return ordersDAO.getOrderDetails(reqMap);
	}
	
	public Map<String, Object> updateOrderStatus(Map<String, Object> reqMap){
		return ordersDAO.updateOrderStatusList(reqMap);
	}
	
	public boolean updateProductStatus(Map<String, Object> reqMap){
		return ordersDAO.updateProductStatusList(reqMap);
	}
	
	public Map<String, Object> getOrderHistory(Map<String, Object> reqMap){
		return ordersDAO.getOrderHistory(reqMap);
	}

	public OrdersHeader getInvoiceDocument(Map<String, Object> reqMap){
		return ordersDAO.getOrderHeaderInfo(reqMap);
	}
	
	public Map<String, Object> createERPRequest(Map<String, Object> reqMap){
		Map<String , Object> orderData = ordersDAO.getOrderDetailsForERPRequest(reqMap);
		return ordersDAO.triggerERPRequest(orderData);
	}


}
