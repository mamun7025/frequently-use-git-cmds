package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.WalletDAO;
import com.ekfc.foodcraft.model.Wallet;
import com.ekfc.foodcraft.model.generic.PaginatedResponse;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class WalletService {

    private static final Logger logger = LoggerFactory.getLogger(WalletService.class);
    private final WalletDAO walletDAO;

    @Autowired
    public WalletService(WalletDAO walletDAO) {
        this.walletDAO = walletDAO;
    }

    public boolean create(Map<String, String> requestMap) {
        return walletDAO.create(requestMap);
    }

    public Wallet read(Map<String, String> requestMap) {
        return walletDAO.read(requestMap);
    }

    public boolean update(Map<String, String> requestMap) {
        return walletDAO.update(requestMap);
    }

    public ResponseEntity<?> getAllPaginated(Map<String, String> filterParams) {
        try {
            Map<String, Object> dataPage = walletDAO.getPaginatedData(filterParams);
            PaginatedResponse response = new PaginatedResponse(
                    true,
                    HttpStatus.OK.value(),
                    "Success",
                    (Integer)dataPage.get("totalElements"),
                    (Integer)dataPage.get("totalPages"),
                    (Integer)dataPage.get("currentPage") ,
                    (Integer)dataPage.get("pageSize") ,
                    dataPage.get("content")
            );
            return ResponseEntity.ok(response);
        } catch (Exception ex){
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


    public List<LinkedHashMap<String, Object>> getActivityLogData(Map<String, String> requestMap) {
        return walletDAO.getActivityLogData(requestMap);
    }
}
