package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.CategoryDAO;
import com.ekfc.foodcraft.dao.ProductDAO;
import com.ekfc.foodcraft.model.*;
import com.ekfc.foodcraft.utils.ProductUtils;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;

@Component
public class ProductService {

    @Autowired
    private ProductDAO productDAO;

    @Autowired
    private CategoryDAO categoryDAO;

    @Autowired
    private Environment env;

    @Autowired
    private ProductUtils productUtils;


    private static final int[] RGB_MASKS = {0xFF0000, 0xFF00, 0xFF};
    private static final ColorModel RGB_OPAQUE =
            new DirectColorModel(32, RGB_MASKS[0], RGB_MASKS[1], RGB_MASKS[2]);

    public void getAllProducts() throws IOException {
        final List<Product> products = productDAO.getProducts();
        productUtils.createJsonLoad(products);
    }

    public Map<String, Object> getAllProductsForCategory(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        final ObjectMapper om = new ObjectMapper();
        if(reqMap.containsKey("categoryId")){
            final String categoryId = reqMap.get("categoryId").toString();
            List<Product> products = productDAO.getAllProductsForCategory(categoryId);
            Comparator productMapComparator = new Comparator<Product>() {
                public int compare(Product o1, Product o2) {
                    try{
                    return ComparisonChain.start()
                            .compare(
                                    ((o1.getOrderJson() != null) && (om.readValue(o1.getOrderJson(), Map.class)).get(categoryId) != null) ? ((Map<String, Integer>)om.readValue(o1.getOrderJson(), Map.class)).get(categoryId): 500000,
                                    ((o2.getOrderJson() != null) && (om.readValue(o2.getOrderJson(), Map.class)).get(categoryId) != null) ? ((Map<String, Integer>)om.readValue(o2.getOrderJson(), Map.class)).get(categoryId): 500000,
                                    Ordering.natural().nullsLast())
                            .result();
                    }catch (Exception ex){
                        ex.printStackTrace();
                        return -1;
                    }
                }
            };
            Collections.sort(products, productMapComparator);
            resultMap.put("result", products);
        }else{
            resultMap.put("error", "Bad Request");
        }

        return resultMap;
    }

    public Map<String, Object> getProductForCode(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("productCode")){
            final String productCode = reqMap.get("productCode").toString();
            Product product = productDAO.getProductForCode(productCode);
            if(null != product){
                resultMap.put("result", product);
            }
        }else{
            resultMap.put("error", "Bad Request");
        }

        return resultMap;
    }

    public Map<String, Object> updateProductForCode(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        final ObjectMapper om = new ObjectMapper();
        final UpdateProduct updateProductReq = om.convertValue(reqMap, UpdateProduct.class);
       
        boolean updated = productDAO.updateProductForCode(updateProductReq, this.getUpdateNutritionImagePath(updateProductReq));

        resultMap.put("result", updated);
        // invoking a new thread to downnload files
        final Runnable runnable = new Runnable() {

            public void run() {
                try{
                	writeNutriFactsImage(updateProductReq);
                }catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        };
        Thread thread = new Thread(runnable);
        thread.start();

        return resultMap;
    }

    public Map<String, Object> udpateProductMediaForCode(Map<String, Object> reqMap) throws IOException {
        final Map<String, Object> resultMap = new HashMap<>();

        final ObjectMapper om = new ObjectMapper();
        final UpdateProductMedia updateProductReq = om.convertValue(reqMap, UpdateProductMedia.class);

        boolean updated = productDAO.udpateProductMediaForCode(updateProductReq, this.getImagePath(updateProductReq));
        resultMap.put("result", updated);

        // invoking a new thread to downnload files
        final Runnable runnable = new Runnable() {

            public void run() {
                try{
                    writeImage(updateProductReq);
                }catch(Exception ex){
                    ex.printStackTrace();
                }
            }
        };
        Thread thread = new Thread(runnable);
        thread.start();

        return resultMap;
    }

    private boolean writeImage(UpdateProductMedia updateProductMedia) throws IOException {
        final StringBuilder sb = new StringBuilder();
        for(final ImageModel p: updateProductMedia.getProducts()){
            final String[] pathSplit = p.getPath().split("/");
            final String imageName = pathSplit[pathSplit.length - 1];
            final String formatName = p.getHeader().split("/")[1];
            final byte[] data = Base64.getDecoder().decode(p.getValue().getBytes(StandardCharsets.UTF_8));
            InputStream targetStream = new ByteArrayInputStream(data);
            try {
                resizeAndDownload(targetStream, imageName, formatName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        final String path = sb.toString();
        return false;
    }
    
    private boolean writeNutriFactsImage(UpdateProduct updateProduct) throws IOException {
        final StringBuilder sb = new StringBuilder();
        for(final ImageModel p: updateProduct.getNutriFacts()){
            if(p.getValue() != "" && p.getValue() != null) {
                final String[] pathSplit = p.getPath().split("/");
                final String imageName = pathSplit[pathSplit.length - 1];
                final String formatName = p.getHeader().split("/")[1];
                final byte[] data = Base64.getDecoder().decode(p.getValue().getBytes(StandardCharsets.UTF_8));
                InputStream targetStream = new ByteArrayInputStream(data);
                try {
                    resizeAndDownloadNutriFactImages(targetStream, imageName, formatName);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        final String path = sb.toString();
        return false;
    }
    
    private boolean writeCreateNutriFactsImage(CreateProduct createProduct) throws IOException {
        final StringBuilder sb = new StringBuilder();
        for(final ImageModel p: createProduct.getNutriFacts()){
            final String[] pathSplit = p.getPath().split("/");
            final String imageName = pathSplit[pathSplit.length - 1];
            final String formatName = p.getHeader().split("/")[1];
            final byte[] data = Base64.getDecoder().decode(p.getValue().getBytes(StandardCharsets.UTF_8));
            InputStream targetStream = new ByteArrayInputStream(data);
            try {
            	resizeAndDownloadNutriFactImages(targetStream, imageName, formatName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        final String path = sb.toString();
        return false;
    }
    
    private String getImagePath(UpdateProductMedia updateProductMedia){
        final StringBuilder sb = new StringBuilder();
        updateProductMedia.getProducts().forEach(p-> {
            sb.append(p.getPath())
                    .append(",");
        });

        final String path = sb.toString();
        return path.substring(0, path.length() - 1);
    }
    
    private String getUpdateNutritionImagePath(UpdateProduct updateProduct){
        final StringBuilder sb = new StringBuilder();
        updateProduct.getNutriFacts().forEach(p-> {
            sb.append(p.getPath())
                    .append(",");
        });

        final String path = sb.toString();
        if(path.length() > 0) {
            return path.substring(0, path.length() - 1);
        }
        return "";
    }
    
    private String getCreateNutritionImagePath(CreateProduct createProduct){
        final StringBuilder sb = new StringBuilder();
        if(createProduct.getNutriFacts() != null) {
        createProduct.getNutriFacts().forEach(p-> {
            sb.append(p.getPath())
                    .append(",");
        });

        final String path = sb.toString();
        return path.substring(0, path.length() - 1);
        }
        else {
        	return null;
        }
    }

    private String resizeAndDownload(final InputStream stream, final String name, final String format) throws IOException, InterruptedException {
        System.out.println("Downloading file " + name + ".....");
        final String productImagePath = env.getProperty("cms.path.product.images");
        final String outputProductImagePath = env.getProperty("cms.path.product.images.output");
        Image img = ImageIO.read(stream);
        img = img.getScaledInstance(1200,1076, Image.SCALE_SMOOTH);

        PixelGrabber pg = new PixelGrabber(img, 0, 0, 1200, 1076, true);
        pg.grabPixels();
        int width = pg.getWidth(), height = pg.getHeight();

        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

        ImageIO.write(bi, format, new File(productImagePath+name));
        ImageIO.write(bi, format, new File(outputProductImagePath+name));
        return "";
    }
    
    private String resizeAndDownloadNutriFactImages(final InputStream stream, final String name, final String format) throws IOException, InterruptedException {
        System.out.println("Downloading file " + name + ".....");
        final String productImagePath = env.getProperty("cms.path.nutritional.facts.images");
        final String productImagePathOutput = env.getProperty("cms.path.nutritional.facts.images.output");
        Image img = ImageIO.read(stream);
        img = img.getScaledInstance(1200,1076, Image.SCALE_SMOOTH);

        PixelGrabber pg = new PixelGrabber(img, 0, 0, 1200, 1076, true);
        pg.grabPixels();
        int width = pg.getWidth(), height = pg.getHeight();

        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

        ImageIO.write(bi, format, new File(productImagePath+name));
        ImageIO.write(bi, format, new File(productImagePathOutput+name));
        return "";
    }

    public Map<String, Object> addCategoryToProduct(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        final ObjectMapper om = new ObjectMapper();
        final ProductCategoryUpdate categoryUpdate = om.convertValue(reqMap, ProductCategoryUpdate.class);
        final Product product = productDAO.getProductForCode(categoryUpdate.getProductCode());

        if(null != product){
            String categoriesStr = product.getCategories();
            categoriesStr += " > " + categoryUpdate.getCategoryId();
            categoryUpdate.setCategoryId(categoriesStr);
            categoryUpdate.setCategoryList(createCategoryList(categoriesStr));
            boolean updated = productDAO.addProductCategory(categoryUpdate);
            resultMap.put("result", updated);
        }else{
            resultMap.put("error", "Unable to Process");
        }

        return resultMap;
    }

    public Map<String, Object> removeCategoryFromTheProduct(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        final ObjectMapper om = new ObjectMapper();
        final ProductCategoryUpdate categoryUpdate = om.convertValue(reqMap, ProductCategoryUpdate.class);
        final Product product = productDAO.getProductForCode(categoryUpdate.getProductCode());

        if(null != product){
            String categoriesStr = product.getCategories();
            final String[] catSplit = categoriesStr.split(" > ");
            String finalString = "";
            for(String c: catSplit){
                if(! c.equalsIgnoreCase(categoryUpdate.getCategoryId())){
                    finalString += c + " > ";
                }
            }
            if(finalString.indexOf(" > ") > -1){
                categoryUpdate.setCategoryId(finalString.substring(0, finalString.length() - 3));
            }else{
                categoryUpdate.setCategoryId(finalString);
            }
            categoryUpdate.setCategoryList(createCategoryList(finalString));
            boolean updated = productDAO.addProductCategory(categoryUpdate);
            resultMap.put("result", updated);
        }else{
            resultMap.put("error", "Unable to Process");
        }

        return resultMap;
    }

    private String createCategoryList(String catStr){
        String[] strSplit = catStr.split(" > ");
        String categoriesListString = "";
        for(String s: strSplit){
            final Category category = categoryDAO.getCategoryForId(s);
            if(category != null) {
                categoriesListString +=
                        "<a href='#' class='product-list custom-fc-cat-link' data-menu-cat='" + s + "'>"+category.getCategoryName()+"</a>,";
            }
        }
        if(categoriesListString.length() > 1){
            String s =  URLEncoder.encode(categoriesListString.substring(0, categoriesListString.length() - 1));
            s = s.replace("+", "%20");
            return s;
        }else{
            return "";
        }
    }

    public Map<String, Object> createProduct(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();

        final ObjectMapper om = new ObjectMapper();
        final CreateProduct createProductReq = om.convertValue(reqMap, CreateProduct.class);


        final Product product = productDAO.getProductForCode(createProductReq.getCode());
        if(null == product) {
            boolean created = productDAO.createProduct(createProductReq,this.getCreateNutritionImagePath(createProductReq));
            resultMap.put("result", created);
            // invoking a new thread to downnload files
            final Runnable runnable = new Runnable() {

                public void run() {
                    try{
                    	if(createProductReq.getNutriFacts() != null) {
                    	writeCreateNutriFactsImage(createProductReq);
                    	}
                    }catch(Exception ex){
                        ex.printStackTrace();
                    }
                }
            };
            Thread thread = new Thread(runnable);
            thread.start();
        }else{
            resultMap.put("exists", "Product with code already exists.");
        }

        return resultMap;
    }

    public Map<String, Object> updateProductOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("code")) {
            final String productCode = reqMap.get("code").toString();
            Map<String, Integer> order = (Map<String, Integer>) reqMap.get("order");
            try {
                final ObjectMapper om = new ObjectMapper();
                final Product existingProduct = productDAO.getProductForCode(productCode);
                if(existingProduct != null && existingProduct.getOrderJson() != null){
                    final Map<String, Integer> existingOrderMap = om.readValue(
                            existingProduct.getOrderJson(),
                            Map.class
                    );
                    for(Map.Entry<String, Integer> entry: order.entrySet()){
                        existingOrderMap.put(entry.getKey(), entry.getValue());
                    }
                    order = existingOrderMap;
                }
                final String orderJson = om.writeValueAsString(order);
                final boolean isUpdated = productDAO.updateOrderJson(productCode, orderJson);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }

    public Map<String, Object> updateProductOrderList(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("productList")){

            final List<Map<String, Object>> productList = (List<Map<String, Object>>) reqMap.get("productList");
            try{
                for(Map<String, Object> product: productList){
                    this.updateProductOrder(product);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> deleteProduct(Map<String, Object> reqMap){
    	String productCode = reqMap.get("code").toString();
    		boolean isDeletedProduct = productDAO.deleteProduct(productCode);
    		Map<String, Object> resultMap = new HashMap<String, Object>();
    		if(isDeletedProduct) {
    			resultMap.put("result", "Product deleted successfully");
    		}
    		return resultMap;
    }
    
    public Map<String, Object> deleteProductMediaForCode(Map<String, Object> reqMap) throws IOException {
        final Map<String, Object> resultMap = new HashMap<>();
        String code = reqMap.get("code").toString();
        String resultList = productDAO.getProductMediaForCode(code);
        String image = reqMap.get("image").toString();
        String[] tempList = resultList.split(",");
        List<String> arrList = new ArrayList<>(Arrays.asList(tempList));
        arrList.remove(image);
        boolean isDeleted = productDAO.udpateProductMediaForCode(code, arrList.toString());
		/*
		 * for(int i =0; i< arrList.size(); i++) {
		 * if(arrList(i).equalsIgnoreCase(image)) { tempList.remove(tempList[i]); } }
		 */
            resultMap.put("result", isDeleted);        	

        return resultMap;
    }

}
