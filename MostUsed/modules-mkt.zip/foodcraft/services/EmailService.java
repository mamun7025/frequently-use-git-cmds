package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.model.EmailCampaignRequest;
import com.ekfc.foodcraft.utils.ERPUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class EmailService {

    @Autowired
    private Environment env;

    public Map<String, Object> sendEmail(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("emailBody") && reqMap.containsKey("toEmail") && reqMap.containsKey("emailSubject")) {
            final ObjectMapper om = new ObjectMapper();

            final EmailCampaignRequest emailCampaignRequest = om.convertValue(reqMap, EmailCampaignRequest.class);
            final String emailBody = emailCampaignRequest.getEmailBody();
            final String emailSubject = emailCampaignRequest.getEmailSubject();
            final List<String> toEmail = emailCampaignRequest.getToEmail();


                final Runnable newRunnable = new Runnable() {
                    @Override
                    public void run() {
                        synchronized (this){
                            try {
                                if (!CollectionUtils.isEmpty(toEmail)) {
                                    for (final String emailString : toEmail) {
                                        ERPUtil.sendEmailCampaign(
                                                emailBody,
                                                emailString.toLowerCase().strip(),
                                                emailSubject,
                                                env.getProperty("epost.domain.url"), env.getProperty("basic.auth.email.header"),
                                                env.getProperty("send.email.endpoint"));
                                        this.wait(5000);
                                    }
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                };
                final Thread th = new Thread(newRunnable);
                th.start();
                resultMap.put("result", "Email Sent");
        }else{
            resultMap.put("error", "Bad Request");
        }

        return resultMap;
    }
}
