package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.PushNotificationDAO;
import com.ekfc.foodcraft.model.PushNotification;
import com.ekfc.foodcraft.model.generic.PaginatedResponse;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

@Service
public class PushNotificationService {

    private static final Logger logger = LoggerFactory.getLogger(PushNotificationService.class);
    private final PushNotificationDAO pushNotificationDAO;

    @Autowired
    public PushNotificationService(PushNotificationDAO pushNotificationDAO) {
        this.pushNotificationDAO = pushNotificationDAO;
    }

    public boolean saveData(Map<String, String> requestMap) {
        return pushNotificationDAO.saveData(requestMap);
    }

    public List<PushNotification> getData(Map<String, String> requestMap) {
        return pushNotificationDAO.getData(requestMap);
    }

    public ResponseEntity<?> getDataPaginated(Map<String, String> filterParams) {
        try {
            Map<String, Object> dataPage = pushNotificationDAO.getDataPaginated(filterParams);
            PaginatedResponse response = new PaginatedResponse(
                    true,
                    HttpStatus.OK.value(),
                    "Success",
                    (Integer)dataPage.get("totalElements"),
                    (Integer)dataPage.get("totalPages"),
                    (Integer)dataPage.get("currentPage") ,
                    (Integer)dataPage.get("pageSize") ,
                    dataPage.get("content")
            );
            return ResponseEntity.ok(response);
        } catch (Exception ex){
            logger.error("return error response...");
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


}
