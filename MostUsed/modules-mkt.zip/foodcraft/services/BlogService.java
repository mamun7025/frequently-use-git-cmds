package com.ekfc.foodcraft.services;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;
import java.awt.image.PixelGrabber;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.dao.BlogDAO;
import com.ekfc.foodcraft.model.BlogModel;
import com.google.gson.Gson;
import com.luciad.imageio.webp.WebPWriteParam;

@Component
public class BlogService {

	@Autowired
	private BlogDAO blogDAO;
	
    @Autowired
    private Environment env;

    private static final int[] RGB_MASKS = {0xFF0000, 0xFF00, 0xFF};
    private static final ColorModel RGB_OPAQUE =
            new DirectColorModel(32, RGB_MASKS[0], RGB_MASKS[1], RGB_MASKS[2]);
	
	 public Map<String, Object> getBlogs() {
	        final Map<String, Object> resultMap = new HashMap<>();

	        final List<BlogModel> blogModels = blogDAO.getBlogs();

	        resultMap.put("result", blogModels);

	        return resultMap;
	    }

	    public Map<String, Object> addBlog(BlogModel requestObj) {
	        final Map<String, Object> resultMap = new HashMap<>();

	        final boolean downloaded = writeBlogImages(requestObj.getImgData(), requestObj.getImgPath());
	        if(downloaded) {
	            final boolean created = blogDAO.addBlog(requestObj);
	            if (created) {
	                resultMap.put("result", true);
	            } else {
	                resultMap.put("error", "Unable to Process, please try again later");
	            }
	        }else{
	            resultMap.put("error", "Unable to Process, please try again later");
	        }
	        return resultMap;
	    }


	    private boolean writeBlogImages(String data, String path) {
	        final StringBuilder sb = new StringBuilder();

	        final String[] pathSplit = path.split("/");
	        final String imageName = pathSplit[pathSplit.length - 1];
	        final String formatName = imageName.split("\\.")[1];
	        final byte[] data1 = Base64.getDecoder().decode(data.getBytes(StandardCharsets.UTF_8));
	        InputStream targetStream = new ByteArrayInputStream(data1);
	        try {
	            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.blog.images");
	            targetStream = new ByteArrayInputStream(data1);
	            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.blog.images.output");
	            return true;
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return false;
	    }

	    private String resizeAndDownloadGenericImage(final InputStream stream, final String name, final String format, int width, int height, String confPath) throws IOException, InterruptedException {
	        System.out.println("Downloading file " + name + ".....");
	        final String productImagePath = env.getProperty(confPath);

	        // Obtain an image to encode from somewhere
	        BufferedImage image = ImageIO.read(stream);

	        // Image img = ImageIO.read(stream);
	        Image img = image.getScaledInstance(width,height, Image.SCALE_SMOOTH);

	        PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);
	        pg.grabPixels();

	        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
	        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
	        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

	        // ImageIO.write(bi, format, new File(productImagePath+name));
	        // Obtain a WebP ImageWriter instance
	        ImageWriter writer = ImageIO.getImageWritersByMIMEType("image/" + format.toLowerCase()).next();

	        // Configure encoding parameters
	        WebPWriteParam writeParam = new WebPWriteParam(writer.getLocale());
	        writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
	        writeParam.setCompressionType("Lossless");

	        // Configure the output on the ImageWriter
	        writer.setOutput(new FileImageOutputStream(new File(productImagePath + name)));

	        // Encode
	        writer.write(null, new IIOImage(image, null, null), writeParam);
	        return "";
	    }

	    public Map<String, Object> updateBlog(BlogModel requestObj) {
	        final Map<String, Object> resultMap = new HashMap<>();

	        final String imageData = requestObj.getImgData();
	        if(imageData != "" && imageData != null){
	            final boolean downloaded = writeBlogImages(requestObj.getImgData(), requestObj.getImgPath());
	            if(downloaded) {
	                final boolean updated = blogDAO.updateBlog(requestObj);
	                if (updated) {
	                    resultMap.put("result", true);
	                } else {
	                    resultMap.put("error", "Unable to Process, please try again later");
	                }
	            }else{
	                resultMap.put("error", "Unable to Process, please try again later");
	            }
	        }
	        else{
	            final boolean updated = blogDAO.updateBlog(requestObj);
	            if (updated) {
	                resultMap.put("result", true);
	            } else {
	                resultMap.put("error", "Unable to Process, please try again later");
	            }
	        }

	        return resultMap;
	    }

	    public Map<String, Object> removeBlog(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();

	        if(reqMap.containsKey("id")) {
	            final int id = Integer.valueOf(reqMap.get("id").toString());
	            final boolean removed = blogDAO.removeBlog(id);
	            if (removed) {
	                resultMap.put("result", true);
	            } else {
	                resultMap.put("error", "Unable to Process, please try again later");
	            }
	        }else{
	            resultMap.put("error", "Bad Request");
	        }
	        return resultMap;
	    }

	    public Map<String, Object> publishBlog() {
	        final Map<String, Object> resultMap = new HashMap<>();

	        try {
	            final List<BlogModel> activeCarousel = blogDAO.getActiveBlogs();
	            final String jsonPathPrefix = env.getProperty("cms.path.blog.json", "");
	            File file = Paths.get(jsonPathPrefix + "blogs.js").toFile();
	            Gson gson = new Gson();
	            FileWriter writer = new FileWriter(file);
	            StringBuffer strBuffer = new StringBuffer();
	            strBuffer.append("var blogList").append(" = ").append(gson.toJson(activeCarousel));
	            writer.write(strBuffer.toString());
	            writer.flush();
	            writer.close();
	            resultMap.put("result", "Blogs are published to blogs.js");
	        }catch (Exception ex){
	            ex.printStackTrace();
	            resultMap.put("error", "Unable to Process, Please try again.");
	        }

	        return resultMap;
	    }
	    
	    public Map<String, Object> updateBlogSorting(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();
	        if(reqMap.containsKey("categoryList")){

	        	final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
	            try{
	                for(Map<String, Object> category: categoryList){
	                    this.updateBlogOrder(category);
	                }
	                resultMap.put("result", "Updated the order in the System");
	            }catch(Exception ex){
	                resultMap.put("error", "Bad Request");
	            }
	        }else{
	            resultMap.put("error", "Bad Request");
	        }
	        return resultMap;
	    }
	    
	    public Map<String, Object> updateBlogOrder(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();
	        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
	            final String code = reqMap.get("categoryId").toString();
	            int order = (int)reqMap.get("order");
	            try {

	                final boolean isUpdated = blogDAO.updateOrder(code, order);
	                if(isUpdated){
	                    resultMap.put("result", "The order is updated");
	                }
	                else{
	                    resultMap.put("error", "Unable to Process, please try again.");
	                }
	            }catch(Exception ex){
	                ex.printStackTrace();
	                resultMap.put("error", "Unable to Process, please try again.");
	            }
	        }
	        return resultMap;
	    }
}
