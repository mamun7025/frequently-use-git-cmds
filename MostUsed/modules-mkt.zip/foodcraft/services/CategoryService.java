package com.ekfc.foodcraft.services;

import com.ekfc.foodcraft.dao.CategoryDAO;
import com.ekfc.foodcraft.dao.ProductDAO;
import com.ekfc.foodcraft.model.Category;
import com.ekfc.foodcraft.model.Product;
import com.ekfc.foodcraft.utils.ProductUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;
import com.google.gson.Gson;
import com.luciad.imageio.webp.WebPWriteParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferInt;
import java.awt.image.DirectColorModel;
import java.awt.image.PixelGrabber;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.*;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;

@Component
public class CategoryService {

    @Autowired
    private CategoryDAO categoryDAO;

    @Autowired
    private ProductDAO productDAO;

    @Autowired
    private Environment env;

    @Autowired
    private ProductUtils productUtils;
    
    private static final int[] RGB_MASKS = {0xFF0000, 0xFF00, 0xFF};
    private static final ColorModel RGB_OPAQUE =
            new DirectColorModel(32, RGB_MASKS[0], RGB_MASKS[1], RGB_MASKS[2]);

    public Map<String, Object> getAllCategories(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

        final List<Category> categories = categoryDAO.getAllCategories();
        resultMap.put("result", categories);
        return resultMap;
    }

    public Map<String, Object> getAllEnabledCategories(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

        final List<Category> categories = categoryDAO.getAllEnabledCategories();
        resultMap.put("result", categories);
        return resultMap;
    }

    public Map<String, Object> getCategoryForId(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("categoryId")){
            final String categoryId = reqMap.get("categoryId").toString();
            final Category category = categoryDAO.getCategoryForId(categoryId);
            if(null != category){
                resultMap.put("result", category);
            }else{
                resultMap.put("noResults", true);
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }

    public Map<String, Object> updateCategory(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

        if(reqMap.containsKey("categoryId") && reqMap.containsKey("categoryName")
                && reqMap.containsKey("enabled") && reqMap.containsKey("parent")){
            final String categoryId = reqMap.get("categoryId").toString();
            final String categoryName = reqMap.get("categoryName").toString();
            final boolean downloadedDesktop = writeCategoryImage((String)reqMap.get("imageData"), (String)reqMap.get("image"));
            final boolean enabled = Boolean.valueOf(reqMap.get("enabled").toString());
            final String parent = (reqMap.get("parent") != null) ? reqMap.get("parent").toString(): null;
            final boolean filter = Boolean.valueOf(reqMap.get("filter").toString());
            final boolean header = Boolean.valueOf(reqMap.get("header").toString());
            final String shortDesc = (reqMap.get("shortDesc") != null) ? reqMap.get("shortDesc").toString() : null;
            final String longDesc = (reqMap.get("longDesc") != null) ? reqMap.get("longDesc").toString() : null;
            final String image = (reqMap.get("image") != null) ? reqMap.get("image").toString(): null;
            final int orderNumber = 0;
            final Category category = new Category(
                    categoryId,
                    categoryName,
                    enabled,
                    parent,
                    header,
                    filter,
                    longDesc,
                    shortDesc,
                    image,
                    orderNumber
            );
            if(downloadedDesktop) {
            final boolean updated = categoryDAO.updateCategory(category);
            if(updated){
                resultMap.put("result", "Updated successfully");
            }else{
                resultMap.put("error", "Unable to Process, Please contact IT helpdesk for Support.");
            }
            }
            else{
                resultMap.put("error", "Unable to Process, Please contact IT helpdesk for Support.");
            }
        }
        return resultMap;
    }

    public Map<String, Object> addCategory(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryId") && reqMap.containsKey("categoryName")
                && reqMap.containsKey("enabled") && reqMap.containsKey("parent")) {
            final boolean downloadedDesktop = writeCategoryImage((String)reqMap.get("imageData"), (String)reqMap.get("image"));
            final String categoryId = reqMap.get("categoryId").toString();
            final String categoryName = reqMap.get("categoryName").toString();
            final boolean enabled = Boolean.valueOf(reqMap.get("enabled").toString());
            final String parent = reqMap.get("parent") != null ? reqMap.get("parent").toString() : null;
            final boolean filter = Boolean.valueOf(reqMap.get("filter").toString());
            final boolean header = Boolean.valueOf(reqMap.get("header").toString());
            final String shortDesc = reqMap.get("shortDesc").toString();
            final String longDesc = reqMap.get("longDesc").toString();
            final String image = (reqMap.get("image") != null ) ? reqMap.get("image").toString(): null;
            final int orderNumber = 0;
            final Category category = new Category(
                    categoryId,
                    categoryName,
                    enabled,
                    parent,
                    header,
                    filter,
                    longDesc,
                    shortDesc,
                    image,
                    orderNumber
            );
            if(downloadedDesktop) {
            final boolean added = categoryDAO.addCategory(category);

            if(added){
                resultMap.put("result", "Category Added Successfully");
            }else{
                resultMap.put("error", "Unable to Process, Please contact IT helpdesk for Support.");
            }
            }

        }else {
            resultMap.put("error", "Bad Request");
        }

        return resultMap;
    }

    public Map<String, Object> updateCategoryStatus(final Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryId") && reqMap.containsKey("categoryName")){
            final String categoryId = reqMap.get("categoryId").toString();
            final boolean enabled = Boolean.valueOf(reqMap.get("enabled").toString());

            final boolean updated = categoryDAO.updateCategoryStatus(categoryId, enabled);

            if(updated){
                resultMap.put("result", "Category Updated Successfully");
            }else{
                resultMap.put("error", "Unable to Process, Please contact IT helpdesk for Support.");
            }
        }else {
            resultMap.put("error", "Bad Request");
        }


        return resultMap;
    }

    public Map<String, Object> publishProduct(Map<String, Object> reqMap) throws IOException {
        final Map<String, Object> resultMap = new HashMap<>();
        final ObjectMapper om = new ObjectMapper();
        final List<Category> categories = categoryDAO.getAllEnabledCategories();
        final List<Map<String, Object>> productLoadList = new ArrayList<>();
        if(!CollectionUtils.isEmpty(categories)){
            this.generateCategoryLoad(categories, om);
            categories.forEach(category -> {
                final List<Product> finalProducts = new ArrayList<>();
                final Map<String, Object> productLoadMap = new HashMap<>();
                final String catId = category.getCategoryId();
                final List<Product> initialProducts = productDAO.getAllEnabledProductsForCategory(catId);
                initialProducts.forEach(product -> {
                    final String catString = product.getCategories();
                    final List<String> catList = Arrays.asList(catString.split(" > "));
                    if(catList.indexOf(catId) > -1){
                        finalProducts.add(product);
                    }
                });
                //productLoadMap.put("category", catId);
                // TODO, we can send the categories filtered from here and just only modify or transform the Products and return the list back.
                try {
                    System.out.println("The unique products length is: " + finalProducts.size());
                    final List<Map<String, Object>> listMapProducts = productUtils.publishJsonLoad(finalProducts);
                    productLoadMap.put("category", catId);
                    Comparator productMapComparator = new Comparator<Map<String, Object>>() {
                        public int compare(Map<String, Object> o1, Map<String, Object> o2) {
                            return ComparisonChain.start()
                                    .compare(
                                            (o1.get("orderJson") != null) ? ((Map<String, Integer>)o1.get("orderJson")).get(catId) : 500000,
                                            (o2.get("orderJson") != null) ? ((Map<String, Integer>)o2.get("orderJson")).get(catId) : 500000,
                                            Ordering.natural().nullsLast())
                                    .result();
                        }
                    };
                    Collections.sort(listMapProducts, productMapComparator);
                    productLoadMap.put("products", listMapProducts);
                    resultMap.put("result", "successfully generated product_menu.json and category_menu.json with the latest product & category information");
                } catch (Exception e) {
                    e.printStackTrace();
                    resultMap.put("error", "There is some error, please try again or contact IT Helpdesk for support.");
                }
                
                if(!CollectionUtils.isEmpty(productLoadMap)){
                    productLoadList.add(productLoadMap);
                }
            });
            final String jsonPathPrefix = env.getProperty("cms.path.product.json", "");
            File file = Paths.get(jsonPathPrefix + "product_menu.js").toFile();
         
            Gson gson = new Gson();
            try (FileWriter writer = new FileWriter(file)){
                StringBuffer strBuffer = new StringBuffer();
                strBuffer.append("var productJson").append(" = ").append(gson.toJson(productLoadList));
                writer.write(strBuffer.toString());
                writer.flush();
                writer.close();
            }catch(Exception ex){
                ex.printStackTrace();
            }
            
            
        }else{
            resultMap.put("error", "There are no categories enabled to create Product Load, try to publish again by activating any categories.");
        }
        return resultMap;
    }

    private void generateCategoryLoad(List<Category> categories, final ObjectMapper om) throws IOException {
        final Map<String, Object> enabledCategories = new HashMap<>();
        final List<Category> rootCategories = categoryDAO.getRootCategories();
        enabledCategories.put("rootCategories", rootCategories);
        final List<Map<String, Object>> relationList = new ArrayList<>();
        categories.forEach(
                category -> {
                    final Map<String, Object> relationMap = new HashMap<>();
                    final String categoryId = category.getCategoryId();
                    final List<Category> subCategories = categoryDAO.getSubCategoriesForCategory(categoryId);
                    relationMap.put(categoryId, subCategories);
                    relationList.add(relationMap);
                }
        );
        enabledCategories.put("relatedCategories", relationList);
        final String jsonPathPrefix = env.getProperty("cms.path.category.json", "");
        File file = Paths.get(jsonPathPrefix + "category_menu.js").toFile();
        Gson gson = new Gson();
        try (FileWriter writer = new FileWriter(file)){
            StringBuffer strBuffer = new StringBuffer();
            strBuffer.append("var categoryJson").append(" = ").append(gson.toJson(enabledCategories));
            writer.write(strBuffer.toString());
            writer.flush();
            writer.close();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        //om.writeValue(Paths.get(jsonPathPrefix + "category_menu.js").toFile(), enabledCategories);
    }

    public Map<String, Object> searchCategories(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("code")){
            final String categoryId = reqMap.get("code").toString();
            final List<Category> categories = categoryDAO.searchCategories(categoryId);

            resultMap.put("result", categories);
        }else {
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCategoryOrderList(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryList")){

            final List<Map<String, Object>> categoryList = (List<Map<String, Object>>) reqMap.get("categoryList");
            try{
                for(Map<String, Object> category: categoryList){
                    this.updateCategoryOrder(category);
                }
                resultMap.put("result", "Updated the order in the System");
            }catch(Exception ex){
                resultMap.put("error", "Bad Request");
            }
        }else{
            resultMap.put("error", "Bad Request");
        }
        return resultMap;
    }
    
    public Map<String, Object> updateCategoryOrder(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("order") && reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            int order = (int)reqMap.get("order");
            try {

                final boolean isUpdated = categoryDAO.updateOrder(code, order);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    public Map<String, Object> deleteCategory(Map<String, Object> reqMap) {
        final Map<String, Object> resultMap = new HashMap<>();
        if(reqMap.containsKey("categoryId")) {
            final String code = reqMap.get("categoryId").toString();
            try {

                final boolean isUpdated = categoryDAO.deleteCatgeory(code);
                if(isUpdated){
                    resultMap.put("result", "The order is updated");
                }
                else{
                    resultMap.put("error", "Unable to Process, please try again.");
                }
            }catch(Exception ex){
                ex.printStackTrace();
                resultMap.put("error", "Unable to Process, please try again.");
            }
        }
        return resultMap;
    }
    
    private boolean writeCategoryImage(String data, String path) {
        final StringBuilder sb = new StringBuilder();

        final String[] pathSplit = path.split("/");
        final String imageName = pathSplit[pathSplit.length - 1];
        final String formatName = imageName.split("\\.")[1];
        final byte[] data1 = Base64.getDecoder().decode(data.getBytes(StandardCharsets.UTF_8));
        InputStream targetStream = new ByteArrayInputStream(data1);
        try {
            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.homepage.category.images");
            targetStream = new ByteArrayInputStream(data1);
            resizeAndDownloadGenericImage(targetStream, imageName, formatName, 1200, 800, "cms.path.homepage.category.images.output");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private String resizeAndDownloadGenericImage(final InputStream stream, final String name, final String format, int width, int height, String confPath) throws IOException, InterruptedException {
        System.out.println("Downloading file " + name + ".....");
        final String productImagePath = env.getProperty(confPath);

        // Obtain an image to encode from somewhere
        BufferedImage image = ImageIO.read(stream);

        // Image img = ImageIO.read(stream);
        Image img = image.getScaledInstance(width,height, Image.SCALE_SMOOTH);

        PixelGrabber pg = new PixelGrabber(img, 0, 0, width, height, true);
        pg.grabPixels();

        DataBuffer buffer = new DataBufferInt((int[]) pg.getPixels(), pg.getWidth() * pg.getHeight());
        WritableRaster raster = Raster.createPackedRaster(buffer, width, height, width, RGB_MASKS, null);
        BufferedImage bi = new BufferedImage(RGB_OPAQUE, raster, false, null);

        // ImageIO.write(bi, format, new File(productImagePath+name));
        // Obtain a WebP ImageWriter instance
        ImageWriter writer = ImageIO.getImageWritersByMIMEType("image/" + format.toLowerCase()).next();

        // Configure encoding parameters
        WebPWriteParam writeParam = new WebPWriteParam(writer.getLocale());
        writeParam.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        writeParam.setCompressionType("Lossless");

        // Configure the output on the ImageWriter
        writer.setOutput(new FileImageOutputStream(new File(productImagePath + name)));

        // Encode
        writer.write(null, new IIOImage(image, null, null), writeParam);
        return "";
    }
}
