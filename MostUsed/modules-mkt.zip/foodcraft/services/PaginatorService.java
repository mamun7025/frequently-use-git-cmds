package com.ekfc.foodcraft.services;

import org.springframework.stereotype.Service;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Service
public class PaginatorService {

    public int pageNum = 1;         // default page number is 0 (yes it is weird)
    public int pageSize = 10;       // default page size is 5
    public int offset;              // ((this.pageNum - 1) * this.pageSize)
    public String sortField = "id";
    public String sortDir = "desc";

    HttpServletRequest request;
    Map<String, String> clientParams;


    public PaginatorService(){
    }

    /**
     * @param page must not be less than zero.
     * @param size must not be less than one.
     */
    public PaginatorService(int page, int size) {
        if (page < 0) {
            throw new IllegalArgumentException("Page index must not be less than zero!");
        }
        if (size < 1) {
            throw new IllegalArgumentException("Page size must not be less than one!");
        }
        this.pageNum = page;
        this.pageSize = size;
    }

    public PaginatorService( Map<String, String> clientParams ) {
        this.clientParams = clientParams;
        if(this.clientParams.containsKey("pageNum")){
            this.pageNum = Integer.parseInt(this.clientParams.get("pageNum"));
        }
        if(this.clientParams.containsKey("pageSize")){
            this.pageSize = Integer.parseInt(this.clientParams.get("pageSize"));
        }
    }

    public PaginatorService(HttpServletRequest request){
        this.request = request;
        if (this.request.getParameter("pageNum") != null && !this.request.getParameter("pageNum").isEmpty()) this.pageNum = Integer.parseInt(this.request.getParameter("pageNum"));
        if (this.request.getParameter("pageSize") != null && !this.request.getParameter("pageSize").isEmpty()) this.pageSize = Integer.parseInt(this.request.getParameter("pageSize"));
        if (this.request.getParameter("sortField") != null && !this.request.getParameter("sortField").isEmpty()) this.sortField = this.request.getParameter("sortField");
        if (this.request.getParameter("sortDir") != null && !this.request.getParameter("sortDir").isEmpty()) this.sortDir = this.request.getParameter("sortDir");
    }

    public PaginatorService( HttpServletRequest request, Map<String, String> clientParams ) {
        this.request = request;
        this.clientParams = clientParams;
    }

    public void setDefaultSortDir(String sortField, String sortDir){
        this.sortField = sortField;
        this.sortDir = sortDir;
    }

    public void setPage(int page){
        this.pageNum = page;
    }
    public void setSize(int size){
        this.pageSize = size;
    }
    public int getPage(){
        return this.pageNum;
    }
    public int getSize(){
        return this.pageSize;
    }
    public int getOffset(){
        this.offset = ((this.pageNum - 1) * this.pageSize);
        return this.offset;
    }

}
