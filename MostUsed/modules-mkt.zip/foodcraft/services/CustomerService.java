package com.ekfc.foodcraft.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.dao.CustomerDAO;
import com.ekfc.foodcraft.model.Address;
import com.ekfc.foodcraft.model.CustomersData;
import com.ekfc.foodcraft.model.SupportTicketDiscussion;
import com.ekfc.foodcraft.model.SupportTicketHeader;
import com.ekfc.foodcraft.strategy.PasswordHashingStrategy;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class CustomerService {

	@Autowired
	private CustomerDAO customerDAO;
	
    @Autowired
    private PasswordHashingStrategy passwordHashingStrategy;

	public final static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static final String[] HEADERs = { "Ticket Number","Subject","Issue","Email","Priority","Type","Status","Date" };
	  static final String SHEET = "Tickets";
	
	public Map<String, Object> getAllCustomerDetails(){
		List<CustomersData> resultData = customerDAO.getAllCustomers();
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("result", resultData);
		return resultMap;
	}
	
	public Map<String, Object> getCustomerDetailsByEmail(Map<String, Object> reqMap){
		String email = reqMap.get("email").toString();
		List<CustomersData> resultDataInfo = customerDAO.getCustomerDetailsByEmail(email);
		List<Address> resultDataAddress = customerDAO.getAddressesForUser(email);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("customerInfo", resultDataInfo);
		resultMap.put("customerAddress", resultDataAddress);
		return resultMap;
	}

	public Map<String, Object> updateCustomerAddress(Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();

		ObjectMapper om = new ObjectMapper();
        Address add = om.convertValue(reqMap, Address.class);
       // add.setUserId(reqMap.get("user").toString());
        if(add.isPrimaryCheck()){
            List<Address> primaryAddresses = customerDAO.getPrimaryAddress(add.getUserId());
            if(primaryAddresses.size() > 0){
                Address primaryAddress = primaryAddresses.get(0);
                primaryAddress.setPrimaryCheck(false);
                customerDAO.updateAddress(primaryAddress);
            }
        }
        boolean updated = customerDAO.updateAddress(add);
        if(!updated) {
            resultMap.put("error", "UNABLE_TO_PROCESS_MESSAGE");
        }
        else {
        resultMap.put("result", "SUCCESS");
        }
        return resultMap;
	}
	
	public Map<String, Object> updateCustomerInfo(Map<String, Object> reqMap){
		Map<String, Object> resultMap = new HashMap<String, Object>();
	    	boolean updatedUser = false;
			try {
				String password = "";
				if(reqMap.get("password").toString() != null && reqMap.get("password").toString() != "") {
				password = passwordHashingStrategy.hashPassword(reqMap.get("password").toString());
				}
				else {
					List<CustomersData> resultDataInfo = customerDAO.getCustomerDetailsByEmail(reqMap.get("email").toString());
					password = resultDataInfo.get(0).getPassword();
				}
				updatedUser = customerDAO.updateUser(
						reqMap.get("email").toString(),
						reqMap.get("firstName").toString(),
						reqMap.get("lastName").toString(),
						reqMap.get("phoneNumber").toString(),
						password,
				        reqMap.get("communication").toString());
			} catch (NoSuchAlgorithmException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	
	    			resultMap.put("result", updatedUser);
	    			return resultMap;
	}
	
	public Map<String, Object> getAllTickets(){
		Map<String, Object> resultMap = new HashMap<>();
		List<SupportTicketHeader> data = customerDAO.getAllTicketsList();
		if(data.size() > 0) {
			resultMap.put("result",data);			
		}
		else {
			resultMap.put("error","not able to process the request");
		}
		return resultMap;

	}
	
	public Map<String, Object> getAllTicketsByFilter(Map<String, Object> reqMap){
		Map<String, Object> resultMap = new HashMap<>();
		List<SupportTicketHeader> data = customerDAO.getAllTicketsListByFilter(reqMap);
		if(data.size() > 0) {
			resultMap.put("result",data);			
		}
		else {
			resultMap.put("error","not able to process the request");
		}
		return resultMap;

	}
	
	public Map<String, Object> downloadSupportTicketReport(Map<String, Object> reqMap){
		Map<String, Object> resultMap = new HashMap<>();
		List<SupportTicketHeader> ticketData = customerDAO.getAllTicketsListByFilter(reqMap);
		try(Workbook workbook = new XSSFWorkbook()){

			Sheet sheet = workbook.createSheet(SHEET);
			Row headerRow = sheet.createRow(0);
			for(int col =0; col<HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}
			int rowIdx = 1;
			//	String orderId = null;
			for(SupportTicketHeader od : ticketData) {

				Row row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(od.getId());
				row.createCell(1).setCellValue(od.getSubject());
				row.createCell(2).setCellValue(od.getIssue());
				row.createCell(3).setCellValue(od.getUser());
				row.createCell(4).setCellValue(od.getPriority());
				row.createCell(5).setCellValue(od.getType());
				row.createCell(6).setCellValue(od.getStatus());
				row.createCell(7).setCellValue(od.getCreatedOn());
			}
			sheet.autoSizeColumn(0);
			sheet.autoSizeColumn(1);
			sheet.autoSizeColumn(2);
			sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
			sheet.autoSizeColumn(5);
			sheet.autoSizeColumn(6);
			sheet.autoSizeColumn(7);
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			workbook.write(out);
			byte[] excelBytes = out.toByteArray();
			resultMap.put("result",Base64.getEncoder().encodeToString(excelBytes));
			return resultMap;
		}
		catch(IOException ex) {
			ex.printStackTrace();
			return null;
		}

	}
	
	
	 public Map<String, Object> getTicketDetailsForUser(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();
	        try {
	                    String id = reqMap.get("id").toString();
	                    String user = reqMap.get("user").toString();
	                    List<SupportTicketHeader> tickets = customerDAO.getTicketDetailsForUser(user, id);
	                    List<SupportTicketDiscussion> discussions = customerDAO.getDiscussionForTickets(Integer.parseInt(id));
	                    resultMap.put("ticketsHeader", tickets);
	                    resultMap.put("ticketsDiscussion", discussions);
	        }catch (Exception ex) {
	            ex.printStackTrace();
	            resultMap.put("error", "UNABLE_TO_PROCESS_MESSAGE");
	        }
	        return resultMap;
	    }
	 
	 public Map<String, Object> addTicketDiscussionForUser(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();

	        try {
	                    String id = reqMap.get("id").toString();
	                    String issue = reqMap.get("issue").toString();

	                        boolean isAdded = customerDAO.addDiscussionToTicket(Integer.parseInt(id), false, true, issue);
	                        resultMap.put("result", isAdded);
	        }catch (Exception ex) {
	            ex.printStackTrace();
	            resultMap.put("error", "UNABLE_TO_PROCESS_MESSAGE");
	        }
	        return resultMap;
	    }
	 
	 
	 public Map<String, Object> updateTicketStatus(Map<String, Object> reqMap) {
	        final Map<String, Object> resultMap = new HashMap<>();

	        try {
	                        customerDAO.updateTicketStatusList(reqMap);
	                        resultMap.put("result", "Updated Successfully");
	        }catch (Exception ex) {
	            ex.printStackTrace();
	            resultMap.put("error", "UNABLE_TO_PROCESS_MESSAGE");
	        }
	        return resultMap;
	    }
	

	
}
