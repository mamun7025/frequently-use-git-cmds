package com.ekfc.foodcraft.services;


import com.jcraft.jsch.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileInputStream;

@Service
public class SftpTransferService {

    @Autowired
    private Environment env;

    private String remoteMchUser;   // AWS or Azure Machine user // ex: ec2-user
    private String remoteMchHost;   // ex: ec2-52-201-227-212.compute-1.amazonaws.com"
    private String remoteMchPort;   // ex: 22
    private String privateKeyPath;  // Remote access private key
    private String passphrase;

    private String srcFilePath;     // file name with path
    private String dstFilePath;     // destination dir


    static Session sessionGV = null;
    static Channel channelGV = null;
    static ChannelSftp channelSftpGV = null;

    public void setConfigProperties() {
//        this.remoteMchUser = "ec2-user"; // ec2 user
//        this.remoteMchHost = "ec2-52-201-227-212.compute-1.amazonaws.com";
//        this.privateKeyPath = "D:\\app-codes\\RnDs\\PemKeyFile.pem";
//        this.passphrase = "Sumi25";
        this.remoteMchUser = env.getProperty("cms.file.transfer.remote.machine.user");
        this.remoteMchHost = env.getProperty("cms.file.transfer.remote.machine.host");
        this.remoteMchPort = env.getProperty("cms.file.transfer.remote.machine.port");
        this.privateKeyPath = env.getProperty("cms.file.transfer.remote.machine.private.key");
        this.passphrase = env.getProperty("cms.file.transfer.remote.machine.passphrase");           // pass phrase if have

        this.srcFilePath = env.getProperty("cms.file.transfer.src");
        this.dstFilePath = env.getProperty("cms.file.transfer.dst");
    }


    /**
     * This method is called recursively to Upload the local folder content to SFTP server
     *
     * @param sourcePath src
     * @param destinationPath dst
     * @throws SftpException ex
     * @throws FileNotFoundException err
     */
    private void recursiveFolderUpload(String sourcePath, String destinationPath) throws SftpException, FileNotFoundException {
        File sourceFile = new File(sourcePath);
        if (sourceFile.isFile()) {
            // copy if it is a file
            channelSftpGV.cd(destinationPath);
            if (!sourceFile.getName().startsWith(".")){
                /*
                 * put method takes two arguments.
                 * first one is the file which located in our local machine
                 * second one is the place our file should be transfer.
                 */
                channelSftpGV.put(new FileInputStream(sourceFile), sourceFile.getName(), ChannelSftp.OVERWRITE);
            }
        } else {
            System.out.println("inside else " + sourceFile.getName());
            File[] files = sourceFile.listFiles();
            if (files != null && !sourceFile.getName().startsWith(".")) {
                channelSftpGV.cd(destinationPath);
                SftpATTRS attrs = null;
                // check if the directory is already existing
                try {
                    attrs = channelSftpGV.stat(destinationPath + "/" + sourceFile.getName());
                } catch (Exception e) {
                    System.out.println(destinationPath + "/" + sourceFile.getName() + " not found");
                }
                // else create a directory
                if (attrs != null) {
                    System.out.println("Directory exists IsDir=" + attrs.isDir());
                } else {
                    System.out.println("Creating dir " + sourceFile.getName());
                    channelSftpGV.mkdir(sourceFile.getName());
                }
                for (File f : files) {
                    recursiveFolderUpload(f.getAbsolutePath(), destinationPath + "/" + sourceFile.getName());
                }
            }
        }
    }



    public void transferFileToRemoteHost() {

        JSch jsch = new JSch();
        try {
            /*
             * getSession() method required 3 parameters.
             * username of the remote server
             * IP address of the remote server
             * SSH port of the remote server
             */
            sessionGV = jsch.getSession(this.remoteMchUser, this.remoteMchHost, Integer.parseInt(this.remoteMchPort));
            System.out.println("session created.");

            // pass phrase optional
            if(this.passphrase != null && !this.passphrase.isEmpty()){
                jsch.addIdentity(this.privateKeyPath, this.passphrase);
            } else {
                jsch.addIdentity(this.privateKeyPath);
            }
            System.out.println("identity added");

            sessionGV.setConfig("StrictHostKeyChecking", "no");
            System.out.println("Trying to connect...");
            sessionGV.connect();
            System.out.println("Connected successfully.");

            channelGV = sessionGV.openChannel("sftp");
            channelGV.connect();
            channelSftpGV = (ChannelSftp) channelGV;
            System.out.println("Uploading Files...");
            recursiveFolderUpload(this.srcFilePath, this.dstFilePath);
            System.out.println("Success");
            channelSftpGV.exit();
            sessionGV.disconnect();

        } catch (SftpException | JSchException e) {
            System.out.println("Error occurred during SFTP " + e.getMessage());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

    }


}