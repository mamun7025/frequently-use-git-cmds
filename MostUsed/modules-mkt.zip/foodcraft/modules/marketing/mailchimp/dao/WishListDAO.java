package com.ekfc.foodcraft.modules.marketing.mailchimp.dao;

import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Repository
public class WishListDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    public List<Map<String, String>> getWishListData() {

        StringBuilder plSQL = new StringBuilder("call p_cms_promotion_get_wishlist_data()");
        List< Map<String, String> > dataList = new ArrayList<>();

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet rs) throws SQLException {
                boolean processNext = true;
                while (processNext) {
                    Map<String, String> dataBean = new LinkedHashMap<>();
                    dataBean.put("lineId", rs.getString("id"));
                    dataBean.put("productCode", rs.getString("product_code"));
                    dataBean.put("productName", rs.getString("product_name"));
                    dataBean.put("productImg", rs.getString("product_img"));
                    dataBean.put("category", rs.getString("category"));
                    dataBean.put("customerEmail", rs.getString("customer_email"));
                    dataBean.put("createdOn", rs.getString("created_on"));
                    // push in list
                    dataList.add(dataBean);
                    processNext = rs.next();
                }
            }
        });

        return dataList;
    }


}
