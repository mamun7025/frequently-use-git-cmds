package com.ekfc.foodcraft.modules.marketing.mailchimp.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ekfc.foodcraft.model.Users;

public class NewCustomerOrderDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public List<Users> getAllNewCustomerData(Date date){
		return jdbcTemplate.query("call p_cms_get_all_new_cust(?)", (rs, rowNum) -> new Users(rs.getString("id")), new Object[] {date});
	}

}
