package com.ekfc.foodcraft.modules.marketing.mailchimp;


import com.ekfc.foodcraft.modules.marketing.mailchimp.service.WishListDataService;
import com.ekfc.foodcraft.modules.marketing.mailchimp.templates.EmailTemplatesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("*")
@RestController
@RequestMapping("/fcadmin/api/promotion")
public class PromotionDataApiController {

    @Autowired
    WishListDataService wishListDataService;

    /**
     * Last 1-month data
     * @return null
     */
    @PostMapping("/wishlist-data")
    public ResponseEntity<?> getWishListPromotionData(){
        return wishListDataService.getWishListData();
    }

    @PostMapping("/get-wishlist-campaign-template")
    public ResponseEntity<?> getWishListCampaignTemplate(){
        String tmpBody = EmailTemplatesRepo.demoTemp1;
        tmpBody = tmpBody.replaceAll("##CampaignTitle##", "Discount on Lunch Meal 25th September only!");
        return ResponseEntity.ok(tmpBody);
    }

}
