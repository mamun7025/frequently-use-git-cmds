package com.ekfc.foodcraft.modules.marketing.mailchimp.utils;

import java.util.UUID;

public class MailChimpUtils {
    public static String getUniqueGroupIdForSegments(){
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }
}
