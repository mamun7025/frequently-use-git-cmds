package com.ekfc.foodcraft.modules.marketing.mailchimp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.modules.marketing.mailchimp.model.CampaignCreateResponse;
import com.ekfc.foodcraft.modules.marketing.mailchimp.templates.EmailTemplatesRepo;
import com.ekfc.foodcraft.modules.marketing.mailchimp.utils.MailChimpUtils;
import com.ekfc.foodcraft.modules.marketing.utils.CommonHttpUtil;

@Service
public class NewCustomerOrderService {
	
    private static final Logger logger = LoggerFactory.getLogger(NewCustomerOrderService.class);
	
	@Autowired
	private RestTemplate restTemplate;
	
    @Value("${cms.mailchimp.apiurl}")
    private String mailchimpApiUrl;
    @Value("${cms.mailchimp.apikey}")
    private String mailchimpApiKey;
    
    @Value("${cms.mailchimp.audienceId}")
    private String mailchimpAudienceId;
	
	public ResponseEntity<?> createNewSegments(Map<String, ArrayList<String>> reqBody, HttpServletRequest servletRequest){
        // listId/audienceId
        //String listId = "958fe69af6";
        String apiURL = this.mailchimpApiUrl + "lists/"+mailchimpAudienceId+"/segments";
        List<String> recipients = reqBody.get("recipients");

        HashMap<String, Object> payloadData = new HashMap<>();
//        payloadData.put("name", "GroupUser201");
        payloadData.put("name", "GroupUser_"+MailChimpUtils.getUniqueGroupIdForSegments());
//        payloadData.put("static_segment", new ArrayList<>());
//        payloadData.put("static_segment", List.of("mamun7025@gmail.com", "muntaserh@ekfc.ae"));
        payloadData.put("static_segment", recipients);

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.set("Authorization", "apikey " + this.mailchimpApiKey);

        HttpEntity<?> requestBody = new HttpEntity<>(payloadData, httpHeaders);
        ResponseEntity<Object> responseObj;
        try {
            logger.info("@apiURL {}", apiURL);
            responseObj = restTemplate.exchange(apiURL, HttpMethod.POST, requestBody, Object.class);
        } catch(HttpStatusCodeException e) {
            return ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
        }

        if (responseObj.getStatusCode().equals(HttpStatus.OK)) {
            Object responseBody = responseObj.getBody();
            System.out.println(responseBody);
            if(responseBody != null){
                return ResponseEntity.status(HttpStatus.OK).body(responseBody);
            }
        }
        logger.error("return error response...");
        return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, responseObj.getStatusCodeValue(), "Request fail", "", responseObj.getBody()));

    }
	
	
	  public ResponseEntity<?> createCampaign(Map<String, String> reqBody, HttpServletRequest servletRequest) {
	        // validate
	        this.validateCreateCampaign(reqBody);

	        // process
	        String campaignId = "";
	        String apiURL = this.mailchimpApiUrl + "campaigns";

	        Map<String, Object> payloadData = this.setCampaignTitleAndData(reqBody);
	        payloadData.put("content_type", "template");

	        HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
	        httpHeaders.set("Authorization", "apikey " + this.mailchimpApiKey);

	        HttpEntity<?> requestBody = new HttpEntity<>(payloadData, httpHeaders);
	        // ResponseEntity<Object> responseObj = restTemplate.exchange(apiURL, HttpMethod.POST, requestBody, Object.class);
	        ResponseEntity<Object> responseObj;
	        try {
	            logger.info("@apiURL {}", apiURL);
	            responseObj = restTemplate.exchange(apiURL, HttpMethod.POST, requestBody, Object.class);
	        } catch(HttpStatusCodeException e) {
	            return ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
	        }

	        if (responseObj.getStatusCode().equals(HttpStatus.OK)) {
	            Object responseBody = responseObj.getBody();
	            System.out.println(responseBody);
	            if(responseBody != null){
	                CampaignCreateResponse cmpCreateResponse = CommonHttpUtil.convertToOriginalObject(responseBody, CampaignCreateResponse.class);
	                 return updateCampaignContent_addingHTML(cmpCreateResponse, reqBody);
	                // return ResponseEntity.status(HttpStatus.OK).body(cmpResponse);
	            }
	        }
	        logger.error("return error response...");
	        return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, responseObj.getStatusCodeValue(), "Request fail", "", responseObj.getBody()));

	    }
	  
	    public Boolean validateCreateCampaign(Map<String, String> reqBody){
	        return true;
	    }

	    public ResponseEntity<?> updateCampaignContent_addingHTML(CampaignCreateResponse cmpCreateResponse, Map<String, String> reqBody){

	        String campaignId = cmpCreateResponse.getId();
	        String apiURL = this.mailchimpApiUrl + "campaigns/"+campaignId+"/content";
	        String mailHTML_content = this.getMailTemplateString(reqBody);

	        HashMap<String, String> payloadData = new HashMap<>();
	        payloadData.put("html", mailHTML_content);

	        HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
	        httpHeaders.set("Authorization", "apikey " + this.mailchimpApiKey);

	        HttpEntity<?> requestBody = new HttpEntity<>(payloadData, httpHeaders);
	        ResponseEntity<Object> responseObj;
	        try {
	            logger.info("@apiURL {}", apiURL);
	            responseObj = restTemplate.exchange(apiURL, HttpMethod.PUT, requestBody, Object.class);
	        } catch(HttpStatusCodeException e) {
	            return ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
	        }

	        if (responseObj.getStatusCode().equals(HttpStatus.OK)) {
	            Object responseBody = responseObj.getBody();
	            System.out.println(responseBody);
	            if(responseBody != null){
	                return this.sendCampaignMailToCustomer(cmpCreateResponse, responseBody, reqBody);
	            }
	        }

	        return ResponseEntity.status(HttpStatus.OK).body(cmpCreateResponse);
	    }
	    
	    public ResponseEntity<?> sendCampaignMailToCustomer(CampaignCreateResponse cmpCreateResponse, Object updateResponseObj, Map<String, String> reqBody){
	        String campaignId = cmpCreateResponse.getId();
	        String apiURL = this.mailchimpApiUrl + "campaigns/"+campaignId+"/actions/send";

	        HashMap<String, Object> payloadData = new HashMap<>();
//	        payloadData.put("test_emails", List.of("mamun7025@gmail.com", "muntaserh@ekfc.ae"));
//	        payloadData.put("send_type", "html");

	        HttpHeaders httpHeaders = new HttpHeaders();
	        httpHeaders.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
	        httpHeaders.set("Authorization", "apikey " + this.mailchimpApiKey);

	        HttpEntity<?> requestBody = new HttpEntity<>(payloadData, httpHeaders);
	        ResponseEntity<Object> responseObj;
	        try {
	            logger.info("@apiURL {}", apiURL);
	            responseObj = restTemplate.exchange(apiURL, HttpMethod.POST, requestBody, Object.class);
	        } catch(HttpStatusCodeException e) {
	            return ResponseEntity.status(e.getRawStatusCode()).headers(e.getResponseHeaders()).body(e.getResponseBodyAsString());
	        }

	        if (responseObj.getStatusCode().equals(HttpStatus.OK)) {
	            Object responseBody = responseObj.getBody();
	            System.out.println(responseBody);
	            if(responseBody != null){
	                return ResponseEntity.status(HttpStatus.OK).body(responseBody);
	            }
	        }

	        return ResponseEntity.status(HttpStatus.OK).body(cmpCreateResponse);
	    }

	    public String getMailTemplateString(Map<String, String> reqBody){
	        String tmpBody = EmailTemplatesRepo.demoTemp1;
	        // process your HTML data
	        // tmpBody = tmpBody.replaceAll("##CampaignTiyle##", "Discount on Lunch Meal 25th September only!");
	        tmpBody = tmpBody.replaceAll("##CampaignTitle##", reqBody.get("HTML_campaignTitle"));
	        // append wishList product for this customer
	        // apply replace
	        System.out.println(tmpBody);
	        return tmpBody;
	    }
	    
	    @SuppressWarnings("unchecked")
		public Map<String, Object> setCampaignTitleAndData(Map<String, String> reqBody){
	        ( (HashMap<String, Object>)this.campaignCreatePayloadTemplate.get("settings") ).put("subject_line", reqBody.get("subjectLine"));
	        ( (HashMap<String, Object>)this.campaignCreatePayloadTemplate.get("settings") ).put("preview_text", reqBody.get("previewText"));
	        ( (HashMap<String, Object>)this.campaignCreatePayloadTemplate.get("settings") ).put("title",  reqBody.get("title"));
	        ( (HashMap<String, Object>)this.campaignCreatePayloadTemplate.get("settings") ).put("from_name", reqBody.get("fromName"));
	        // recipients
	        String segmentId = reqBody.getOrDefault("recipientsSegmentId", null);
	        if(segmentId != null){
	            ( (HashMap<String, Object>)this.campaignCreatePayloadTemplate.get("recipients") ).put("segment_opts", new HashMap<>(){{
	                put("saved_segment_id", Integer.parseInt(segmentId));
	                put("match", "any");
	                put("conditions", List.of(
	                        new HashMap<>(){{
	                            put("condition_type", "StaticSegment");
	                            put("field", "static_segment");
	                            put("op", "static_is");
	                            put("value", Integer.parseInt(segmentId));
	                        }}
	                ));
	            }});
	        }
	        return this.campaignCreatePayloadTemplate;
	    }
	    
	    private Map<String, Object> campaignCreatePayloadTemplate = new HashMap<>(){{
	        put("type", "regular");
	        put("recipients", new HashMap<>(){{
	            put("list_id", "958fe69af6");
	        }});
	        put("settings", new HashMap<>(){{
	            put("subject_line", "Summer Sale");
	            put("preview_text", "Summer Sale");
	            put("title", "Test Title");
	            put("from_name", "Test From Name");
	            put("reply_to", "mamun@theanalystbd.net");
	            put("use_conversation", false);
	            put("to_name", "");
	            put("folder_id", "");
	            put("authenticate", false);
	            put("auto_footer", false);
	            put("inline_css", false);
	            put("auto_tweet", false);
	            put("auto_fb_post", new ArrayList<>());
	            put("fb_comments", false);
	            put("template_id", 0);
	        }});
	        put("tracking", new HashMap<>(){{
	            put("opens", true);
	            put("html_clicks", true);
	            put("text_clicks", true);
	            put("goal_tracking", true);
	            put("ecomm360", false);
	            put("google_analytics", "");
	            put("clicktale", "");
	            put("salesforce", new HashMap<>(){{
	                put("campaign", false);
	                put("notes", false);
	            }});
	            put("capsule", new HashMap<>(){{
	                put("notes", false);
	            }});
	        }});
	        put("social_card", new HashMap<>(){{
	            put("image_url", "");
	            put("description", "");
	            put("title", "");
	        }});
	        put("content_type", "template");
	    }};
}
