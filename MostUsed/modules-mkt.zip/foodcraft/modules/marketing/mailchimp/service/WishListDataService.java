package com.ekfc.foodcraft.modules.marketing.mailchimp.service;


import com.ekfc.foodcraft.model.generic.PaginatedResponse;
import com.ekfc.foodcraft.modules.marketing.mailchimp.dao.WishListDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class WishListDataService {

    @Autowired
    WishListDAO wishListDAO;

    public ResponseEntity<?> getWishListData() {
        List<Map<String, String>> listData = wishListDAO.getWishListData();
        PaginatedResponse response = new PaginatedResponse(
                true,
                HttpStatus.OK.value(),
                "Success",
                listData.size(),
                1,
                1 ,
                null ,
                listData
        );
        return ResponseEntity.ok(response);
    }

}
