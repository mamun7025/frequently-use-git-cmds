package com.ekfc.foodcraft.modules.marketing.mailchimp.model;


import com.fasterxml.jackson.annotation.JsonAlias;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CampaignCreateResponse {

    private String id;
    @JsonAlias("web_id")
    private String webId;
    private String type;
    @JsonAlias("create_time")
    private String createTime;
    private String status;
    @JsonAlias("content_type")
    private String contentType;

    public CampaignCreateResponse(){
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getWebId() {
        return webId;
    }

    public void setWebId(String webId) {
        this.webId = webId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }
}
