package com.ekfc.foodcraft.tasksch;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import java.util.Date;

@Configuration
@EnableScheduling
public class CMSJobScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CMSJobScheduler.class);

    @Scheduled(fixedDelay = 45000, initialDelay = 5000) // 45 sec
    public void scheduleTaskWithFixDelay(){

        System.out.println("@calling scheduleTaskWithFixDelay... each 45sec " + new Date());
        // calling method-1
        // calling method-2
        // calling method-3

    }

    @Scheduled(cron = "@hourly")
    public void scheduleTaskHourly(){

        System.out.println("@calling scheduleTaskHourly..." + new Date());
        // calling method-1
        // calling method-2
        // calling method-3

    }

    @Scheduled(cron = "@daily")
    public void scheduleTaskDaily(){

        System.out.println("@calling scheduleTaskDaily..." + new Date());
        // calling method-1
        // calling method-2
        // calling method-3

    }

    @Scheduled(cron = "@weekly")
    public void scheduleTaskWeekly(){

        System.out.println("@calling scheduleTaskWeekly..." + new Date());
        // calling method-1
        // calling method-2
        // calling method-3

    }

    @Scheduled(cron = "@monthly")
    public void scheduleTaskMonthly(){

        System.out.println("@calling scheduleTaskMonthly..." + new Date());
        // calling method-1
        // calling method-2
        // calling method-3

    }


}
