package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.services.HomepageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ekfc.foodcraft.services.CategoryService;

import java.util.HashMap;
import java.util.Map;

@RequestMapping("/fcadmin/api/publish")
@RestController
@CrossOrigin(origins = "*")
public class PublishController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private HomepageService homepageService;


    @PostMapping("/all")
    public Map<String, Object> publishAllPossibleJSFiles(@RequestBody Map<String, Object> reqMap){
        final Map<String, Object> resultMap = new HashMap<>();
        try {
            categoryService.publishProduct(reqMap);
            homepageService.publishCarouselBanner();
            homepageService.publishExploreMenu();
            homepageService.publishCustomerFavorites();
            homepageService.changeVersion();
            resultMap.put("result", "All the relevant JS files are published and available for them to be replaced.");
        }catch(Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "There is a problem processing the publish, so the entire chain will be stopped");
        }

        return resultMap;
    }
}
