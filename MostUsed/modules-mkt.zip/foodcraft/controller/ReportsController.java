package com.ekfc.foodcraft.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ekfc.foodcraft.services.report.AllOrderInfoDataService;
import com.ekfc.foodcraft.services.report.OrderInfoRptCommonService;
import com.ekfc.foodcraft.services.report.SalesRptByCategoryService;
import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.ekfc.foodcraft.model.OrdersDetails;
import com.ekfc.foodcraft.model.reports.OrderQuanityDTO;
import com.ekfc.foodcraft.services.ReportService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api")
public class ReportsController {

	@Autowired
	private ReportService reportService;
	@Autowired
	private SalesRptByCategoryService salesRptByCategoryService;
	@Autowired
	private AllOrderInfoDataService allOrderInfoDataService;
	@Autowired
	private OrderInfoRptCommonService orderInfoRptCommonService;
	
	// newly added
	@PostMapping("/report/getOrderQuantityByCodes")
	public List<OrderQuanityDTO> getOrderQuantityByCodes(@RequestBody Map<String, Object> reqMap) {

		return reportService.getOrderQuantityByCodes(reqMap);
	}

	// newly added
	@PostMapping("/report/getOrderDetailsForProductCode")
	public List<OrdersDetails> getOrderDetailsForProductCode(@RequestBody Map<String, Object> reqMap) {
		System.out.println("\n\tRequest received NEW:" + reqMap);
		return reportService.getOrderDetailsForProductCode(reqMap);
	}
	@PostMapping("/report/order/list")
	public Map<String, Object> getOrderHistoryByDeliveryDate(@RequestBody Map<String, Object> reqMap ){
		return reportService.getOrderHistoryByDeliveryDate(reqMap);
	}
	
	@GetMapping("/report/order/excel")
	public void getFile(HttpServletResponse response, @RequestParam String deliveryDate) throws IOException{
		String fileName = "Delivery_Summary_"+deliveryDate+".xlsx"; 
		response.setContentType("application/octet-stream");
	        response.setHeader("Content-Disposition", "attachment; filename="+fileName);
	        ByteArrayInputStream stream = reportService.load(deliveryDate);
	        IOUtils.copy(stream, response.getOutputStream());
	}

	@PostMapping("/report/sales-rpt-by-pc")
	public ResponseEntity<?> getSalesRptByPC(){
		return salesRptByCategoryService.getRptData();
	}

	@PostMapping("/report/all-order-info")
	public ResponseEntity<?> getAllOrderInfoData(@RequestBody Map<String, String> filterParams, HttpServletRequest servletRequest){
		return allOrderInfoDataService.getOrderInfoDataPaginated(filterParams, servletRequest);
	}
	
	@PostMapping("/report/excel/download")
	public String getAllOrderInfoExcelData(@RequestBody Map<String, String> filterParams, HttpServletRequest servletRequest){
		return allOrderInfoDataService.getAllOrderInfoExcelData(filterParams, servletRequest);
	}

	@PostMapping("/report/get-order-info-summary-rpt-by-status")
	public ResponseEntity<?> getOrderInfoSummaryRptByStatus(){
		return orderInfoRptCommonService.getOrderInfoSummaryRptByStatus();
	}

}
