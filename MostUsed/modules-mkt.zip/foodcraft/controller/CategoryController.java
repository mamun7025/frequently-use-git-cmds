package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.services.BlogService;
import com.ekfc.foodcraft.services.CategoryService;
import com.ekfc.foodcraft.services.HomepageService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private HomepageService homepageService;
    
    @Autowired
    private BlogService blogService;

    @PostMapping("/all")
    public Map<String, Object> getAllCategories(@RequestBody final Map<String, Object> reqMap){
        return categoryService.getAllCategories(reqMap);
    }

    @PostMapping("/all/enabled")
    public Map<String, Object> getAllEnabledCategories(@RequestBody final Map<String, Object> reqMap){
        return categoryService.getAllEnabledCategories(reqMap);
    }

    @PostMapping("/get")
    public Map<String, Object> getCategoryForId(@RequestBody final Map<String, Object> reqMap){
        return categoryService.getCategoryForId(reqMap);
    }

    @PostMapping("/update")
    public Map<String, Object> updateCategory(@RequestBody final Map<String, Object> reqMap){
        return categoryService.updateCategory(reqMap);
    }

    @PostMapping("/add")
    public Map<String, Object> addCategory(@RequestBody final Map<String, Object> reqMap){
        return categoryService.addCategory(reqMap);
    }

    @PostMapping("/update/status")
    public Map<String, Object> updateCategoryStatus(@RequestBody final Map<String, Object> reqMap){
        return categoryService.updateCategoryStatus(reqMap);
    }

    @PostMapping("/publish")
    public Map<String, Object> publishProducts(@RequestBody final Map<String, Object> reqMap) throws IOException {
        final Map<String, Object> resultMap = new HashMap<>();
        try {
            categoryService.publishProduct(reqMap);
            homepageService.publishCarouselBanner();
            homepageService.publishExploreMenu();
            homepageService.publishCustomerFavorites();
            homepageService.changeVersion();
            blogService.publishBlog();
            homepageService.publishCraftPerfectMeals();
            
            resultMap.put("result", "All the relevant JS files are published and available for them to be replaced.");
        }catch(Exception ex){
            ex.printStackTrace();
            resultMap.put("error", "There is a problem processing the publish, so the entire chain will be stopped");
        }

        return resultMap;
    }

    @PostMapping("/search")
    public Map<String, Object> searchCategories(@RequestBody final Map<String, Object> reqMap) throws IOException {
        return categoryService.searchCategories(reqMap);
    }
    
    @PostMapping("/update-order")
    public Map<String, Object> updateCategoryOrder(@RequestBody Map<String, Object> reqMap){
        return categoryService.updateCategoryOrderList(reqMap);
    }
    
    @PostMapping("/delete")
    public Map<String, Object> deleteCategory(@RequestBody Map<String, Object> reqMap){
        return categoryService.deleteCategory(reqMap);
    }
    
}
