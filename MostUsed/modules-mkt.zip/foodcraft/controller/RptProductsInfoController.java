package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.services.report.ProductsInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api")
public class RptProductsInfoController {

	@Autowired
	private ProductsInfoService productsInfoService;

	@PostMapping("/product/all")
	public ResponseEntity<?> getAllProductData(@RequestBody Map<String, String> filterParams, HttpServletRequest servletRequest){
		return productsInfoService.getAllProductData(filterParams, servletRequest);
	}
	
	@PostMapping("/product/excel/download")
	public ResponseEntity<?> getAllProductDataExcel(@RequestBody Map<String, String> filterParams, HttpServletRequest servletRequest){
		return productsInfoService.getAllProductDataExcel(filterParams, servletRequest);
	}


}
