package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api/products")
public class ProductsController {

    @Autowired
    private ProductService productService;

    @PostMapping("/cat")
    public Map<String, Object> getAllProductsForCategory(@RequestBody Map<String, Object> reqMap){
        return productService.getAllProductsForCategory(reqMap);
    }

    @PostMapping("/get")
    public Map<String, Object> getProductForCode(@RequestBody Map<String, Object> reqMap) {
        return productService.getProductForCode(reqMap);
    }

    @PostMapping("/update")
    public Map<String, Object> updateProductForCode(@RequestBody Map<String, Object> reqMap){
        return productService.updateProductForCode(reqMap);
    }

    @PostMapping("/create")
    public Map<String, Object> createProduct(@RequestBody Map<String, Object> reqMap){
        return productService.createProduct(reqMap);
    }

    @PostMapping("/media/update")
    public Map<String, Object> updateProductMediaForCode(@RequestBody Map<String, Object> reqMap) throws IOException {
        return productService.udpateProductMediaForCode(reqMap);
    }
    
    @PostMapping("/media/delete")
    public Map<String, Object> deleteProductMediaForCode(@RequestBody Map<String, Object> reqMap) throws IOException {
        return productService.deleteProductMediaForCode(reqMap);
    }

    @PostMapping("/add/cat")
    public Map<String, Object> addCategoryToProduct(@RequestBody Map<String, Object> reqMap){
        return productService.addCategoryToProduct(reqMap);
    }

    @PostMapping("/remove/cat")
    public Map<String, Object> removeCategoryFromProduct(@RequestBody Map<String, Object> reqMap){
        return productService.removeCategoryFromTheProduct(reqMap);
    }

    @PostMapping("/update-order")
    public Map<String, Object> updateProductOrder(@RequestBody Map<String, Object> reqMap){
        return productService.updateProductOrderList(reqMap);
    }
    
    @PostMapping("/delete")
    public Map<String, Object> deleteProduct(@RequestBody Map<String, Object> reqMap){
    	return productService.deleteProduct(reqMap);
    }
}
