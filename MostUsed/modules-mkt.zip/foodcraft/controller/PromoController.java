package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.model.promotion.PromoCode;
import com.ekfc.foodcraft.services.PromotionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/fcadmin/api/promotions")
@CrossOrigin(origins = "*")
public class PromoController {

    @Autowired
    private PromotionService promotionService;

    @PostMapping
    public Map<String, Object> getAllPromotions(){
        return promotionService.getAllPromotions();
    }

    @PostMapping("/update")
    public Map<String, Object> updatePromotion(@RequestBody PromoCode promoCode){
        return promotionService.updatePromotion(promoCode);
    }

    @PostMapping("/add")
    public Map<String, Object> addPromotion(@RequestBody PromoCode promoCode){
        return promotionService.addPromotion(promoCode);
    }
}
