package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.services.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin (origins = "*")
@RequestMapping("/fcadmin/api/email")
public class EmailController {


    @Autowired
    private EmailService emailService;

    @PostMapping("/send-campaign")
    public Map<String, Object> sendEmailCampaigns(@RequestBody final Map<String, Object> reqMap){
        return emailService.sendEmail(reqMap);
    }
}
