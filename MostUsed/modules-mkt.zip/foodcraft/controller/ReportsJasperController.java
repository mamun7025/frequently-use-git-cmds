package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.model.reports.RptRequestDTO;
import com.ekfc.foodcraft.services.report.JsrReportRenderService;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Map;


@CrossOrigin("*")
@Controller
@RequestMapping("/fcadmin/api/report")
public class ReportsJasperController {

    final JsrReportRenderService jsrReportRenderService;

    @Autowired
    public ReportsJasperController(JsrReportRenderService jsrReportRenderService) {
        this.jsrReportRenderService = jsrReportRenderService;
    }


    /**
     * Report
     * By product category ---------------------------------------------------------------------------------------------
     * @param rptRequestDTO DTO
     * @return base64 string
     */
    @PostMapping("/sales-report-by-product-category")
    public ResponseEntity<?> getSaleRptByProductCategoryWise(@RequestBody RptRequestDTO rptRequestDTO){
        try {

            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            byte [] pdfBytes = JasperExportManager.exportReportToPdf(jasperPrint);
            String encodedString = Base64.getEncoder().encodeToString(pdfBytes);
            return ResponseEntity.ok(encodedString);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/sales-report-by-product-category-export")
    public HttpEntity<byte[]> getSaleRptByProductCategoryWiseExport(@RequestParam("rptFileName") String rptFileName, HttpServletResponse response){

        String outputFileName = rptFileName + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String reportFormat = "XLSX";
        RptRequestDTO rptRequestDTO = new RptRequestDTO(rptFileName, outputFileName, reportFormat);

        // process
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
        response.setHeader("Content-Disposition", "filename="+outputFileName+".xlsx");
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(true);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            return new HttpEntity<>(excelBytes, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }


    @PostMapping("/jasper/sales-report-by-product-category-export-post")
    public ResponseEntity<?> getSaleRptByProductCategoryWiseExportPost(@RequestBody RptRequestDTO rptRequestDTO){
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(false);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            String encodedString = Base64.getEncoder().encodeToString(excelBytes);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", encodedString));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


    /**
     * Report
     * Order Info by date ----------------------------------------------------------------------------------------------
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/jasper/all-order-info")
    public ResponseEntity<?> getAllOrderInfoRptByDate(@RequestBody Map<String, String> requestMap){
        try {
            RptRequestDTO rptRequestDTO = new RptRequestDTO(requestMap.get("rptFileName"), requestMap.get("outputFileName"), requestMap.get("reportFormat"));
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport_withFilterParams(rptRequestDTO, requestMap);
            byte [] pdfBytes = JasperExportManager.exportReportToPdf(jasperPrint);
            String encodedString = Base64.getEncoder().encodeToString(pdfBytes);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", encodedString));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    @GetMapping("/jasper/all-order-info-export")
    public HttpEntity<byte[]> getAllOrderInfoRptByDateExport(@RequestParam("rptFileName") String rptFileName, HttpServletResponse response){

        String outputFileName = rptFileName + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String reportFormat = "XLSX";
        RptRequestDTO rptRequestDTO = new RptRequestDTO(rptFileName, outputFileName, reportFormat);

        // process
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
        response.setHeader("Content-Disposition", "filename="+outputFileName+".xlsx");
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(false);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            return new HttpEntity<>(excelBytes, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    @PostMapping("/jasper/all-order-info-export-export-post")
    public ResponseEntity<?> getAllOrderInfoRptByDateExportPost(@RequestBody RptRequestDTO rptRequestDTO){
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(false);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            String encodedString = Base64.getEncoder().encodeToString(excelBytes);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", encodedString));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }



    /**
     * Report
     * Order Info by Status ----------------------------------------------------------------------------------------------
     * @param rptRequestDTO DTO
     * @return base64 string
     */
    @PostMapping("/jasper/order-info-summary-rpt-by-status")
    public ResponseEntity<?> getOrderInfoSummaryRptByStatus(@RequestBody RptRequestDTO rptRequestDTO){
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            byte [] pdfBytes = JasperExportManager.exportReportToPdf(jasperPrint);
            String encodedString = Base64.getEncoder().encodeToString(pdfBytes);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", encodedString));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    @GetMapping("/jasper/order-info-summary-rpt-by-status-export")
    public HttpEntity<byte[]> getOrderInfoSummaryRptByStatusExport(@RequestParam("rptFileName") String rptFileName, HttpServletResponse response){

        String outputFileName = rptFileName + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String reportFormat = "XLSX";
        RptRequestDTO rptRequestDTO = new RptRequestDTO(rptFileName, outputFileName, reportFormat);

        // process
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("application/vnd.ms-excel"));
        response.setHeader("Content-Disposition", "filename="+outputFileName+".xlsx");
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(false);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            return new HttpEntity<>(excelBytes, headers);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }


    @PostMapping("/jasper/order-info-summary-rpt-by-status-export-post")
    public ResponseEntity<?> getOrderInfoSummaryRptByStatusExportPost(@RequestBody RptRequestDTO rptRequestDTO){
        try {
            JasperPrint jasperPrint = this.jsrReportRenderService.generateReport(rptRequestDTO);
            SimpleXlsxReportConfiguration configuration = new SimpleXlsxReportConfiguration();
            configuration.setOnePagePerSheet(false);
            configuration.setIgnoreGraphics(false);

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            JRXlsxExporter exporter = new JRXlsxExporter();
            exporter.setExporterInput(new SimpleExporterInput(jasperPrint));
            exporter.setExporterOutput(new SimpleOutputStreamExporterOutput(byteArrayOutputStream));
            exporter.setConfiguration(configuration);
            exporter.exportReport();

            byte [] excelBytes = byteArrayOutputStream.toByteArray();
            String encodedString = Base64.getEncoder().encodeToString(excelBytes);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", encodedString));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


}
