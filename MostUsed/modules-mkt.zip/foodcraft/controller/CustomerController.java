package com.ekfc.foodcraft.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekfc.foodcraft.services.CustomerService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api/customer")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;

	@PostMapping("/all")
	public Map<String, Object> getAllCustomersList(@RequestBody Map<String, Object> reqMap){
		return customerService.getAllCustomerDetails();
	}
	
	@PostMapping("/email")
	public Map<String, Object> getCustomerDetailsByEmail(@RequestBody Map<String, Object> reqMap){
		return customerService.getCustomerDetailsByEmail(reqMap);
	}
	
	@PostMapping("/update/address")
	public Map<String, Object> updateCustomerAddress(@RequestBody Map<String, Object> reqMap){
		return customerService.updateCustomerAddress(reqMap);
	}
	
	@PostMapping("/update/details")
	public Map<String, Object> updateCustomerInfo(@RequestBody Map<String, Object> reqMap){
		return customerService.updateCustomerInfo(reqMap);
	}
	
	@PostMapping("/tickets-list")
	public Map<String, Object> getAllTickets(@RequestBody Map<String, Object> reqMap){
		return customerService.getAllTickets();
	}
	
	@PostMapping("/tickets-list/filter")
	public Map<String, Object> getAllTicketsByFilter(@RequestBody Map<String, Object> reqMap){
		return customerService.getAllTicketsByFilter(reqMap);
	}
	
	@PostMapping("/tickets-list/download")
	public Map<String, Object> downloadSupportTicketReport(@RequestBody Map<String, Object> reqMap){
		return customerService.downloadSupportTicketReport(reqMap);
	}
	
	@PostMapping("/tickets-details")
	public Map<String, Object> getTicketDetailsById(@RequestBody Map<String, Object> reqMap){
		return customerService.getTicketDetailsForUser(reqMap);
	}
	
	@PostMapping("/discussions/add")
	public Map<String, Object> addTicketDiscussionForUser(@RequestBody Map<String, Object> reqMap){
		return customerService.addTicketDiscussionForUser(reqMap);
	}
	
	@PostMapping("/ticket/update")
	public Map<String, Object> updateTicketStatus(@RequestBody Map<String, Object> reqMap){
		return customerService.updateTicketStatus(reqMap);
	}
}
