package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.dao.WalletDAO;
import com.ekfc.foodcraft.model.Wallet;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/fcadmin/api/wallet")
public class WalletController {

    private final WalletService walletService;
    private final WalletDAO walletDAO;

    @Autowired
    public WalletController(WalletService walletService, WalletDAO walletDAO) {
        this.walletService = walletService;
        this.walletDAO = walletDAO;
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody Map<String, String> requestMap){
        try {
            boolean status = walletService.create(requestMap);
            if(status){
                return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", "Successfully create wallet"));
            }
            return ResponseEntity.ok(new ResponseModel(false, HttpStatus.OK.value(), "Fail", "Fail to create wallet, " + walletDAO.errorDetails));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/get")
    public ResponseEntity<?> read(@RequestBody Map<String, String> requestMap){
        try {
            Wallet wallet = walletService.read(requestMap);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", wallet));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/update")
    public ResponseEntity<?> update(@RequestBody Map<String, String> requestMap){
        try {
            boolean status = walletService.update(requestMap);
            if(status){
                return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", "Successfully update wallet"));
            }
            return ResponseEntity.ok(new ResponseModel(false, HttpStatus.OK.value(), "Fail", "Fail update wallet"));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/get-paginated-data")
    public ResponseEntity<?> getAllPaginated(@RequestBody Map<String, String> requestMap){
        return walletService.getAllPaginated(requestMap);
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/get-all-wallet-log-data")
    public ResponseEntity<?> getActivityLogData(@RequestBody Map<String, String> requestMap){
        try {
            List<LinkedHashMap<String, Object>> dataList = walletService.getActivityLogData(requestMap);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Activity Data List", dataList));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }


}
