package com.ekfc.foodcraft.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

import com.ekfc.foodcraft.model.OrdersHeader;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekfc.foodcraft.services.*;

@RestController
@RequestMapping("/fcadmin/api")
@CrossOrigin(origins = "*")
public class OrdersController {

	@Autowired
	OrderService ordersService;
	
	@Autowired
	HttpServletRequest request;

	
	@PostMapping("/getHistory")
	public Map<String, Object> getOrderHistory(@RequestBody Map<String, Object> reqMap ){
		return ordersService.getOrderHistory(reqMap);
	}
	
	@PostMapping("/getOrderDetails")
	public Map<String, Object> getOrderDetails(@RequestBody Map<String, Object> reqMap ){
		return ordersService.getOrderDetails(reqMap);
	}
	
	@PostMapping("/updateOrderStatus")
	public Map<String, Object> updateOrderStatus(@RequestBody Map<String, Object> reqMap ){
		return ordersService.updateOrderStatus(reqMap);
	}
	
	@PostMapping("/updateProductStatus")
	public Map<String, Object> updateProductStatus(@RequestBody Map<String, Object> reqMap ){
		Map<String, Object> resMap= new HashMap<String, Object>();
		boolean isUpdated = ordersService.updateProductStatus(reqMap);
		if(isUpdated) {
			resMap.put("result","Product Status Updated");
		}
		else {
			resMap.put("error","Product Status Updated");			
		}
		return resMap;
	}


	@PostMapping("/get-invoice-document")
	public ResponseEntity<?> getInvoiceDocument(@RequestBody Map<String, Object> reqMap ){
		try {
			OrdersHeader ordersHeader = ordersService.getInvoiceDocument(reqMap);
			ResponseModel response = new ResponseModel(true, HttpStatus.OK.value(), "Success", ordersHeader.getInvoice());
			return ResponseEntity.ok(response);
		} catch (Exception ex){
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
		}
	}
	
	@PostMapping("/create/erp-request")
	public ResponseEntity<?> createERPRequest(@RequestBody Map<String, Object> reqMap){
		try {
			ordersService.createERPRequest(reqMap);
			ResponseModel response = new ResponseModel(true, HttpStatus.OK.value(), "Success", "Request Sent successfully");
			return ResponseEntity.ok(response);
		}
		catch(Exception ex) {
			return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
		}
	}


}
