package com.ekfc.foodcraft.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekfc.foodcraft.services.LoyaltyConfigService;

@RestController
@RequestMapping("/fcadmin/api/loyalty")
@CrossOrigin(origins = "*")
public class LoyaltyController {

	@Autowired
	private LoyaltyConfigService service;
	
	@PostMapping("/get/all")
	public Map<String, Object> getLoyaltyConfigList(@RequestBody Map<String, Object> reqMap){
		return service.getLoyaltyConfig(reqMap);
	}
	
	@PostMapping("/update/byType")
	public Map<String, Object> saveLoyaltyConfigList(@RequestBody Map<String, Object> reqMap){
		return service.saveLoyaltyConfig(reqMap);
	}
}
