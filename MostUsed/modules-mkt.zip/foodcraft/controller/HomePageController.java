package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.model.homepage.CarouselModel;
import com.ekfc.foodcraft.model.homepage.CustFavoriteModel;
import com.ekfc.foodcraft.model.homepage.ExploreModel;
import com.ekfc.foodcraft.model.homepage.OurMenuModel;
import com.ekfc.foodcraft.services.HomepageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/fcadmin/api/home")
@CrossOrigin(origins = "*")
public class HomePageController {

    @Autowired
    private HomepageService homepageService;

    @PostMapping("/carousel")
    public Map<String, Object> getHomePageCarouselComponents(){
        return homepageService.getHomePageCarouselComponents();
    }

    @PostMapping("/carousel/add")
    public Map<String, Object> addCarouselBanner(@RequestBody CarouselModel requestObj){
        return homepageService.addCarouselBanner(requestObj);
    }

    @PostMapping("/carousel/remove")
    public Map<String, Object> removeCarouselBanner(@RequestBody Map<String, Object> reqMap){
        return homepageService.removeCarouselBanner(reqMap);
    }

    @PostMapping("/carousel/update")
    public Map<String, Object> updateCarouselBanner(@RequestBody CarouselModel requestObj){
        return homepageService.updateCarouselBanner(requestObj);
    }

    @PostMapping("/carousel/publish")
    public Map<String, Object> publishCarouselBanner(){
        return homepageService.publishCarouselBanner();
    }
    
    @PostMapping("/carousel/update/sorting")
    public Map<String, Object> updateCarouselOurMenuSorting(@RequestBody Map<String, Object> reqMap){
        return homepageService.updateCarouselOurMenuSorting(reqMap);
    }

    @PostMapping("/explore")
    public Map<String, Object> getExploreOurMenu(){
        return homepageService.getExploreOurMenuComponents();
    }

    @PostMapping("/explore/add")
    public Map<String, Object> addExploreOurMenu(@RequestBody ExploreModel requestObj){
        return homepageService.addExploreMenu(requestObj);
    }

    @PostMapping("/explore/remove")
    public Map<String, Object> removeExploreOurMenu(@RequestBody Map<String, Object> reqMap){
        return homepageService.removeExploreMenu(reqMap);
    }

    @PostMapping("/explore/update")
    public Map<String, Object> updateExploreOurMenu(@RequestBody ExploreModel requestObj){
        return homepageService.updateExploreMenu(requestObj);
    }
    
    @PostMapping("/explore/update/sorting")
    public Map<String, Object> updateExploreOurMenuSorting(@RequestBody Map<String, Object> reqMap){
        return homepageService.updateExploreOurMenuSorting(reqMap);
    }

    @PostMapping("/explore/publish")
    public Map<String, Object> publishExploreOurMenu(){
        return homepageService.publishExploreMenu();
    }
    

    @PostMapping("/craft-perfect")
    public Map<String, Object> getCraftPerfectMeal(){
        return homepageService.getCraftPerfectMealsComponents();
    }

    @PostMapping("/craft-perfect/add")
    public Map<String, Object> addCraftPerfectMeal(@RequestBody ExploreModel requestObj){
        return homepageService.addCraftPerfectMeals(requestObj);
    }

    @PostMapping("/craft-perfect/remove")
    public Map<String, Object> removeCraftPerfectMeal(@RequestBody Map<String, Object> reqMap){
        return homepageService.removeCraftPerfectMeals(reqMap);
    }

    @PostMapping("/craft-perfect/update")
    public Map<String, Object> updateCraftPerfectMeal(@RequestBody ExploreModel requestObj){
        return homepageService.updateCraftPerfectMeals(requestObj);
    }
    
    @PostMapping("/craft-perfect/update/sorting")
    public Map<String, Object> updateCraftPerfectMealSorting(@RequestBody Map<String, Object> reqMap){
        return homepageService.updateCraftPerfectMealsSorting(reqMap);
    }

    @PostMapping("/craft-perfect/publish")
    public Map<String, Object> publishCraftPerfectMeal(){
        return homepageService.publishCraftPerfectMeals();
    }

    @PostMapping("/cust-fav")
    public Map<String, Object> getAllCustomerFavorites(){
        return homepageService.getAllCustomerFavorites();
    }

    @PostMapping("/cust-fav/add")
    public Map<String, Object> addCustomerFavarites(@RequestBody CustFavoriteModel customerFavModel){
        return homepageService.addCustomerFavorites(customerFavModel);
    }

    @PostMapping("/cust-fav/update")
    public Map<String, Object> updateCustomerFavarites(@RequestBody CustFavoriteModel customerFavModel){
        return homepageService.updateCustomerFavorites(customerFavModel);
    }
    
    @PostMapping("/cust-fav/getProducts")
    public Map<String, Object> getCampProducts(@RequestBody Map<String, Object> reqMap){
    	return homepageService.getCampProducts(reqMap);
    }
    
    @PostMapping("/cust-fav/del")
    public Map<String, Object> delCamp(@RequestBody Map<String, Object> reqMap){
    	return homepageService.delCamp(reqMap);
    }

    @PostMapping("/cust-fav/publish")
    public Map<String, Object> publishCustomerFavorites(){
        return homepageService.publishCustomerFavorites();
    }
    
    @PostMapping("/our-menu")
    public Map<String, Object> getOurMenuComponents(){
        return homepageService.getOurMenuComponents();
    }

    @PostMapping("/our-menu/add")
    public Map<String, Object> addOurMenuComponents(@RequestBody Map<String, Object> reqMap){
        return homepageService.addOurMenuComponents(reqMap);
    }

    @PostMapping("/our-menu/remove")
    public Map<String, Object> removeOurMenuComponents(@RequestBody Map<String, Object> reqMap){
        return homepageService.removeOurMenuComponents(reqMap);
    }

    @PostMapping("/our-menu/update")
    public Map<String, Object> updateOurMenuComponents(@RequestBody OurMenuModel requestObj){
        return homepageService.updateOurMenuComponents(requestObj);
    }
    
    @PostMapping("/our-menu/update/sorting")
    public Map<String, Object> updateOurMenuComponentsSorting(@RequestBody Map<String, Object> reqMap){
        return homepageService.updateOurMenuComponentsSorting(reqMap);
    }

    @PostMapping("/our-menu/publish")
    public Map<String, Object> publishOurMenuComponents(){
        return homepageService.publishOurMenuComponents();
    }

}