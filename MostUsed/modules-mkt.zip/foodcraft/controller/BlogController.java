package com.ekfc.foodcraft.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekfc.foodcraft.model.BlogModel;
import com.ekfc.foodcraft.services.BlogService;

@RestController
@RequestMapping("/fcadmin/api/blogs")
@CrossOrigin(origins = "*")

public class BlogController {
	
	@Autowired 
	private BlogService blogService;
	
	
    @PostMapping("/all")
    public Map<String, Object> getAllBlogs(){
        return blogService.getBlogs();
    }

    @PostMapping("/add")
    public Map<String, Object> addBlog(@RequestBody BlogModel requestObj){
        return blogService.addBlog(requestObj);
    }

    @PostMapping("/remove")
    public Map<String, Object> removeBlog(@RequestBody Map<String, Object> reqMap){
        return blogService.removeBlog(reqMap);
    }

    @PostMapping("/update")
    public Map<String, Object> updateBlog(@RequestBody BlogModel requestObj){
        return blogService.updateBlog(requestObj);
    }
    
    @PostMapping("/update/sorting")
    public Map<String, Object> updateBlogSorting(@RequestBody Map<String, Object> reqMap){
        return blogService.updateBlogSorting(reqMap);
    }

    @PostMapping("/publish")
    public Map<String, Object> publishBlog(){
        return blogService.publishBlog();
    }
}
