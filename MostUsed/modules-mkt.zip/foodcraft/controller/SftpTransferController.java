package com.ekfc.foodcraft.controller;


import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.SftpTransferFileService;
import com.ekfc.foodcraft.services.SftpTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/fcadmin/api/transfer")
public class SftpTransferController {

    private final SftpTransferService sftpTransferService;
    private final SftpTransferFileService transferFileService;

    @Autowired
    public SftpTransferController(SftpTransferService sftpTransferService, SftpTransferFileService transferFileService) {
        this.sftpTransferService = sftpTransferService;
        this.transferFileService = transferFileService;
    }

    @PostMapping("/push-remote")
    public ResponseEntity<?> doPushRemote(@RequestBody Map<String, Object> requestMap){
        try {
            sftpTransferService.setConfigProperties();
            sftpTransferService.transferFileToRemoteHost();
            
            transferFileService.setConfigProperties();
            transferFileService.transferFileToRemoteHost();
            
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", "Push code to remote server successfully"));
        } catch (Exception ex){
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    /*@PostMapping("/push-remote-folder-content")
    public ResponseEntity<?> doPushRemoteFolderContent(@RequestBody Map<String, Object> requestMap){
        try {
            transferFileService.setConfigProperties();
            transferFileService.transferFileToRemoteHost();
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", "Push code to remote server successfully"));
        } catch (Exception ex){
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }*/


}
