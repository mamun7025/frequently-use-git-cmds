package com.ekfc.foodcraft.controller;

import com.ekfc.foodcraft.model.PushNotification;
import com.ekfc.foodcraft.model.generic.ResponseErrorModel;
import com.ekfc.foodcraft.model.generic.ResponseModel;
import com.ekfc.foodcraft.services.PushNotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@CrossOrigin("*")
@RestController
@RequestMapping("/fcadmin/api")
public class PushNotificationController {

    private final PushNotificationService pushNotificationService;

    @Autowired
    public PushNotificationController(PushNotificationService pushNotificationService) {
        this.pushNotificationService = pushNotificationService;
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/notification/save-data")
    public ResponseEntity<?> saveFormData(@RequestBody Map<String, String> requestMap){
        try {
            boolean status = pushNotificationService.saveData(requestMap);
            if(status){
                return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Success", "Successfully save data"));
            }
            return ResponseEntity.ok(new ResponseModel(false, HttpStatus.OK.value(), "Fail", "fail save data"));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/notification/get-notification-data")
    public ResponseEntity<?> getPushNotificationData(@RequestBody Map<String, String> requestMap){
        try {
            List<PushNotification> dataList = pushNotificationService.getData(requestMap);
            return ResponseEntity.ok(new ResponseModel(true, HttpStatus.OK.value(), "Notification List", dataList));
        } catch (Exception ex) {
            ex.printStackTrace();
            return ResponseEntity.status(HttpStatus.OK).body(new ResponseErrorModel(false, HttpStatus.INTERNAL_SERVER_ERROR.value(), "Request fail", ex.getMessage(), null));
        }
    }

    /**
     * @param requestMap DTO
     * @return base64 string
     */
    @PostMapping("/notification/get-notification-data-pages")
    public ResponseEntity<?> getPushNotificationDataPaginated(@RequestBody Map<String, String> requestMap){
        return pushNotificationService.getDataPaginated(requestMap);
    }

}
