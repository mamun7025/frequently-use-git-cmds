package com.ekfc.foodcraft.controller;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;

@RestController
public class PingController {


    @GetMapping("/ping")
    public String pingMe(){
        return "pong";
    }

    @ResponseBody
    @GetMapping("/convert-hash")
    public String convertHash256(@RequestParam("q") String qTxt){

        String sha256hex = org.apache.commons.codec.digest.DigestUtils.sha256Hex(qTxt);
        System.out.println(sha256hex);
        return "Plain Text: " + qTxt + ", Hash 256: " + sha256hex;

    }


    public String convertToSHA256String(String plainStr){
        return org.apache.commons.codec.digest.DigestUtils.sha256Hex(plainStr);
    }

    @PostMapping("/convert-hash")
    public String convertHashSH256(@RequestBody HashMap<String, Object> reqMap ){

        String sha256hex = convertToSHA256String(reqMap.get("q").toString());
        System.out.println(sha256hex);
        return "Plain Text: " + reqMap.get("q").toString() + ", Hash 256: " + sha256hex;

    }


}
