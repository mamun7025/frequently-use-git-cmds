package com.ekfc.foodcraft.dao;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.model.Address;
import com.ekfc.foodcraft.model.CustomersData;
import com.ekfc.foodcraft.model.SupportTicketDiscussion;
import com.ekfc.foodcraft.model.SupportTicketHeader;
import com.ekfc.foodcraft.templates.EmailTemplate;
import com.ekfc.foodcraft.utils.ERPUtil;

@Component
public class CustomerDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private Environment env;
	
	public List<CustomersData> getAllCustomers(){
		return jdbcTemplate.query("call p_cms_get_all_customer_list()",
				(rs, rowNum) -> new CustomersData(rs.getString("x1"),rs.getString("x2"),
						rs.getString("x3"),rs.getString("x4"),rs.getString("x5"),rs.getString("x6"),
						rs.getString("x7")));
	}
	
	public List<CustomersData> getCustomerDetailsByEmail(String email){
		return jdbcTemplate.query("call p_cms_get_customer_details_all(?)",
				(rs, rowNum) -> new CustomersData(rs.getString("x1"),rs.getString("x2"),
						rs.getString("x3"),rs.getString("x4"),rs.getString("x5"),rs.getString("x6"),
						 rs.getString("x7")),
				new Object[] {email});
	}
	
	public List<Address> getAddressesForUser(String user) {
		List<Address> addresses = jdbcTemplate.query(
				"call p_get_addresses_for_user(?)",
				(rs, rowNum) -> new Address(
						rs.getInt("x1"),
						rs.getString("x2"),
						rs.getString("x3"),
						rs.getString("x4"),
						rs.getString("x5"),
						rs.getString("x6"),
						rs.getString("x7"),
						rs.getString("x8"),
						rs.getString("x9"),
						rs.getBoolean("x10"),
						rs.getString("x11")
				),
				new Object[] {user}
		);
		return addresses;
	}
	
	public boolean updateAddress(Address add) {
		try{
			int rows = jdbcTemplate.update(
					"call p_update_address_for_user(?,?,?,?,?,?,?,?,?,?,?)",
					new Object[] {
							add.getFirstName(),
							add.getLastName(),
							add.getStreetAddress(),
							add.getStreetName(),
							add.getApartment(),
							add.getLandmark(),
							add.getCity(),
							add.getArea(),
							add.isPrimaryCheck(),
							add.getUserId(),
							add.getId()
					}
			);
			if(rows == 0) {
				return true;
			}
				return false;

		}catch(Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	
	public List<Address> getPrimaryAddress(String user) {
		List<Address> addresses = jdbcTemplate.query(
				"call p_get_primary_address_for_user(?,?)",
				(rs, rowNum) -> new Address(
						rs.getInt("x1"),
						rs.getString("x2"),
						rs.getString("x3"),
						rs.getString("x4"),
						rs.getString("x5"),
						rs.getString("x6"),
						rs.getString("x7"),
						rs.getString("x8"),
						rs.getString("x9"),
						rs.getBoolean("x10"),
						rs.getString("x11")
				),
				new Object[] {user, true}
		);
		return addresses;
	}
	
	public boolean updateUser(String email, String firstName, String lastName, String phone, String password, String communication) throws IOException {
		jdbcTemplate.update("call p_cms_update_user_details(?,?,?,?,?,?)",
				new Object[]{email, firstName, lastName, phone, password, communication}
		);
		return true;
	}
	
	
	public List<SupportTicketHeader> getAllTicketsList(){
		 return jdbcTemplate.query("call p_cms_all_customer_tickets()",
				(rs, rowNum) -> new SupportTicketHeader(
						rs.getInt("x1"),
						rs.getString("x2"),
						rs.getString("x3"),
						rs.getString("x4"),
						rs.getString("x5"),
						rs.getString("x6"),
						rs.getDate("x7"),
						rs.getDate("x8"),
						rs.getString("x9"),
						rs.getString("x10")),
				new Object[] {});
	}
	
	public List<SupportTicketHeader> getAllTicketsListByFilter(Map<String, Object> reqMap){
		String id=((reqMap.get("id") != null && (String)reqMap.get("id") !="") ? (String)reqMap.get("id") : null);
		String email= ((reqMap.get("email") != null  && (String)reqMap.get("email") !="") ? (String)reqMap.get("email") : null);
		String priority= ((reqMap.get("priority") != null  && (String)reqMap.get("priority") !="") ? (String)reqMap.get("priority") : null);
		String type= ((reqMap.get("type") != null  && (String)reqMap.get("type") !="") ? (String)reqMap.get("type") : null);
		String status= ((reqMap.get("status") != null  && (String)reqMap.get("status") !="") ? (String)reqMap.get("status") : null);
		String date= ((reqMap.get("date") != null  && (String)reqMap.get("date") !="") ? (String)reqMap.get("date") : null);
		
		 return jdbcTemplate.query("call p_cms_all_customer_tickets_by_filter(?,?,?,?,?,?)",
				(rs, rowNum) -> new SupportTicketHeader(
						rs.getInt("x1"),
						rs.getString("x2"),
						rs.getString("x3"),
						rs.getString("x4"),
						rs.getString("x5"),
						rs.getString("x6"),
						rs.getDate("x7"),
						rs.getDate("x8"),
						rs.getString("x9"),
						rs.getString("x10")),
				new Object[] {
						id,
						email,
						priority,
						type,
						status,
						date
						});
	}
	
	
	public List<SupportTicketHeader> getTicketDetailsForUser(String user, String id){
		List<SupportTicketHeader> tickets = jdbcTemplate.query(
				"call p_get_ticket_details_for_user_by_id(?,?)",
				(rs, rowNum) -> new SupportTicketHeader(
						rs.getInt("x1"),
						rs.getString("x2"),
						rs.getString("x3"),
						rs.getString("x4"),
						rs.getString("x5"),
						rs.getString("x6"),
						rs.getDate("x7"),
						rs.getDate("x8"),
						rs.getString("x9"),
						rs.getString("x10")
				),
				new Object[] {
						user, id
				}
		);
		return tickets;
	}

	public List<SupportTicketDiscussion> getDiscussionForTickets(int ticketId){
		List<SupportTicketDiscussion> discussions = jdbcTemplate.query(
				"call p_get_ticket_discussion(?)",
				(rs, rowNum) -> new SupportTicketDiscussion(
						rs.getInt("x1"),
						rs.getInt("x2"),
						rs.getBoolean("x3"),
						rs.getBoolean("x4"),
						rs.getString("x5"),
						rs.getDate("x6")
				),
				new Object[] {
						ticketId
				}
		);
		return discussions;
	}
	
	public boolean addDiscussionToTicket(int ticketId, boolean customer, boolean employee, String description){
		try{
			jdbcTemplate.update(
					"call p_create_ticket_discussion(?,?,?,?)",
					new Object[] {
							ticketId, customer, employee, description
					}
			);
			return true;
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
	
	public Map<String, Object> updateTicketStatusList(Map<String, Object> reqMap) throws IOException{
		@SuppressWarnings("unchecked")
		final List<Map<String, Object>> data = (List<Map<String, Object>>) reqMap.get("ticketList");
        String status = reqMap.get("status").toString();
		for(Map<String, Object> ticketList : data) {
			String id = (String)ticketList.get("ticketNumber");
			String email = (String)ticketList.get("custEmail");
			EmailTemplate et = new EmailTemplate();
			boolean isUpdated = this.updateTicketStatus(id,status);
			if(isUpdated) {
				System.out.println("IS Updated : "+isUpdated);
				Runnable myRunnable1 = new Runnable() {
					public void run() {
						try {
							ERPUtil.sendTicketStatusEmail(
									id,
									email,
									et.logo,
//									env.getProperty("send.new.user.email.dl"),
									email,
									"Thank you for reaching out to us! ",
									env.getProperty("epost.domain.url"),
									env.getProperty("send.email.endpoint"),
									env.getProperty("basic.auth.email.header")

							);
						}
						catch(Exception e) {
							e.printStackTrace();
						}
			}
		};
		Thread thread = new Thread(myRunnable1);
		thread.start();
			}
		}
			return reqMap;
	}
	
	public boolean updateTicketStatus(String ticketId, String status){
		try{
			jdbcTemplate.update(
					"call p_cms_update_ticket_status(?,?)",
					new Object[] {
							ticketId, status
					}
			);
			return true;
		}catch (Exception ex){
			ex.printStackTrace();
		}
		return false;
	}
}
