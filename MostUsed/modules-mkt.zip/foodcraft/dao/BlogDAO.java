package com.ekfc.foodcraft.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.model.BlogModel;

@Component
public class BlogDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
    public List<BlogModel> getBlogs() {
        final List<BlogModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_all_blog()",
                (rs, rowNum) -> new BlogModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6"),
                        rs.getString("x7"),
                        rs.getString("x8"),
                        rs.getString("x9")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public List<BlogModel> getActiveBlogs() {
        final List<BlogModel> blogModel = jdbcTemplate.query(
                "call p_cms_get_active_blog()",
                (rs, rowNum) -> new BlogModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6"),
                        rs.getString("x7"),
                        rs.getString("x8"),
                        rs.getString("x9")
                ),
                new Object[] {}
        );

        return blogModel;
    }

    public boolean addBlog(BlogModel requestObj) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_blog(?,?,?,?,?,?)",
                    new Object[] {
                        requestObj.getTitle(),
                        requestObj.getContent(),
                        requestObj.getImgPath(),
                        requestObj.isActive(),
                        requestObj.getType(),
                        requestObj.getUrl()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateBlog(BlogModel requestObj) {
        final String title = requestObj.getTitle();
        final String content = requestObj.getContent();
        final String type = requestObj.getType();
        final String imgPath = requestObj.getImgPath();
        final String url = requestObj.getUrl();
        final boolean active = requestObj.isActive();
        final long id = requestObj.getId();

        try {
            jdbcTemplate.update(
                    "call p_cms_update_blog(?,?,?,?,?,?,?)",
                    new Object[]{
                            id,
                            title,
                            content,
                            imgPath,
                            active,
                            type,
                            url
                    }
            );
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeBlog(int id) {

        try{
            jdbcTemplate.update(
                    "call p_cms_remove_blog(?)",
                    new Object[] {id
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean updateOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_blog_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
}
