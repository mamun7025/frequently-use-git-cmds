package com.ekfc.foodcraft.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.ekfc.foodcraft.model.LoyaltyEarnBurnModel;

@Component
public class LoyaltyConfigDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public boolean createEarnBurnConfig(final LoyaltyEarnBurnModel model) {
		try {
		jdbcTemplate.update("call p_cms_create_earn_burn_points_config(?,?,?,?)",
				new Object[] {model.getType(),model.getPoints(), model.getPrice(), model.getActive()});
		return true;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public boolean updateEarnBurnConfig(final LoyaltyEarnBurnModel model) {
		try {
		jdbcTemplate.update("call p_cms_update_earn_burn_points_config(?,?,?,?)",
				new Object[] {model.getType(),model.getPoints(), model.getPrice(), model.getActive()});
		return true;
		}
		catch(Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public List<LoyaltyEarnBurnModel> getLoyaltyDetailsByType(final String type) {
		try {
			List<LoyaltyEarnBurnModel> list =  jdbcTemplate.query("call p_cms_get_earn_burn_points(?)",
					(rs, rowNum) -> new LoyaltyEarnBurnModel(rs.getDouble("x1"), 
							rs.getDouble("x2"), rs.getBoolean("x3"), rs.getString("x4")),
					new Object[] {type});
			if(!list.isEmpty()) {
				return list;				
			}
			else {
				return null;
			}

			}
			catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}
	}
	
	
	public List<LoyaltyEarnBurnModel> getAllLoyaltyDetails() {
		try {
			List<LoyaltyEarnBurnModel> list =  jdbcTemplate.query("call p_cms_get_all_earn_burn_points()",
					(rs, rowNum) -> new LoyaltyEarnBurnModel(rs.getDouble("x1"), 
							rs.getDouble("x2"), rs.getBoolean("x3"), rs.getString("x4")),
					new Object[] {});
			return list;

			}
			catch(Exception ex) {
				ex.printStackTrace();
				return null;
			}
	}
}
