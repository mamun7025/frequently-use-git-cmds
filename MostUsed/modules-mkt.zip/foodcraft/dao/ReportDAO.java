package com.ekfc.foodcraft.dao;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.model.OrderReport;
import com.ekfc.foodcraft.model.OrdersDetails;
import com.ekfc.foodcraft.model.reports.OrderQuanityDTO;

@Component
public class ReportDAO {

	public final static String TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	  static final String[] HEADERs = { "Order Number"	,"Order Date"	,"Delivery date"	,"Delivery timeslot"	,"Customer Note"	,"Payment Method Title"	,"Total amount (Inc. VAT)","Cash on delivery fee"	,"Delivery charges"	,"Address 1&2 (Shipping)"	,"Street number / name"	,"Landmark"	,"City (Shipping)" };
	  static final String SHEET = "Orders";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//new
	public List<OrderQuanityDTO> getOrderQuantityByCodes(String startDate,String endDate,String productCodes) {
		List<OrderQuanityDTO> result = jdbcTemplate.query("call p_cms_get_order_information_by_pcode(?,?,?)",
				(rs,rowNum)-> new OrderQuanityDTO(rs.getString("ProductCode"),rs.getString("ProductName"),rs.getInt("Quantity")),
				new Object[] {startDate,endDate,productCodes});
		return result;
	}
	//new
	public List<OrdersDetails> getOrderDetailsForProductCode(String startDate,String endDate,String productCodes) {
		return this.jdbcTemplate.query("call p_cms_get_order_for_pcode(?,?,?)",
				(rs, rowNum) -> new OrdersDetails(rs.getString("description"), rs.getString("category"),
						rs.getString("packaging"), rs.getString("uom"), rs.getString("origin"),
						rs.getInt("quantity"), rs.getString("pricingUom"), rs.getDouble("salesprice"),
						rs.getDouble("baseprice"), rs.getString("p_code"), rs.getInt("id"),rs.getString("created_on")),
				new Object[] { startDate,endDate,productCodes });
	}
	
	public Map<String, Object> getOrderHistory(String deliveryDate) {
		Map<String, Object> resultMap = new HashMap<String, Object>();

			StringBuilder builder = new StringBuilder(
					"call p_cms_all_orders_by_date(?)");
			
			List<OrderReport> orderList = jdbcTemplate.query(builder.toString(),
					(rs, rowNum) -> new OrderReport(rs.getInt("x1"), rs.getString("x2"),
							deliveryDate, rs.getString("x5"), rs.getString("x6"),
							rs.getString("x7"), rs.getString("x8"), rs.getDouble("x4"),
							rs.getString("x3")), 
					new Object[] {deliveryDate} );
			if (orderList.isEmpty()) {
				resultMap.put("Error", "No records found");
			} else {
				resultMap.put("result", orderList);
			}

		return resultMap;
	}
	
	public List<OrderReport> getAllOrderHistory(String deliveryDate) {

		deliveryDate = deliveryDate.replaceAll("-","/");
			StringBuilder builder = new StringBuilder(
					"call p_cms_all_orders_details_by_date(?)");
			
			List<OrderReport> orderList = jdbcTemplate.query(builder.toString(),
					(rs, rowNum) -> new OrderReport(rs.getInt("x1"), rs.getString("x2"),
							rs.getString("x3"), rs.getString("x4"), rs.getDouble("x5"),
							rs.getString("x6"), rs.getString("x7"), rs.getDouble("x8"),
							rs.getDouble("x9"), rs.getString("x10"), rs.getString("x11"),
							rs.getString("x12"),rs.getString("x13"),rs.getString("x14"),
							rs.getString("x15"),rs.getString("x16"),rs.getString("x17")), 
					new Object[] {deliveryDate} );
		return orderList;
	}
	
	
	public ByteArrayInputStream downloadExcel(String deliveryDate){
		try(Workbook workbook = new XSSFWorkbook()){
			
			Sheet sheet = workbook.createSheet(SHEET);
			Row headerRow = sheet.createRow(0);
			for(int col =0; col<HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}
			int rowIdx = 1;
			List<OrderReport> orderReport = getAllOrderHistory(deliveryDate);
			for(OrderReport od : orderReport) {
				Row row = sheet.createRow(rowIdx++);
				row.createCell(0).setCellValue(od.getOrderNumber());
				row.createCell(1).setCellValue(od.getCreatedOn());
				row.createCell(2).setCellValue(od.getDeliveryDate());
				row.createCell(3).setCellValue(od.getDeliverySlots());
				row.createCell(4).setCellValue(od.getNote());
				row.createCell(5).setCellValue(od.getPaymentMode());
				row.createCell(6).setCellValue(od.getTotalAmount());
				row.createCell(7).setCellValue(od.getDeliverFee());
				row.createCell(8).setCellValue(od.getProcessingFee());
				row.createCell(9).setCellValue(od.getShippingAddress());
				row.createCell(10).setCellValue(od.getStreetName());
				row.createCell(11).setCellValue(od.getLandmark());
				row.createCell(12).setCellValue(od.getCity());
			}
			sheet.autoSizeColumn(0);
	        sheet.autoSizeColumn(1);
	        sheet.autoSizeColumn(2);
	        sheet.autoSizeColumn(3);
			sheet.autoSizeColumn(4);
	        sheet.autoSizeColumn(5);
	        sheet.autoSizeColumn(6);
	        sheet.autoSizeColumn(7);
			sheet.autoSizeColumn(8);
	        sheet.autoSizeColumn(9);
	        sheet.autoSizeColumn(10);
	        sheet.autoSizeColumn(11);
	        ByteArrayOutputStream out = new ByteArrayOutputStream();
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		}
		catch(IOException ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
}
