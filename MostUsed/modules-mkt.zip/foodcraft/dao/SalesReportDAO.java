package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.generic.GenericModel;
import com.ekfc.foodcraft.model.reports.OrderRptBean;
import com.ekfc.foodcraft.services.PaginatorService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Component
public class SalesReportDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public List<GenericModel> getSalesRptDataByPC() {

        StringBuilder plSQL = new StringBuilder("call p_cms_rpt_get_product_category_wise_sales_data()");
        List<GenericModel> dataList = jdbcTemplate.query(plSQL.toString(),
                (rs, rowNum) -> new GenericModel(
                        rs.getString("product_category"),
                        rs.getString("total_sale_amt"))
        );
        return dataList;

    }

    public Map<String, Object> getAllOrderInfoDataPaginated( Map<String, String> filterParams ) {

        Map<String, Object> dataPage = new LinkedHashMap<>();
        List<OrderRptBean> dataList = new ArrayList<>();

        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        // pagination first
        PaginatorService ps = new PaginatorService(filterParams);
        searchParams.add(ps.getOffset());   // P1
        searchParams.add(ps.getSize());     // P2
        // others filter params
        // initialize default
        searchParams.add(null);             // P3, order num
        searchParams.add(null);             // P4, cust name
        searchParams.add(null);             // P5, cust phone
        searchParams.add(null);				// P6, cust email
        searchParams.add(null);             // P7, order Status
        searchParams.add(null);             // P8, from date
        searchParams.add(null);             // P9, to date
        searchParams.add(null);             // P10, customer type
        searchParams.add(null);             // P10, ERP Status
        // process and push params value
        searchParams.set(2, ( filterParams.containsKey("orderNum") && !filterParams.get("orderNum").isEmpty() ) ? Integer.parseInt(filterParams.get("orderNum"))  : null ); // P3, order num
        searchParams.set(3, (filterParams.get("customer") != null && !filterParams.get("customer").isEmpty()) ? filterParams.get("customer") : null );                      // P4, cust name
        searchParams.set(4, null );                                                                                                                                         // P5, cust phone
        searchParams.set(5, (filterParams.get("customerEmail") != null && !filterParams.get("customerEmail").isEmpty()) ? filterParams.get("customerEmail") : null  );      // P6, cust email
        searchParams.set(6, filterParams.getOrDefault("orderStatus", null) );                        // P7, order Status
        // for date range
        if( filterParams.containsKey("deliveryDate") && !filterParams.get("deliveryDate").isEmpty() ){
            searchParams.set(7, filterParams.get("deliveryDate"));                                                  // from date,   P8
            searchParams.set(8, filterParams.get("deliveryDate"));                                                  // from date,   P9
        }
        if( filterParams.containsKey("deliveryDateRange") && !filterParams.get("deliveryDateRange").isEmpty() ){
            String deliveryDateRange = filterParams.get("deliveryDateRange");
            searchParams.set(7, deliveryDateRange.split(" - ")[0]);                                           // from date,   P8
            searchParams.set(8, deliveryDateRange.split(" - ")[1]);                                           // from date,   P9
        }
        searchParams.set(9, filterParams.getOrDefault("customerType", null) );                       // P10, customer type
        searchParams.set(10, filterParams.getOrDefault("erpStatus", null) );                       // P10, customer type

        // procedures
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        StringBuilder plSQL = new StringBuilder("call p_cms_rpt_get_all_order_info_data_wf(?,?,?,?,?,?,?,?,?,?,?)");
        StringBuilder plSQLForCount = new StringBuilder("call p_cms_rpt_get_all_order_info_data_wf_row_count(?,?,?,?,?,?,?,?,?,?,?)");
        // execute
        Integer rowCount = this.jdbcTemplate.queryForObject(plSQLForCount.toString(), Integer.class, plSqlParams);

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    OrderRptBean orderRptBean = new OrderRptBean();
                    String orderNumber = resultSet.getString("order_number");
                    orderRptBean.setOrderNumber( orderNumber );
                    orderRptBean.setCustomerId(resultSet.getString("customer_id"));
                    orderRptBean.setCustomerFirstName(resultSet.getString("cust_first_name"));
                    orderRptBean.setCustomerLastName(resultSet.getString("cust_last_name"));
                    orderRptBean.setCustomerPhone(resultSet.getString("cust_phone"));
                    orderRptBean.setOrderPlaceTime(resultSet.getString("order_place_time"));
                    orderRptBean.setOrderStatus(resultSet.getString("order_status"));
                    orderRptBean.setDeliveryDate( resultSet.getString("delivery_date") );
                    orderRptBean.setDeliverySlots( resultSet.getString("delivery_slots") );
                    orderRptBean.setShippingAddress( resultSet.getString("delivering_address") );
                    orderRptBean.setPaymentMode( resultSet.getString("payment_mode") );
                    orderRptBean.setPaymentAmount( resultSet.getString("payment_amount") );
                    orderRptBean.setCustomerId( resultSet.getString("email") );
                    orderRptBean.setCustomerType( resultSet.getString("customer_type") );
                    orderRptBean.setErpStatus( resultSet.getString("erp_status") );
                    // push in list
                    dataList.add(orderRptBean);
                    processNextRow = resultSet.next();
                }
            }
        }, plSqlParams);

        // prepare return
        dataPage.put("totalElements", rowCount);
        dataPage.put("totalPages", rowCount/ps.getSize());
        dataPage.put("currentPage", ps.getPage());
        dataPage.put("pageSize", ps.getSize());
        dataPage.put("content", dataList);
        return dataPage;
    }


    public List<OrderRptBean> getAllOrderInfoForExcel( Map<String, String> filterParams ) {

        List<OrderRptBean> dataList = new ArrayList<>();

        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        // pagination first
        PaginatorService ps = new PaginatorService(filterParams);
        searchParams.add(ps.getOffset());   // P1
        searchParams.add(ps.getSize());     // P2
        // others filter params
        // initialize default
        searchParams.add(null);             // P3, order num
        searchParams.add(null);             // P4, cust name
        searchParams.add(null);             // P5, cust phone
        searchParams.add(null);             // P6, cust email
        searchParams.add(null);             // P7, order status
        searchParams.add(null);             // P8, from date
        searchParams.add(null);             // P9, to date
        searchParams.add(null);             // P10, customer type
        searchParams.add(null);             // P10, erp status
        // process and push params value
        searchParams.set(2, ( filterParams.containsKey("orderNum") && !filterParams.get("orderNum").isEmpty() ) ? Integer.parseInt(filterParams.get("orderNum"))  : null ); // P3, order num
        searchParams.set(3, (filterParams.get("customer") != null && !filterParams.get("customer").isEmpty()) ? filterParams.get("customer") : null );                      // P4, cust name
        searchParams.set(4, null );                                                                                                                                         // P5, cust phone
        searchParams.set(5, (filterParams.get("customerEmail") != null && !filterParams.get("customerEmail").isEmpty()) ? filterParams.get("customerEmail") : null  );      // P6, cust email
        searchParams.set(6, filterParams.getOrDefault("orderStatus", null) );                        // P7, order Status
        // for date range
        if( filterParams.containsKey("deliveryDate") && !filterParams.get("deliveryDate").isEmpty() ){
            searchParams.set(7, filterParams.get("deliveryDate"));                                                  // from date,   P8
            searchParams.set(8, filterParams.get("deliveryDate"));                                                  // from date,   P9
        }
        if( filterParams.containsKey("deliveryDateRange") && !filterParams.get("deliveryDateRange").isEmpty() ){
            String deliveryDateRange = filterParams.get("deliveryDateRange");
            searchParams.set(7, deliveryDateRange.split(" - ")[0]);                                           // from date,   P8
            searchParams.set(8, deliveryDateRange.split(" - ")[1]);                                           // from date,   P9
        }
        searchParams.set(9, filterParams.getOrDefault("customerType", null) );                       // P10, customer type
        searchParams.set(10, filterParams.getOrDefault("erpStatus", null) );                       // P10, customer type
        
        // procedures
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        StringBuilder plSQL = new StringBuilder("call p_cms_rpt_get_all_order_info_data_excel(?,?,?,?,?,?,?,?,?,?,?)");
        // execute

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    OrderRptBean orderRptBean = new OrderRptBean();
                    String orderNumber = resultSet.getString("order_number");
                    orderRptBean.setOrderNumber( orderNumber );
                    orderRptBean.setCustomerId(resultSet.getString("customer_id"));
                    orderRptBean.setCustomerFirstName(resultSet.getString("cust_first_name"));
                    orderRptBean.setCustomerLastName(resultSet.getString("cust_last_name"));
                    orderRptBean.setCustomerPhone(resultSet.getString("cust_phone"));
                    orderRptBean.setOrderPlaceTime(resultSet.getString("order_place_time"));
                    orderRptBean.setOrderStatus(resultSet.getString("order_status"));
                    orderRptBean.setProductCode(resultSet.getString("product_code") );
                    orderRptBean.setOrderDate(resultSet.getString("created_on") );
                    orderRptBean.setProductDescription(resultSet.getString("product_description"));
                    String quantity = resultSet.getString("quantity");
                    orderRptBean.setQuantity( (quantity != null) ?  Double.parseDouble(quantity) : 0.00 );
                    String saleAmt = resultSet.getString("sale_amount");
                    orderRptBean.setSaleAmount( (saleAmt != null) ? Double.parseDouble(saleAmt) : 0.00 );
                    orderRptBean.setDeliveryDate( resultSet.getString("delivery_date") );
                    orderRptBean.setDeliverySlots( resultSet.getString("delivery_slots") );
                    orderRptBean.setShippingAddress( resultSet.getString("delivering_address") );
                    orderRptBean.setCity( resultSet.getString("emirate") );
                    orderRptBean.setDeliverFee(resultSet.getDouble("shipping_amount"));
                    orderRptBean.setProcessingFee(resultSet.getDouble("processing_fee"));
                    orderRptBean.setPaymentMode( resultSet.getString("payment_mode") );
                    orderRptBean.setPaymentAmount( resultSet.getString("payment_amount") );
                    orderRptBean.setCustomerId( resultSet.getString("email") );
                    orderRptBean.setCustomerType( resultSet.getString("customer_type") );
                    orderRptBean.setErpStatus( resultSet.getString("erp_status") );
                    // push in list
                    dataList.add(orderRptBean);
                    processNextRow = resultSet.next();
                }
            }
        }, plSqlParams);
        return dataList;
    }


    public List<GenericModel> getOrderInfoSummaryRptDataByStatus() {
        StringBuilder plSQL = new StringBuilder("call p_cms_rpt_get_order_info_summary_data_bystatus()");
        List<GenericModel> dataList = jdbcTemplate.query(plSQL.toString(),
                (rs, rowNum) -> new GenericModel(
                        rs.getString("status"),
                        rs.getString("order_num"))
        );
        return dataList;
    }


}
