package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.promotion.PromoCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PromotionDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<PromoCode> getAllPromotions() {

        final List<PromoCode> promoCodeList = jdbcTemplate.query(
                "call p_cms_get_all_promo_details()",
                (rs, rowNum) -> new PromoCode(
                    rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getDouble("x3"),
                        rs.getString("x4"),
                        rs.getDate("x5"),
                        rs.getDate("x6"),
                        rs.getBoolean("x7"),
                        rs.getString("x8"),
                        rs.getBoolean("x11"),
                        rs.getBoolean("X12")
                ),
                new Object[] {}
        );

        return promoCodeList;
    }

    public boolean updatePromotion(PromoCode promoCode) {
        try{
            jdbcTemplate.update(
                    "call p_cms_update_promo_details_for_code(?,?,?,?,?,?,?,?,?,?)",
                    new Object[] {
                            promoCode.getId(),
                            promoCode.getCode(),
                            promoCode.getDiscount(),
                            promoCode.getDiscountType(),
                            promoCode.getValidFrom(),
                            promoCode.getValidTill(),
                            promoCode.isActive(),
                            promoCode.isAllowedForGuestUser(),
                            promoCode.isExcludeSaleTime(),
                            promoCode.getUsageLimit()
                    }
            );
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean addPromoCode(PromoCode promoCode){
        try{
            jdbcTemplate.update(
                    "call p_cms_add_promo_details_for_code(?,?,?,?,?,?,?,?,?)",
                    new Object[] {
                            promoCode.getCode(),
                            promoCode.getDiscount(),
                            promoCode.getDiscountType(),
                            promoCode.getValidFrom(),
                            promoCode.getValidTill(),
                            promoCode.isActive(),
                            promoCode.isAllowedForGuestUser(),
                            promoCode.isExcludeSaleTime(),
                            promoCode.getUsageLimit()
                    }
            );
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
}
