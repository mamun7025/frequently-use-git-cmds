package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.PushNotification;
import com.ekfc.foodcraft.services.PaginatorService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Component
public class PushNotificationDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public boolean saveData(Map<String, String> requestMap) {
        try{
            jdbcTemplate.update(
                    "call p_cms_insert_push_notification_data(?,?,?,?)",
                    new Object[] {
                            requestMap.get("title"),
                            requestMap.get("description"),
                            requestMap.get("redirectUrl"),
                            requestMap.get("thumbImage")
                    }
            );
            return true;
        } catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to add the PushNotification data");
            return false;
        }
    }

    public List<PushNotification> getData(Map<String, String> requestMap) {

        StringBuilder plSQL = new StringBuilder("call p_cms_get_push_notification_data()");
        List<PushNotification> dataList = jdbcTemplate.query(plSQL.toString(),
                (rs, rowNum) -> new PushNotification(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("redirect_url"),
                        rs.getString("thumb_image")
                )
        );
        return dataList;

    }


    public Map<String, Object> getDataPaginated( Map<String, String> filterParams ) {

        Map<String, Object> dataPage = new LinkedHashMap<>();
        List<PushNotification> dataList = new ArrayList<>();

        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        // pagination first
        PaginatorService ps = new PaginatorService(filterParams);
        searchParams.add(ps.getOffset());   // P1
        searchParams.add(ps.getSize());     // P2
        // others filter params
        // initialize default
        searchParams.add(null);             // P3, title
        // process and push params value
        String filterKey = filterParams.getOrDefault("filterKey", null);
        String searchValue = filterParams.getOrDefault("searchValue", null);
        searchValue = (searchValue != null && searchValue.isEmpty()) ? null: searchValue;
        // add order number
        searchParams.set(2, (filterKey != null && searchValue != null && filterKey.equals("byTitle")) ? searchValue : null );

        // procedures
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        StringBuilder plSQL = new StringBuilder("call p_cms_get_push_notification_data_pages(?,?,?)");
        StringBuilder plSQLForCount = new StringBuilder("call p_cms_get_push_notification_data_pages_count(?,?,?)");
        // execute
        Integer rowCount = this.jdbcTemplate.queryForObject(plSQLForCount.toString(), Integer.class, plSqlParams);

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    PushNotification dataBean = new PushNotification();
                    dataBean.setNotificationId(resultSet.getInt("id"));
                    dataBean.setTitle(resultSet.getString("title"));
                    dataBean.setDescription(resultSet.getString("description"));
                    dataBean.setRedirectUrl(resultSet.getString("redirect_url"));
                    dataBean.setCreationDateTime(resultSet.getTimestamp("creation_datetime").toString());
                    // push in list
                    dataList.add(dataBean);
                    processNextRow = resultSet.next();
                }
            }
        }, plSqlParams);

        // prepare return
        dataPage.put("totalElements", rowCount);
        dataPage.put("totalPages", rowCount/ps.getSize());
        dataPage.put("currentPage", ps.getPage());
        dataPage.put("pageSize", ps.getSize());
        dataPage.put("content", dataList);
        return dataPage;
    }


}
