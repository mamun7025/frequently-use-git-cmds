package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.Category;
import com.ekfc.foodcraft.model.Product;
import com.google.common.collect.ComparisonChain;
import com.google.common.collect.Ordering;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Component
public class CategoryDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;


    public List<Category> getAllCategories(){
        try{
            List<Category> categories = jdbcTemplate.query(
                    "call p_cms_get_all_categories_with_relation()",
                    (rs, rowNum) -> new Category(
                            rs.getString("x1"),
                            rs.getString("x2"),
                            rs.getBoolean("x3"),
                            rs.getString("x4"),
                            rs.getBoolean("x5"),
                            rs.getBoolean("x6"),
                            rs.getString("x7"),
                            rs.getString("x8"),
                            rs.getString("x9"),
                            rs.getInt("x10")
                    ),
                    new Object[] {}
            );
            
          Comparator categoryComparator = new Comparator<Category>() {
                public int compare(Category o1, Category o2) {
                    try{
						 return Integer.compare(o1.getOrderNumber(), o2.getOrderNumber());
                            
                    }catch (Exception ex){
                        ex.printStackTrace();
                        return -1;
                    }
                }
            };
            Collections.sort(categories, categoryComparator);
            
            return !CollectionUtils.isEmpty(categories) ? categories : new ArrayList<>();
        }catch(Exception ex){
            ex.printStackTrace();
            System.out.println("Unable to get the Categories");
        }
        return new ArrayList<>();
    }

    public List<Category> getAllEnabledCategories(){
        try{
            List<Category> categories = jdbcTemplate.query(
                    "call p_cms_get_all_enabled_categories()",
                    (rs, rowNum) -> new Category(
                            rs.getString("x1"),
                            rs.getString("x2"),
                            rs.getBoolean("x3"),
                            rs.getString("x4"),
                            rs.getBoolean("x5"),
                            rs.getBoolean("x6"),
                            rs.getString("x7"),
                            rs.getString("x8"),
                            rs.getString("x9"),
                            rs.getInt("x10")
                    ),
                    new Object[] {}
            );
            return !CollectionUtils.isEmpty(categories) ? categories : new ArrayList<>();
        }catch(Exception ex){
            ex.printStackTrace();
            System.out.println("Unable to get the Categories");
        }
        return new ArrayList<>();
    }

    public Category getCategoryForId(String categoryId){
        try{
            List<Category> categories = jdbcTemplate.query(
                    "call p_cms_get_category_for_category_id(?)",
                    (rs, rowNum) -> new Category(
                            rs.getString("x1"),
                            rs.getString("x2"),
                            rs.getBoolean("x3"),
                            rs.getString("x4"),
                            rs.getBoolean("x5"),
                            rs.getBoolean("x6"),
                            rs.getString("x7"),
                            rs.getString("x8"),
                            rs.getString("x9"),
                            rs.getInt("x10")
                    ),
                    new Object[] {categoryId}
            );
            return !CollectionUtils.isEmpty(categories) ? categories.get(0) : null;
        }catch(Exception ex){
            ex.printStackTrace();
            System.out.println("Unable to get the Category for the Category ID");
        }
        return null;
    }

    public boolean updateCategory(Category category){
        try{
            jdbcTemplate.update(
                    "call p_cms_update_existing_category(?,?,?,?,?,?,?,?,?)",
                    new Object[] {category.getCategoryId(), category.getCategoryName(), category.isEnabled(), category.getParent(),
                    		category.getLongDesc(), category.getShortDesc(), category.getImage(), category.isHeader(), category.isFilter()}
            );
            return true;
        }catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to upadte the category");
        }
        return false;
    }

    public boolean addCategory(Category category){
        try{
            jdbcTemplate.update(
                    "call p_cms_insert_new_category(?,?,?,?,?,?,?,?,?)",
                    new Object[] {category.getCategoryId(), category.getCategoryName(), category.isEnabled(), category.getParent(),
                    		category.getLongDesc(), category.getShortDesc(), category.getImage(), category.isHeader(), category.isFilter()}
            );
            return true;
        }catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to add the category");
        }
        return false;
    }

    public boolean updateCategoryStatus(String categoryId, boolean status){
        try{
            jdbcTemplate.update(
                    "call p_cms_update_category_status(?,?)",
                    new Object[] {categoryId, status}
            );
            return true;
        }catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to update the category status for the Category");
        }
        return false;
    }

    public List<Category> getSubCategoriesForCategory(String categoryId){
        List<Category> subCategories = jdbcTemplate.query(
                "call p_cms_get_all_sub_categories_for_category(?)",
                (rs, rowNum) -> new Category(
                        rs.getString("x1"),
                        rs.getString("x2"),
                        rs.getBoolean("x3"),
                        rs.getString("x4"), rs.getBoolean("x5"), rs.getBoolean("x6"),
                        rs.getString("x7"),
                        rs.getString("x8"),
                        rs.getString("x9"),
                        rs.getInt("x10")
                ),
                new Object[] {categoryId}
        );

        return subCategories;
    }

    public List<Category> getRootCategories(){
        List<Category> subCategories = jdbcTemplate.query(
                "call p_cms_get_all_root_categories()",
                (rs, rowNum) -> new Category(
                        rs.getString("x1"),
                        rs.getString("x2"),
                        rs.getBoolean("x3"),
                        rs.getString("x4"), rs.getBoolean("x5"), rs.getBoolean("x6"),
                        rs.getString("x7"),
                        rs.getString("x8"),
                        rs.getString("x9"),
                        rs.getInt("x10")
                ),
                new Object[] {}
        );

        return subCategories;
    }

    public List<Category> searchCategories(String categoryId) {
        List<Category> subCategories = jdbcTemplate.query(
                "call p_cms_get_all_categories_for_keyword(?)",
                (rs, rowNum) -> new Category(
                        rs.getString("x1"),
                        rs.getString("x2"),
                        rs.getBoolean("x3"),
                        rs.getString("x4"), rs.getBoolean("x5"), rs.getBoolean("x6"),
                        rs.getString("x7"),
                        rs.getString("x8"),
                        rs.getString("x9"),
                        rs.getInt("x10")
                ),
                new Object[] {categoryId}
        );

        return subCategories;
    }
    
    public boolean updateOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_category_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteCatgeory(String categoryCode) {
        try {
            jdbcTemplate.update(
                    "call p_cms_remove_category(?)",
                    new Object[]{categoryCode}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
}
