package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.Wallet;
import com.ekfc.foodcraft.services.PaginatorService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Component
public class WalletDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;
    public String errorDetails;

    public boolean create(Map<String, String> requestMap) {
        requestMap.put("creationUser", "system");
        try {
            jdbcTemplate.update(
                    "call p_cms_insert_wallet_data(?,?,?)",
                    new Object[] {
                            requestMap.get("walletEmail"),
                            requestMap.get("balance"),
                            requestMap.get("creationUser")
                    }
            );
            return true;
        } catch (DuplicateKeyException ex){
            this.errorDetails = ex.getMessage().split("SQLIntegrityConstraintViolationException:")[1];
            return false;
        }catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to add the wallet data");
            return false;
        }
    }

    public Wallet read(Map<String, String> requestMap) {

        List<Wallet> dataList = new ArrayList<>();
        StringBuilder plSQL = new StringBuilder("call p_cms_get_wallet_data_by_id(?)");
        Object[] plSqlParams = new Object[] {requestMap.get("walletId")};

        try {
        	
        	jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
                public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                	boolean processNextRow = true;
                    while (processNextRow) {
                        // process it
                        Wallet dataBean = new Wallet();
                        dataBean.setWalletId(resultSet.getInt("wallet_id"));
                        dataBean.setWalletEmail(resultSet.getString("wallet_email"));
                        dataBean.setBalance(resultSet.getDouble("balance"));
                        dataBean.setCreationUser(resultSet.getString("creation_user"));
                        Timestamp ct = resultSet.getTimestamp("creation_datetime");
                        String ctx = (ct == null) ? "" : ct.toString();
                        dataBean.setCreationDateTime(ctx);
                        dataBean.setLastUpdateUser(resultSet.getString("last_update_user"));
                        Timestamp lut = resultSet.getTimestamp("last_update_datetime");
                        String lutx = (lut == null) ? "" : lut.toString();
                        dataBean.setLastUpdateDateTime(lutx);
                        // push in list
                        dataList.add(dataBean);
                        processNextRow = resultSet.next();
                    }
                }
            }, plSqlParams);
        	
            /*jdbcTemplate.query(plSQL.toString(), resultSet -> {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    Wallet dataBean = new Wallet();
                    dataBean.setWalletId(resultSet.getInt("wallet_id"));
                    dataBean.setWalletEmail(resultSet.getString("wallet_email"));
                    dataBean.setBalance(resultSet.getDouble("balance"));
                    dataBean.setCreationUser(resultSet.getString("creation_user"));
                    Timestamp ct = resultSet.getTimestamp("creation_datetime");
                    String ctx = (ct == null) ? "" : ct.toString();
                    dataBean.setCreationDateTime(ctx);
                    dataBean.setLastUpdateUser(resultSet.getString("last_update_user"));
                    Timestamp lut = resultSet.getTimestamp("last_update_datetime");
                    String lutx = (lut == null) ? "" : lut.toString();
                    dataBean.setLastUpdateDateTime(lutx);
                    // push in list
                    dataList.add(dataBean);
                    processNextRow = resultSet.next();
                }
            }, plSqlParams);*/
        } catch (Exception ex){
            ex.printStackTrace();
            System.out.println("Unable to get the object by ID");
        }
        if(dataList.isEmpty()) return null;
        return dataList.get(0);
    }

    public boolean update(Map<String, String> requestMap) {

        requestMap.put("updateUser", "system");
        try{
            jdbcTemplate.update(
                    "call p_cms_update_wallet_data(?,?,?,?)",
                    new Object[] {
                            requestMap.get("walletId"),
                            requestMap.get("walletEmail"),
                            requestMap.get("balance"),
                            requestMap.get("updateUser")
                    }
            );
            return true;
        } catch(Exception ex) {
            ex.printStackTrace();
            System.out.println("Unable to add the wallet data");
            return false;
        }

    }

    public Map<String, Object> getPaginatedData(Map<String, String> filterParams) {
        Map<String, Object> dataPage = new LinkedHashMap<>();
        List<Wallet> dataList = new ArrayList<>();

        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        // pagination first
        PaginatorService ps = new PaginatorService(filterParams);
        searchParams.add(ps.getOffset());   // P1
        searchParams.add(ps.getSize());     // P2
        // others filter params
        // initialize default
        searchParams.add(null);             // P3, title
        // process and push params value
        String filterKey = filterParams.getOrDefault("filterKey", null);
        String searchValue = filterParams.getOrDefault("searchValue", null);
        searchValue = (searchValue != null && searchValue.isEmpty()) ? null: searchValue;
        // add order number
        searchParams.set(2, (filterKey != null && searchValue != null && filterKey.equals("byEmail")) ? searchValue : null );

        // procedures
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        StringBuilder plSQL = new StringBuilder("call p_cms_get_wallet_data_pages(?,?,?)");
        StringBuilder plSQLForCount = new StringBuilder("call p_cms_get_wallet_data_pages_count(?,?,?)");
        // execute
        Integer rowCount = this.jdbcTemplate.queryForObject(plSQLForCount.toString(), Integer.class, plSqlParams);

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    Wallet dataBean = new Wallet();
                    dataBean.setWalletId(resultSet.getInt("wallet_id"));
                    dataBean.setWalletEmail(resultSet.getString("wallet_email"));
                    dataBean.setBalance(resultSet.getDouble("balance"));

                    String ctUser = resultSet.getString("creation_user");
                    dataBean.setCreationUser((ctUser == null) ? "" : ctUser);
                    Timestamp ct = resultSet.getTimestamp("creation_datetime");
                    String ctx = (ct == null) ? "" : ct.toString();
                    dataBean.setCreationDateTime(ctx);

                    String ltUser = resultSet.getString("last_update_user");
                    dataBean.setLastUpdateUser((ltUser == null) ? "" : ltUser);
                    Timestamp lut = resultSet.getTimestamp("last_update_datetime");
                    String lutx = (lut == null) ? "" : lut.toString();
                    dataBean.setLastUpdateDateTime(lutx);
                    // push in list
                    dataList.add(dataBean);
                    processNextRow = resultSet.next();
                }
            }
        }, plSqlParams);

        // prepare return
        dataPage.put("totalElements", rowCount);
        dataPage.put("totalPages", rowCount/ps.getSize());
        dataPage.put("currentPage", ps.getPage());
        dataPage.put("pageSize", ps.getSize());
        dataPage.put("content", dataList);
        return dataPage;
    }


    public List<LinkedHashMap<String, Object>> getActivityLogData(Map<String, String> requestMap) {
        List<LinkedHashMap<String, Object>> dataList = new ArrayList<>();
        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        // procedures
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        StringBuilder plSQL = new StringBuilder("call p_cms_get_wallet_log_data()");

        jdbcTemplate.query(plSQL.toString(), new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet resultSet) throws SQLException {
                boolean processNextRow = true;
                while (processNextRow) {
                    // process it
                    LinkedHashMap<String, Object> dataBean = new LinkedHashMap<>();

                    dataBean.put("log_id", resultSet.getInt("log_id"));
                    dataBean.put("log_timestamp", resultSet.getTimestamp("log_timestamp"));
                    dataBean.put("log_operation", resultSet.getString("log_operation"));
                    dataBean.put("log_user", resultSet.getString("log_user"));

                    dataBean.put("wallet_id", resultSet.getInt("wallet_id"));
                    dataBean.put("wallet_email", resultSet.getString("wallet_email"));
                    dataBean.put("balance", resultSet.getDouble("balance"));

                    String ctUser = resultSet.getString("creation_user");
                    dataBean.put("creation_user", (ctUser == null) ? "" : ctUser);
                    Timestamp ct = resultSet.getTimestamp("creation_datetime");
                    String ctx = (ct == null) ? "" : ct.toString();
                    dataBean.put("creation_datetime", ctx);

                    String ltUser = resultSet.getString("last_update_user");
                    dataBean.put("last_update_user", (ltUser == null) ? "" : ltUser);
                    Timestamp lut = resultSet.getTimestamp("last_update_datetime");
                    String lutx = (lut == null) ? "" : lut.toString();
                    dataBean.put("last_update_datetime", lutx);
                    // push in list
                    dataList.add(dataBean);
                    processNextRow = resultSet.next();
                }
            }
        });

        return dataList;
    }


}
