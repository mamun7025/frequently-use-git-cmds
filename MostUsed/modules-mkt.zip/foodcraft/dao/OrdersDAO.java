package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.CustomerDetails;
import com.ekfc.foodcraft.model.OrdersDetails;
import com.ekfc.foodcraft.model.OrdersHeader;
import com.ekfc.foodcraft.services.LoyaltyService;
import com.ekfc.foodcraft.templates.EmailTemplate;
import com.ekfc.foodcraft.utils.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class OrdersDAO {

	private static final Logger logger = LoggerFactory.getLogger(OrdersDAO.class);

	public final String ORDER_CANCELLED = "Cancelled";
	public final String ORDER_COMPLETION = "Completed";
	public final String ORDER_DELIVERED = "Delivered";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private Environment env;

	@Autowired
	private LoyaltyService loyaltyService;

	@Autowired
	private LoyaltyConfigDAO loyaltyConfigDAO;

	public Map<String, Object> getOrderDetails(Map<String, Object> reqMap) {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		String orderNumber= reqMap.get("orderNumber").toString();
		StringBuilder builder = new StringBuilder("call p_get_order_hdr_cms(?)");

		List<OrdersHeader> ordersHeader = this.jdbcTemplate.query(builder.toString(),
				(rs, rowNum) -> new OrdersHeader(String.valueOf(rs.getLong("id")),
						rs.getString("user_id"),
						rs.getString("created_on"),
						rs.getString("created_by"),
						rs.getString("status"),
						rs.getDouble("vat_amount"),
						rs.getDouble("shipping_amount"),
						rs.getDouble("total_amount"),
						rs.getDouble("payment_amount"),
						rs.getString("invoice"),rs.getString("status")), orderNumber);

		if (ordersHeader.isEmpty()) {
			resultMap.put("Error", "No records found");
		} else {
			resultMap.put("headerDetails", (ordersHeader.size() > 0) ? ordersHeader.get(0) : new HashMap<>());

			List<OrdersDetails> ordersDetails = this.jdbcTemplate.query(
					"call p_get_order_details_cms(?)",
					(rs, rowNum) -> new OrdersDetails(rs.getString("description"),
							rs.getString("category"), rs.getString("packaging"),
							rs.getString("uom"), rs.getString("brand"),
							rs.getString("origin"), rs.getInt("quantity"),
							rs.getString("pricingUom"), rs.getDouble("salesprice"),
							rs.getDouble("baseprice"), rs.getString("p_code"),
							rs.getInt("id"), rs.getString("status")),
					new Object[] { ordersHeader.get(0).getOrderNumber() });


			List<CustomerDetails> custDetails = new ArrayList<>();
			try {
				custDetails =  this.jdbcTemplate.query(
						"call p_get_customer_details_cms(?)",
						(rs, rowNum) -> {
							try {
								return new CustomerDetails(rs.getString("username"),
										rs.getString("billing_address"), rs.getString("delivering_address"),
										rs.getString("delivery_date"),
										rs.getString("phone"));
							} catch (Exception e) {
								throw new RuntimeException(e);
							}
						},
						new Object[] { ordersHeader.get(0).getOrderNumber() });
			} catch (Exception ex){
				ex.printStackTrace();
			}

			resultMap.put("orderDetails", ordersDetails);
			resultMap.put("customerDetails", (custDetails.size() > 0) ? custDetails.get(0) : new HashMap<>());
		}
		return resultMap;
	}


	public Map<String, Object> getOrderHistory(Map<String, Object> reqMap) {
		Map<String, Object> resultMap = new HashMap<String, Object>();

			StringBuilder builder = new StringBuilder(
					"call p_get_all_orders_cms()");
			
			List<OrdersHeader> ordersHeader = this.jdbcTemplate.query(builder.toString(),
					(rs, rowNum) -> new OrdersHeader(rs.getString("id"), rs.getString("user_id"),
							rs.getString("created_on"), rs.getString("created_by"), "closed",
							rs.getDouble("vat_amount"), rs.getDouble("shipping_amount"), rs.getDouble("total_amount"),
							rs.getDouble("payment_amount"), rs.getString("invoice")));
			if (ordersHeader.isEmpty()) {
				resultMap.put("Error", "No records found");
			} else {
				resultMap.put("headerDetails", ordersHeader);
			}

		return resultMap;
	}
	
	
	public Map<String, Object> getDailyOrderReport(Map<String, Object> reqMap) {
		Map<String, Object> resultMap = new HashMap<String, Object>();

			StringBuilder builder = new StringBuilder(
					"call p_get_daily_orders_cms(?)");
			
			List<OrdersHeader> ordersHeader = this.jdbcTemplate.query(builder.toString(),
					(rs, rowNum) -> new OrdersHeader(rs.getString("id"), rs.getString("user_id"),
							rs.getString("created_on"), rs.getString("created_by"), "closed",
							rs.getDouble("vat_amount"), rs.getDouble("shipping_amount"), rs.getDouble("total_amount"),
							rs.getDouble("payment_amount"), rs.getString("invoice")), new Object[] {reqMap.get("deliveryDate")});
			if (ordersHeader.isEmpty()) {
				resultMap.put("Error", "No records found");
			} else {
				resultMap.put("headerDetails", ordersHeader);
			}

		return resultMap;
	}
	
	public Map<String, Object> updateOrderStatusList(Map<String, Object> reqMap){
		final List<Map<String, Object>> data = (List<Map<String, Object>>) reqMap.get("orderList");
		final String status = (String) reqMap.get("status");
		for(Map<String, Object> orderList : data) {
			System.out.println(orderList.get("orderNumber"));
			this.updateOrderStatus((String)orderList.get("orderNumber"),(String)orderList.get("custEmail"),status);
		}
			
		return reqMap;
		
	}
	
	public Map<String, Object> updateOrderStatus(String orderNumber, String customerEmail, String status) {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		try {
/*		String orderNumber = reqMap.get("orderNumber").toString();
		String status = reqMap.get("status").toString();
		String customerEmail=reqMap.get("custEmail").toString();
		*/
			StringBuilder builder = new StringBuilder(
					"call p_update_order_status_for_id_cms(?,?)");
			this.jdbcTemplate.update(builder.toString(),
				orderNumber,status);
			List<OrdersHeader> orderHeader = this.jdbcTemplate.query("call p_get_odr_hdr_for_id_cms(?)",
					(rs, rownum) -> new OrdersHeader(rs.getString("payment_mode"), rs.getDouble("vat_amount"),
							rs.getDouble("shipping_amount"), rs.getDouble("total_amount"),
							rs.getDouble("payment_amount"), rs.getDouble("discount_amount"), rs.getString("created_on"),
							rs.getString("invoice"),rs.getDouble("loyalty_amount"),rs.getString("loyalty_calculated")),
					new Object[] { orderNumber });
			orderHeader.get(0).setOrderNumber(orderNumber);
			if (status.equalsIgnoreCase(ORDER_COMPLETION) && orderHeader.get(0).getLoyaltyCalculated() == null) {// Calculate earn points if order is completed and loyalty is not already calculated for this order
				// calculate earn points
				var earnConfig = loyaltyConfigDAO.getLoyaltyDetailsByType("EARN").get(0);
				var burnConfig = loyaltyConfigDAO.getLoyaltyDetailsByType("BURN").get(0);
				var userLoyaltyData = loyaltyService.getUserLoyaltyPoints(customerEmail);
				if (earnConfig.getActive()) { // apply points if loyalty is active
					double earnPoints = (orderHeader.get(0).getPaymentAmmount() * earnConfig.getPoints()) / burnConfig.getPoints() ;
					if (userLoyaltyData == null || userLoyaltyData.isEmpty()) { // create new points
						this.jdbcTemplate.update("call p_cms_add_earn_points(?,?)", customerEmail, earnPoints);
					} else {// update existing points

						//earnPoints = orderHeader.get(0).getLoyaltyAmount() > 0 ? userLoyaltyData.get(0).getPoints() + orderHeader.get(0).getLoyaltyAmount() + earnPoints : earnPoints;
						this.jdbcTemplate.update("call p_cms_update_earn_points(?,?)", customerEmail, earnPoints);
					}
					this.jdbcTemplate.update("call p_cms_mark_loyalty_calculated(?)", orderNumber);
				}
			}

			List<OrdersDetails> orderDetails = this.jdbcTemplate.query("call p_get_odr_dtls_for_id_cms(?)",
					(rs, rownum) -> new OrdersDetails(rs.getString("description").toString(),
							rs.getInt("quantity"), rs.getDouble("salesprice")),
					new Object [] {orderNumber});
				
			
			List<CustomerDetails> custDetails = this.jdbcTemplate.query("call p_get_cust_dtls_for_id_cms(?)",
					(rs, rownum) -> new CustomerDetails(rs.getString("first_name").toString(), rs.getString("last_name").toString(), rs.getString("email").toString()),
					new Object [] {orderNumber});	
			EmailTemplate et = new EmailTemplate();
			Map<String, Object> orderMap = new HashMap<String, Object>();
			orderMap.put("orderDetails", orderDetails);
			orderMap.put("orderHeader", orderHeader);
			orderMap.put("custDetails", custDetails);
			orderMap.put("logo", et.logo);
			if(status.equalsIgnoreCase(ORDER_CANCELLED)) {

			resultMap.put("result", "Update successfully");
				Runnable myRunnable1 = new Runnable() {
					public void run() {
						try {
							ERPUtil.sendCancelOrderEmail(orderMap,env.getProperty("send.new.user.email.dl"), "Order #"+orderNumber+" has been cancelled",
									env.getProperty("epost.domain.url"), orderNumber,env.getProperty("basic.auth.email.header"),
									env.getProperty("send.email.endpoint"));
							ERPUtil.sendRefundOrderEmail(orderMap,custDetails.get(0).getEmail(), "Order Refunded: #"+orderNumber,
									env.getProperty("epost.domain.url"), orderNumber,env.getProperty("basic.auth.email.header"),
									env.getProperty("send.email.endpoint"));
						}
						catch(Exception e) {
							e.printStackTrace();
						}
					}
				};
				Thread thread = new Thread(myRunnable1);
				thread.start();
			}
			else if(status.equalsIgnoreCase(ORDER_COMPLETION)) {
				orderMap.put("invDocB64String", "");
				if (!orderHeader.isEmpty()){
					orderMap.put("invDocB64String", orderHeader.get(0).getInvoice());
				}
				Runnable myRunnable1 = new Runnable() {
					public void run() {
						try {
							ERPUtil.sendOrderDeliveredEmail(
									orderMap,
//									env.getProperty("send.new.user.email.dl"),
									custDetails.get(0).getEmail(),
									"Thank you for shopping with us!",
									env.getProperty("epost.domain.url"),
									orderNumber,
									env.getProperty("basic.auth.email.header"),
									env.getProperty("send.email.endpoint")
							);
							/*
							 * ERPUtil.sendOrderCompletionEmail(orderMap,env.getProperty(
							 * "send.new.user.email.dl"), "Thank you for shopping with us!",
							 * env.getProperty("epost.domain.url"),
							 * orderNumber,env.getProperty("basic.auth.email.header"),
							 * env.getProperty("send.email.endpoint"));
							 */
						}
						catch(Exception e) {
							e.printStackTrace();
						}
					}
				};
				Thread thread = new Thread(myRunnable1);
				thread.start();
			}
			else if(status.equalsIgnoreCase(ORDER_DELIVERED)) {
				orderMap.put("invDocB64String", "");
				if (!orderHeader.isEmpty()){
					orderMap.put("invDocB64String", orderHeader.get(0).getInvoice());
				}

				Runnable myRunnable1 = new Runnable() {
					public void run() {
						try {
							ERPUtil.sendOrderDeliveredEmail(
									orderMap,
									env.getProperty("send.new.user.email.dl"),
									"Thank you for shopping with us!",
									env.getProperty("epost.domain.url"),
									orderNumber,
									env.getProperty("basic.auth.email.header"),
									env.getProperty("send.email.endpoint")
							);
						}
						catch(Exception e) {
							e.printStackTrace();
						}
					}
				};
				Thread thread = new Thread(myRunnable1);
				thread.start();
			}
		}
		catch(Exception e) {
			resultMap.put("error", "There was an error in your request");
			e.printStackTrace();
		}
		return resultMap;
	}

	
	public boolean updateProductStatusList(Map<String, Object> reqMap){
		final List<Map<String, Object>> data = (List<Map<String, Object>>) reqMap.get("orderDetails");
		final String orderNumber = (String) reqMap.get("orderNumber");
		try {
		for(Map<String, Object> orderList : data) {
			String status = (String)orderList.get("status");
			String pCode = (String)orderList.get("code");
			this.updateProductStatus(orderNumber, pCode, status);
		}
		return true;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return false;
			
		
	}
	
	public boolean updateProductStatus(String orderNumber, String pCode, String status) {
		try {
			StringBuilder builder = new StringBuilder(
					"call p_update_product_status_for_id_cms(?,?,?)");
			this.jdbcTemplate.update(builder.toString(),
				orderNumber,pCode, status);
			return true;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private static byte[] loadFile(File file) throws Exception {
		InputStream is = new FileInputStream(file);
		long length = file.length();
		if (length > Integer.MAX_VALUE) {
			throw new RuntimeException("File size is too large");
		}
		byte[] bytes = new byte[(int) length];
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}
		if (offset < bytes.length) {
			throw new IOException(" >> loadFile >> Could not completely read file");
		}
		is.close();
		is = null;
		return bytes;
	}

	public List<OrdersDetails> getOrderDetailsForOrderNumber(String orderNumber) {
		return this.jdbcTemplate.query(
				"call p_get_order_for_id_cms(?)",
				(rs, rowNum) -> new OrdersDetails(rs.getString("description"), rs.getString("category"),
						rs.getString("packaging"), rs.getString("uom"), rs.getString("brand"), rs.getString("origin"),
						rs.getInt("quantity"), rs.getString("pricingUom"), rs.getDouble("salesprice"),
						rs.getDouble("baseprice"), rs.getString("p_code"), rs.getInt("id")),
				new Object[] { orderNumber });
	}

	public List<OrdersHeader> getAmountForOrderDetails(String orderNumber) {
		return this.jdbcTemplate.query(
				"call p_get_amount_for_id_cms(?,?)",
				(rs, rowNum) -> new OrdersHeader(String.valueOf(rs.getLong("id")), rs.getDouble("vat_amount"),
						rs.getDouble("shipping_amount"), rs.getDouble("total_amount"), rs.getDouble("payment_amount"),
						rs.getDouble("discount_amount"), rs.getString("created_on")),
				new Object[] { orderNumber, "closed" });
	}

	
	private String changeDateFormat(String date) {
		SimpleDateFormat sfHypen = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat sfSlash = new SimpleDateFormat("dd/MM/YYYY");

		try {
			return sfSlash.format(sfHypen.parse(date));
		} catch (Exception ex) {
			return date;
		}
	}

	private double returnTwoDeciamlPlacesForDouble(double value) {
		return Double.valueOf(String.format("%.2f", value));
	}


	public OrdersHeader getOrderHeaderInfo(Map<String, Object> reqMap){

		String orderNumber= reqMap.get("orderNumber").toString();
		StringBuilder builder = new StringBuilder("call p_get_order_hdr_cms(?)");

		List<OrdersHeader> ordersHeader = this.jdbcTemplate.query(builder.toString(),
				(rs, rowNum) -> new OrdersHeader(String.valueOf(rs.getLong("id")),
						rs.getString("user_id"),
						rs.getString("created_on"),
						rs.getString("created_by"),
						rs.getString("status"),
						rs.getDouble("vat_amount"),
						rs.getDouble("shipping_amount"),
						rs.getDouble("total_amount"),
						rs.getDouble("payment_amount"),
						rs.getString("invoice")), orderNumber);

		if (ordersHeader.isEmpty()) return new OrdersHeader();
		return ordersHeader.get(0);
	}
	
	
	public Map<String, Object> getOrderDetailsForERPRequest(Map<String, Object> reqMap) {

		Map<String, Object> resultMap = new HashMap<String, Object>();

		String orderNumber= reqMap.get("orderNumber").toString();
		StringBuilder builder = new StringBuilder("call p_get_order_hdr_cms(?)");

		List<OrdersHeader> ordersHeader = this.jdbcTemplate.query(builder.toString(),
				(rs, rowNum) -> new OrdersHeader(String.valueOf(rs.getLong("id")),
						rs.getString("user_id"),
						rs.getString("created_on"),
						rs.getString("created_by"),
						rs.getString("status"),
						rs.getDouble("vat_amount"),
						rs.getDouble("shipping_amount"),
						rs.getDouble("total_amount"),
						rs.getDouble("payment_amount"),
						rs.getString("invoice")), orderNumber);

		if (ordersHeader.isEmpty()) {
			resultMap.put("Error", "No records found");
		} else {
			resultMap.put("headerDetails", (ordersHeader.size() > 0) ? ordersHeader.get(0) : new HashMap<>());

			List<OrdersDetails> ordersDetails = this.jdbcTemplate.query(
					"call p_get_order_details_cms(?)",
					(rs, rowNum) -> new OrdersDetails(rs.getString("description"),
							rs.getString("category"), rs.getString("packaging"),
							rs.getString("uom"), rs.getString("brand"),
							rs.getString("origin"), rs.getInt("quantity"),
							rs.getString("pricingUom"), rs.getDouble("salesprice"),
							rs.getDouble("baseprice"), rs.getString("p_code"),
							rs.getInt("id")),
					new Object[] { ordersHeader.get(0).getOrderNumber() });
			
			List<Integer> invoiceId = this.jdbcTemplate.query(
					"call p_get_invoice_id_cms(?)",
					(rs, rowNum) -> new Integer(rs.getInt("id")),
					new Object[] { ordersHeader.get(0).getOrderNumber() });
			
			ordersHeader.get(0).setInvoiceId(invoiceId.get(0));


			List<CustomerDetails> custDetails = new ArrayList<>();
			try {
				custDetails =  this.jdbcTemplate.query(
						"call p_get_customer_details_cms(?)",
						(rs, rowNum) -> {
							try {
								return new CustomerDetails(rs.getString("username"),
										rs.getString("billing_address"), rs.getString("delivering_address"),
										rs.getString("delivery_date"),rs.getString("phone"),
										rs.getString("first_name"),rs.getString("last_name"),
										rs.getString("delivery_slots"), rs.getString("trn_number"));
							} catch (Exception e) {
								throw new RuntimeException(e);
							}
						},
						new Object[] { ordersHeader.get(0).getOrderNumber() });
			} catch (Exception ex){
				ex.printStackTrace();
			}

			resultMap.put("orderDetails", ordersDetails);
			resultMap.put("orderHeader", ordersHeader);
			resultMap.put("customerDetails", (custDetails.size() > 0) ? custDetails.get(0) : new HashMap<>());
		}
		return resultMap;
	}
	
	public Map<String, Object> triggerERPRequest(Map<String, Object> reqMap){
		// Generate ERP string
		final String erpString = this.createERPRequest(reqMap);
		int id = this.addERPRequest(erpString);
		System.out.println("Constructing JSON String ::: " + erpString);
		try {
			String erpUrl=env.getProperty("erp.api.url");
			String erpTkn=env.getProperty("erp.api.tken");
			String stackHolderList = env.getProperty("send.erp.stakeholders.list");
			String domainName = env.getProperty("epost.domain.url");
			String emailURI = env.getProperty("send.email.endpoint");
			String authHeader = env.getProperty("basic.auth.email.header");
			final boolean isERPRequestSent = ERPUtil.callERPAPI(erpUrl, erpTkn, erpString, id,stackHolderList, domainName, emailURI, authHeader);
			String responsePayload = (isERPRequestSent ? "Success" : "Failed");
			List<OrdersHeader> orderHeaderData = (List<OrdersHeader>) reqMap.get("orderHeader");
			updateERPResponse(id, responsePayload,orderHeaderData.get(0).getId());
			erpUrl=null;
			erpTkn=null;
			System.out.println("ERP Request Sent ::: " + isERPRequestSent);
		} catch (Exception erpEx) {
			erpEx.printStackTrace();
		}

		return null;
	}
	
	private String createERPRequest(Map<String, Object> reqMap) {
		StringBuilder sb = new StringBuilder();
		List<OrdersHeader> orderHeaderData = (List<OrdersHeader>) reqMap.get("orderHeader");
		CustomerDetails custDetails = (CustomerDetails) reqMap.get("customerDetails");
		//CustomerDetails custDetails = customerDetailsData.get(0);
		OrdersHeader orderHdr = orderHeaderData.get(0);
		List<OrdersDetails> orderDetailsData = (List<OrdersDetails>) reqMap.get("orderDetails");
		sb.append("{").append("\"GridData\"").append(":").append("[");
		double processingFee = orderHdr.getProcessingFee();
		double shippingAmount = orderHdr.getShippingAmount();
		double discountAmount = orderHdr.getDiscountAmmount();
		String createdOn = orderHdr.getCreatedOn();
		String deliveryDate = custDetails.getDelivery_date();
		String trnNumber = custDetails.getTrn_number();
		int orderNumber = orderHdr.getId();
		String userName = custDetails.getFirst_name() +" "+ custDetails.getLast_name();
		int invoiceId = orderHdr.getInvoiceId();
		String deliverySlot = custDetails.getDelivery_slots();
		
		String timeSlot = deliverySlot.split("-")[0].replaceAll(":", "").concat("00");
		int startingIndex = 0;
		int endingIndex = orderDetailsData.size() ;
		
		if(discountAmount > 0) {
			startingIndex += 1;
			endingIndex += 1;
		double sVatAmount = returnTwoDeciamlPlacesForDouble(discountAmount - discountAmount / 1.05d);
		double amountExclCat = discountAmount - sVatAmount;
//		double sUnitPrice = amountExclCat;
//		double sNetSales = amountExclCat;
//		double sGrossSales = discountAmount;
		double sUnitPrice =  (-1) * amountExclCat;
		double sNetSales =  (-1) * amountExclCat;
		double sGrossSales = (-1) * discountAmount;
		
		sVatAmount = (-1) * sVatAmount;
		
		sb.append("{").append("\"Item_Number\"").append(":").append("\"").append("NAR0165").append("\",")
		.append("\"Item_Description\"").append(":").append("\"").append("Sales Discount").append("\",")
		.append("\"Quantity\"").append(":").append("\"").append(1).append("\",")
		.append("\"UOM\"").append(":").append("\"").append("EA").append("\",")
		.append("\"Line_Number\"").append(":").append("\"").append(1).append("\",")
		.append("\"Unit_Price\"").append(":").append("\"").append(sUnitPrice).append("\",")
		.append("\"Net_Amount\"").append(":").append("\"").append(sNetSales).append("\",")
		.append("\"Tax_Amount\"").append(":").append("\"").append(sVatAmount).append("\",")
		.append("\"VAT_Percent\"").append(":").append("\"").append(5).append("\",")
		.append("\"Gross_Amount\"").append(":").append("\"").append(sGrossSales).append("\",")
		//.append("\"Shipping_Amount\"").append(":").append("\"").append(shippingAmount).append("\",")
		//.append("\"Processing_Fees\"").append(":").append("\"").append(processingFee).append("\",")
		.append("\"Order_Date\"").append(":").append("\"")
		.append(changeDateFormat(createdOn)).append("\",")
		.append("\"Request_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Requested_Time\"").append(":").append("\"").append(timeSlot).append("\",")
		.append("\"Invoice_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Invoice_Number\"").append(":").append("\"").append(invoiceId)
		.append("\",").append("\"Customer_Name\"").append(":").append("\"")
		.append(userName).append("\",").append("\"Customer_TRN\"").append(":")
		.append("\"").append(trnNumber).append("\",")
		.append("\"Customer_Order_reference_Number\"").append(":").append("\"")
		.append(orderNumber).append("\"").append("},");
		}
		
		
		if(shippingAmount > 0) {
			startingIndex += 1;
			endingIndex += 1;
		double sVatAmount = returnTwoDeciamlPlacesForDouble(shippingAmount - shippingAmount / 1.05d);
		double amountExclCat = shippingAmount - sVatAmount;
		double sUnitPrice = amountExclCat;
		double sNetSales = amountExclCat;
		double sGrossSales = shippingAmount;
		
		sb.append("{").append("\"Item_Number\"").append(":").append("\"").append("NAR0256").append("\",")
		.append("\"Item_Description\"").append(":").append("\"").append("SHIPPING CHARGES").append("\",")
		.append("\"Quantity\"").append(":").append("\"").append(1).append("\",")
		.append("\"UOM\"").append(":").append("\"").append("EA").append("\",")
		.append("\"Line_Number\"").append(":").append("\"").append(1).append("\",")
		.append("\"Unit_Price\"").append(":").append("\"").append(sUnitPrice).append("\",")
		.append("\"Net_Amount\"").append(":").append("\"").append(sNetSales).append("\",")
		.append("\"Tax_Amount\"").append(":").append("\"").append(sVatAmount).append("\",")
		.append("\"VAT_Percent\"").append(":").append("\"").append(5).append("\",")
		.append("\"Gross_Amount\"").append(":").append("\"").append(sGrossSales).append("\",")
		//.append("\"Shipping_Amount\"").append(":").append("\"").append(shippingAmount).append("\",")
		//.append("\"Processing_Fees\"").append(":").append("\"").append(processingFee).append("\",")
		.append("\"Order_Date\"").append(":").append("\"")
		.append(changeDateFormat(createdOn)).append("\",")
		.append("\"Request_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Requested_Time\"").append(":").append("\"").append(timeSlot).append("\",")
		.append("\"Invoice_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Invoice_Number\"").append(":").append("\"").append(invoiceId)
		.append("\",").append("\"Customer_Name\"").append(":").append("\"")
		.append(userName).append("\",").append("\"Customer_TRN\"").append(":")
		.append("\"").append(trnNumber).append("\",")
		.append("\"Customer_Order_reference_Number\"").append(":").append("\"")
		.append(orderNumber).append("\"").append("},");
		}
		
		if(processingFee > 0) {
			startingIndex+= 1;
			endingIndex += 1;
		double pVatAmount = returnTwoDeciamlPlacesForDouble(processingFee - processingFee / 1.05d);
		double amountExclVat = processingFee - pVatAmount;
		double pUnitPrice = amountExclVat;
		double pNetSales = amountExclVat;
		double pGrossSales = processingFee;
		
		sb.append("{").append("\"Item_Number\"").append(":").append("\"").append("NAR0259").append("\",")
		.append("\"Item_Description\"").append(":").append("\"").append("PROCESSING CHARGES").append("\",")
		.append("\"Quantity\"").append(":").append("\"").append(1).append("\",")
		.append("\"UOM\"").append(":").append("\"").append("EA").append("\",")
		.append("\"Line_Number\"").append(":").append("\"").append(2).append("\",")
		.append("\"Unit_Price\"").append(":").append("\"").append(pUnitPrice).append("\",")
		.append("\"Net_Amount\"").append(":").append("\"").append(pNetSales).append("\",")
		.append("\"Tax_Amount\"").append(":").append("\"").append(pVatAmount).append("\",")
		.append("\"VAT_Percent\"").append(":").append("\"").append(5).append("\",")
		.append("\"Gross_Amount\"").append(":").append("\"").append(pGrossSales).append("\",")
		//.append("\"Shipping_Amount\"").append(":").append("\"").append(shippingAmount).append("\",")
		//.append("\"Processing_Fees\"").append(":").append("\"").append(processingFee).append("\",")
		.append("\"Order_Date\"").append(":").append("\"")
		.append(changeDateFormat(createdOn)).append("\",")
		.append("\"Request_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Requested_Time\"").append(":").append("\"").append(timeSlot).append("\",")
		.append("\"Invoice_Date\"").append(":").append("\"")
		.append(changeDateFormat(deliveryDate)).append("\",")
		.append("\"Invoice_Number\"").append(":").append("\"").append(invoiceId)
		.append("\",").append("\"Customer_Name\"").append(":").append("\"")
		.append(userName).append("\",").append("\"Customer_TRN\"").append(":")
		.append("\"").append(trnNumber).append("\",")
		.append("\"Customer_Order_reference_Number\"").append(":").append("\"")
		.append(orderNumber).append("\"").append("},");
		}
	
		var orderDetailsIndex = 0;
		for (int i = startingIndex; i < endingIndex; i++) {
			double vatAmount = 0;
			double grossSales = 0;
			double netSales = 0;
			double unitPrice = 0;
			OrdersDetails d = ((OrdersDetails) (orderDetailsData.get(orderDetailsIndex)));
			grossSales = d.getSalesprice() * d.getQuanity();
			vatAmount = returnTwoDeciamlPlacesForDouble(grossSales - grossSales / 1.05d);
			netSales = grossSales - vatAmount;
			double unitVatAmount = returnTwoDeciamlPlacesForDouble(d.getSalesprice() - d.getSalesprice() / 1.05d);
			unitPrice = d.getSalesprice() - unitVatAmount;

			sb.append("{").append("\"Item_Number\"").append(":").append("\"").append(d.getP_code()).append("\",")
					.append("\"Item_Description\"").append(":").append("\"").append(d.getDescription()).append("\",")
					.append("\"Quantity\"").append(":").append("\"").append(d.getQuanity()).append("\",")
					.append("\"UOM\"").append(":").append("\"").append(d.getPricingUom()).append("\",")
					.append("\"Line_Number\"").append(":").append("\"").append(i + 1).append("\",")
					.append("\"Unit_Price\"").append(":").append("\"").append(unitPrice).append("\",")
					.append("\"Net_Amount\"").append(":").append("\"").append(netSales).append("\",")
					.append("\"Tax_Amount\"").append(":").append("\"").append(vatAmount).append("\",")
					.append("\"VAT_Percent\"").append(":").append("\"").append(5).append("\",")
					.append("\"Gross_Amount\"").append(":").append("\"").append(grossSales).append("\",")
					.append("\"Shipping_Amount\"").append(":").append("\"").append(shippingAmount).append("\",")
					.append("\"Processing_Fees\"").append(":").append("\"").append(processingFee).append("\",")
					.append("\"Order_Date\"").append(":").append("\"")
					.append(changeDateFormat(createdOn)).append("\",")
					.append("\"Request_Date\"").append(":").append("\"")
					.append(changeDateFormat(deliveryDate)).append("\",")
					.append("\"Requested_Time\"").append(":").append("\"").append(timeSlot).append("\",")
					.append("\"Invoice_Date\"").append(":").append("\"")
					.append(changeDateFormat(deliveryDate)).append("\",")
					.append("\"Invoice_Number\"").append(":").append("\"").append(invoiceId)
					.append("\",").append("\"Customer_Name\"").append(":").append("\"")
					.append(userName).append("\",").append("\"Customer_TRN\"").append(":")
					.append("\"").append(trnNumber).append("\",")
					.append("\"Customer_Order_reference_Number\"").append(":").append("\"")
					.append(orderNumber).append("\"").append("},");
			orderDetailsIndex++;
		}
	//	sb.append("{").append("\"Shipping_Amount\"").append(":").append("\"").append(shippingAmount).append("\",")
	//	.append("\"Processing_Fees\"").append(":").append("\"").append(processingFee).append("\"").append("},");

		sb.setLength(sb.length() - 1);
		sb.append("]").append("}");
		return sb.toString();
	}

	public int addERPRequest(String inputPayload) {
		try {
			List<Integer> id= jdbcTemplate.query("call p_add_erp_request(?)",
					(rs, rowNum)-> rs.getInt("x1"),
					new Object[] { inputPayload});
			return id.get(0);
		} catch (Exception e) {
			return 0;
		}
	}
	
	
	public boolean updateERPResponse(int id, String responsePayload, int orderNumber) {
			jdbcTemplate.update("call p_update_erp_response(?,?)",
					new Object[] { id, responsePayload});
			jdbcTemplate.update("call p_update_erp_status_for_ordernumber(?,?)",
					new Object[] { orderNumber, responsePayload});
		return true;
	}
}
