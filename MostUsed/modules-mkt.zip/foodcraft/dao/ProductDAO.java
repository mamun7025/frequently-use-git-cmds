package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.*;
import com.ekfc.foodcraft.utils.ProductUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Component
public class ProductDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Product> getProducts(){
        return jdbcTemplate.query(
                "call p_get_all_products()",
                (rs, rowNum) -> new Product(
                        rs.getLong("id"),
                        rs.getString("code"),
                        rs.getString("type"),
                        rs.getString("name"),
                        rs.getString("image1"),
                        rs.getString("image1_hdr"),
                        rs.getString("image2"),
                        rs.getString("image2_hdr"),
                        rs.getString("image3"),
                        rs.getString("image3_hdr"),
                        rs.getString("image4"),
                        rs.getString("image4_hdr"),
                        rs.getString("primary_image"),
                        rs.getString("primary_image_hdr"),
                        rs.getString("uom"),
                        rs.getDouble("base_price"),
                        rs.getDouble("sales_price"),
                        rs.getString("tag"),
                        rs.getString("categories"),
                        rs.getString("categories_list"),
                        rs.getString("stock"),
                        rs.getString("in_stock"),
                        rs.getString("tax_status"),
                        rs.getBoolean("is_featured"),
                        rs.getBoolean("is_live"),
                        rs.getBoolean("is_visible"),
                        rs.getBoolean("is_published"),
                        rs.getString("upsells"),
                        rs.getString("cross_sells"),
                        rs.getString("grouped_products"),
                        rs.getString("attribute_1_name"),
                        rs.getString("additioninfo"),
                        rs.getString("btmdesc"),
                        rs.getString("maindesc"),
                        rs.getString("length_cm"),
                        rs.getString("width_cm"),
                        rs.getString("height_cm"),
                        rs.getString("weight_kg"),
                        rs.getString("position"),
                        rs.getString("shipping_class"),
                        rs.getString("rating"),
                        rs.getString("popularity"),
                        rs.getString("path"),rs.getString("nutri_facts"),
                        rs.getInt("min_order_qty"),
                        rs.getInt("max_order_qty"),
                        rs.getInt("min_order_value"),
                        rs.getInt("max_order_value"),
                        rs.getString("dynamic_attributes"),
                        rs.getString("order_json")
                ),
                new Object[] {}
        );
    }

    public List<Product> getAllProductsForCategory(String categoryId) {
        List<Product> initialProducts =  jdbcTemplate.query(
                "call p_cms_get_all_products(?)",
                (rs, rowNum) -> new Product(
                        rs.getLong("id"),
                        rs.getString("code"),
                        rs.getString("type"),
                        rs.getString("name"),
                        rs.getString("image1"),
                        rs.getString("image1_hdr"),
                        rs.getString("image2"),
                        rs.getString("image2_hdr"),
                        rs.getString("image3"),
                        rs.getString("image3_hdr"),
                        rs.getString("image4"),
                        rs.getString("image4_hdr"),
                        rs.getString("primary_image"),
                        rs.getString("primary_image_hdr"),
                        rs.getString("uom"),
                        rs.getDouble("base_price"),
                        rs.getDouble("sales_price"),
                        rs.getString("tag"),
                        rs.getString("categories"),
                        rs.getString("categories_list"),
                        rs.getString("stock"),
                        rs.getString("in_stock"),
                        rs.getString("tax_status"),
                        rs.getBoolean("is_featured"),
                        rs.getBoolean("is_live"),
                        rs.getBoolean("is_visible"),
                        rs.getBoolean("is_published"),
                        rs.getString("upsells"),
                        rs.getString("cross_sells"),
                        rs.getString("grouped_products"),
                        rs.getString("attribute_1_name"),
                        rs.getString("additioninfo"),
                        rs.getString("btmdesc"),
                        rs.getString("maindesc"),
                        rs.getString("length_cm"),
                        rs.getString("width_cm"),
                        rs.getString("height_cm"),
                        rs.getString("weight_kg"),
                        rs.getString("position"),
                        rs.getString("shipping_class"),
                        rs.getString("rating"),
                        rs.getString("popularity"),
                        rs.getString("path"),rs.getString("nutri_facts"),
                        rs.getInt("min_order_qty"),
                        rs.getInt("max_order_qty"),
                        rs.getInt("min_order_value"),
                        rs.getInt("max_order_value"),
                        rs.getString("dynamic_attributes"),
                        rs.getString("order_json")
                ),
                new Object[] {categoryId}
        );
        final List<Product> finalProducts = new ArrayList<>();
        if(!CollectionUtils.isEmpty(initialProducts)){
            for(Product p: initialProducts){
                final String category = p.getCategories();
                final String modifiedCategory = category;
                final String[] categorySplit = modifiedCategory.split(" > ");
                if(Arrays.asList(categorySplit).indexOf(categoryId) > -1){
                    finalProducts.add(p);
                }
            }
        }
        return finalProducts;
    }


    public List<Product> getAllEnabledProductsForCategory(String categoryId) {
        List<Product> initialProducts =  jdbcTemplate.query(
                "call p_cms_get_all_enabled_products(?)",
                (rs, rowNum) -> new Product(
                        rs.getLong("id"),
                        rs.getString("code"),
                        rs.getString("type"),
                        rs.getString("name"),
                        rs.getString("image1"),
                        rs.getString("image1_hdr"),
                        rs.getString("image2"),
                        rs.getString("image2_hdr"),
                        rs.getString("image3"),
                        rs.getString("image3_hdr"),
                        rs.getString("image4"),
                        rs.getString("image4_hdr"),
                        rs.getString("primary_image"),
                        rs.getString("primary_image_hdr"),
                        rs.getString("uom"),
                        rs.getDouble("base_price"),
                        rs.getDouble("sales_price"),
                        rs.getString("tag"),
                        rs.getString("categories"),
                        rs.getString("categories_list"),
                        rs.getString("stock"),
                        rs.getString("in_stock"),
                        rs.getString("tax_status"),
                        rs.getBoolean("is_featured"),
                        rs.getBoolean("is_live"),
                        rs.getBoolean("is_visible"),
                        rs.getBoolean("is_published"),
                        rs.getString("upsells"),
                        rs.getString("cross_sells"),
                        rs.getString("grouped_products"),
                        rs.getString("attribute_1_name"),
                        rs.getString("additioninfo"),
                        rs.getString("btmdesc"),
                        rs.getString("maindesc"),
                        rs.getString("length_cm"),
                        rs.getString("width_cm"),
                        rs.getString("height_cm"),
                        rs.getString("weight_kg"),
                        rs.getString("position"),
                        rs.getString("shipping_class"),
                        rs.getString("rating"),
                        rs.getString("popularity"),
                        rs.getString("path"),rs.getString("nutri_facts"),
                        rs.getInt("min_order_qty"),
                        rs.getInt("max_order_qty"),
                        rs.getInt("min_order_value"),
                        rs.getInt("max_order_value"),
                        rs.getString("dynamic_attributes"),
                        rs.getString("order_json")
                ),
                new Object[] {categoryId}
        );
        final List<Product> finalProducts = new ArrayList<>();
        if(!CollectionUtils.isEmpty(initialProducts)){
            for(Product p: initialProducts){
                final String category = p.getCategories();
                final String modifiedCategory = category;
                final String[] categorySplit = modifiedCategory.split(" > ");
                if(Arrays.asList(categorySplit).indexOf(categoryId) > -1){
                    finalProducts.add(p);
                }
            }
        }
        return finalProducts;
    }

    public Product getProductForCode(String productCode) {
        List<Product> initialProducts =  jdbcTemplate.query(
                "call p_cms_get_product_for_code(?)",
                (rs, rowNum) -> new Product(
                        rs.getLong("id"),
                        rs.getString("code"),
                        rs.getString("type"),
                        rs.getString("name"),
                        rs.getString("image1"),
                        rs.getString("image1_hdr"),
                        rs.getString("image2"),
                        rs.getString("image2_hdr"),
                        rs.getString("image3"),
                        rs.getString("image3_hdr"),
                        rs.getString("image4"),
                        rs.getString("image4_hdr"),
                        rs.getString("primary_image"),
                        rs.getString("primary_image_hdr"),
                        rs.getString("uom"),
                        rs.getDouble("base_price"),
                        rs.getDouble("sales_price"),
                        rs.getString("tag"),
                        rs.getString("categories"),
                        rs.getString("categories_list"),
                        rs.getString("stock"),
                        rs.getString("in_stock"),
                        rs.getString("tax_status"),
                        rs.getBoolean("is_featured"),
                        rs.getBoolean("is_live"),
                        rs.getBoolean("is_visible"),
                        rs.getBoolean("is_published"),
                        rs.getString("upsells"),
                        rs.getString("cross_sells"),
                        rs.getString("grouped_products"),
                        rs.getString("attribute_1_name"),
                        rs.getString("additioninfo"),
                        rs.getString("btmdesc"),
                        rs.getString("maindesc"),
                        rs.getString("length_cm"),
                        rs.getString("width_cm"),
                        rs.getString("height_cm"),
                        rs.getString("weight_kg"),
                        rs.getString("position"),
                        rs.getString("shipping_class"),
                        rs.getString("rating"),
                        rs.getString("popularity"),
                        rs.getString("path"),rs.getString("nutri_facts"),
                        rs.getInt("min_order_qty"),
                        rs.getInt("max_order_qty"),
                        rs.getInt("min_order_value"),
                        rs.getInt("max_order_value"),
                        rs.getString("dynamic_attributes"),
                        rs.getString("order_json")
                ),
                new Object[] {productCode}
        );

        if(!CollectionUtils.isEmpty(initialProducts)){
            return initialProducts.get(0);
        }
        return null;
    }

    public boolean updateProductForCode(UpdateProduct updateProductReq, String nutrifacts) {
        try{
            jdbcTemplate.update(
                    "call p_cms_update_product(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    new Object[] {
                            updateProductReq.getCode(),
                            updateProductReq.getName(),
                            updateProductReq.getType(),
                            updateProductReq.getUom(),
                            updateProductReq.getSellingPrice(),
                            updateProductReq.getBasePrice(),
                            updateProductReq.getCrossSells(),
                            updateProductReq.getUpSells(),
                            updateProductReq.isLive(),
                            updateProductReq.getBtmdesc(),
                            updateProductReq.getMaindesc(),
                            updateProductReq.getAdditioninfo(),
                            updateProductReq.getUser(),
                            updateProductReq.getMinOrderedQty(),
                            updateProductReq.getMaxOrderedQty(),
                            updateProductReq.getMinOrderedValue(),
                            updateProductReq.getMaxOrderedValue(),
                            updateProductReq.getDynamicAttributes(),
                            nutrifacts,
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean udpateProductMediaForCode(UpdateProductMedia updateProductReq, String imagePath) {
        try{
            jdbcTemplate.update(
                    "call p_cms_update_products_media(?,?)",
                    new Object[] {
                            updateProductReq.getCode(),
                            imagePath
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public String getProductMediaForCode(String code) {
        try{
            List<String> result = jdbcTemplate.query(
                    "call p_cms_get_product_images(?)",
                    (rs, rowNum) -> new String(rs.getString("x1")),
                    new Object[] {
                            code
                    }
            );
            return result.get(0);
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return "";
    }
    
    public boolean udpateProductMediaForCode(String code, String imagePath) {
        try{
            jdbcTemplate.update(
                    "call p_cms_update_product_images(?,?)",
                    new Object[] {
                    		code,
                            imagePath
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean addProductCategory(ProductCategoryUpdate categoryUpdate) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_category_to_product(?,?,?)",
                    new Object[]{categoryUpdate.getCategoryId(), categoryUpdate.getProductCode(), categoryUpdate.getCategoryList()}
            );
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeProductFromCategory(ProductCategoryUpdate categoryUpdate) {
        try{
            jdbcTemplate.update(
                    "call p_cms_remove_category_from_product(?,?,?)",
                    new Object[]{categoryUpdate.getCategoryId(), categoryUpdate.getProductCode(), categoryUpdate.getCategoryList()}
            );
            return true;
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean createProduct(CreateProduct updateProductReq, String nutriFacts) {

        try{
            jdbcTemplate.update(
                    "call p_cms_create_product(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    new Object[] {
                            updateProductReq.getCode(),
                            updateProductReq.getName(),
                            updateProductReq.getType(),
                            updateProductReq.getUom(),
                            updateProductReq.getSellingPrice(),
                            updateProductReq.getBasePrice(),
                            updateProductReq.getCrossSells(),
                            updateProductReq.getUpSells(),
                            updateProductReq.isLive(),
                            updateProductReq.getBtmdesc(),
                            updateProductReq.getMaindesc(),
                            updateProductReq.getAdditioninfo(),
                            updateProductReq.getUser(),
                            updateProductReq.getCategories(),
                            updateProductReq.getCategoriesList(),
                            updateProductReq.getMinOrderedQty(),
                            updateProductReq.getMaxOrderedQty(),
                            updateProductReq.getMinOrderedValue(),
                            updateProductReq.getMaxOrderedValue(),
                            updateProductReq.getDynamicAttributes(),
                            nutriFacts
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateOrderJson(String productCode, String orderJson) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_product_order_numbering(?,?)",
                    new Object[]{productCode, orderJson}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean deleteProduct(String productCode) {
    	try {
    		jdbcTemplate.update("call p_cms_delete_product(?)",
    		new Object[]{productCode}
    		);
    		return true;
    	}
    	catch(Exception ex) {
    		ex.printStackTrace();
    	}
    	return false;
    }


    public List<Product> getAllProductData() {
        List<Product> dataList = new ArrayList<>();
        // prepare pl/sql params
        List<Object> searchParams = new ArrayList<>();
        Object[] plSqlParams = searchParams.toArray(new Object[0]);
        jdbcTemplate.query("call p_get_all_products()", new RowCallbackHandler() {
            public void processRow(@NotNull ResultSet rs) throws SQLException {
                boolean processNext = true;
                while (processNext) {
                    // process it
                    Product product = new Product();
                    product.setId(rs.getLong("id") );
                    product.setCode(rs.getString("code") );
                    product.setName(rs.getString("name") );
                    product.setType(rs.getString("type") );
                    product.setUom(rs.getString("uom") );
                    product.setBasePrice(rs.getDouble("base_price") );
                    product.setSalesPrice(rs.getDouble("sales_price") );
                    product.setCategories(rs.getString("categories") );
                    product.setCategoriesList(rs.getString("categories_list") );
                    product.setLive(rs.getBoolean("is_live") );
                    product.setPublished(rs.getBoolean("is_published") );
                    product.setPath(rs.getString("path") );
                    // push in list
                    dataList.add(product);
                    processNext = rs.next();
                }
            }
        }, plSqlParams);

        return dataList;
    }

}
