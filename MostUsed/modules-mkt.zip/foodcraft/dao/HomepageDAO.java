package com.ekfc.foodcraft.dao;

import com.ekfc.foodcraft.model.homepage.CarouselModel;
import com.ekfc.foodcraft.model.homepage.CustFavoriteModel;
import com.ekfc.foodcraft.model.homepage.ExploreModel;
import com.ekfc.foodcraft.model.homepage.OurMenuModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.Map;

@Component
public class HomepageDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<CarouselModel> getHomepageCarouselComponents() {
        final List<CarouselModel> carouselList = jdbcTemplate.query(
                "call p_cms_homepage_carousel_components()",
                (rs, rowNum) -> new CarouselModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getString("x6"),
                        rs.getString("x7"),
                        rs.getBoolean("x8"),
                        rs.getInt("x9")
                ),
                new Object[]{}
        );
        return carouselList;
    }

    public boolean addCarouselBanner(CarouselModel requestObj) {
        final String title = requestObj.getTitleM();
        final String actionName = requestObj.getActionName();
        final String actionUrl = requestObj.getHref();
        final String content = requestObj.getTitleD();
        final String imageUrlDesktop = requestObj.getImgPathDesktop();
        final String imageUrlMobile = requestObj.getImgPathMobile();
        final boolean active = requestObj.isActive();

        try{
            jdbcTemplate.update(
                    "call p_cms_add_homepage_carousel_components(?,?,?,?,?,?,?)",
                    new Object[] {
                            title,
                            actionName,
                            actionUrl,
                            content,
                            imageUrlDesktop,
                            imageUrlMobile,
                            active
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeCarouselBanner(int id) {

        try{
            jdbcTemplate.update(
                    "call p_cms_remove_homepage_carousel_components(?)",
                    new Object[] {
                            id
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateCarouselBanner(CarouselModel requestObj) {
        final String title = requestObj.getTitleM();
        final String actionName = requestObj.getActionName();
        final String actionUrl = requestObj.getHref();
        final String content = requestObj.getTitleD();
        final String imageUrlDesktop = requestObj.getImgPathDesktop();
        final String imageUrlMobile = requestObj.getImgPathMobile();
        final boolean active = requestObj.isActive();
        final long id = requestObj.getId();

        try {
            jdbcTemplate.update(
                    "call p_cms_update_homepage_carousel_components(?,?,?,?,?,?,?,?)",
                    new Object[]{
                            title,
                            actionName,
                            actionUrl,
                            content,
                            imageUrlDesktop,
                            imageUrlMobile,
                            id,
                            active
                    }
            );
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public List<CarouselModel> getActiveHomepageCarouselComponents() {
        final List<CarouselModel> carouselList = jdbcTemplate.query(
                "call p_cms_active_homepage_carousel_components()",
                (rs, rowNum) -> new CarouselModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getString("x6"),
                        rs.getString("x7"),
                        rs.getBoolean("x8"),
                        rs.getInt("x9")
                ),
                new Object[]{}
        );
        return carouselList;
    }

    public List<ExploreModel> getExploreOurMenuComponents() {
        final List<ExploreModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_all_explore_our_menu_options()",
                (rs, rowNum) -> new ExploreModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public List<ExploreModel> getActiveExploreOurMenuComponents() {
        final List<ExploreModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_active_explore_our_menu_options()",
                (rs, rowNum) -> new ExploreModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public boolean addExploreMenu(ExploreModel requestObj) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_explore_our_menu_options(?,?,?,?)",
                    new Object[] {
                        requestObj.getTitle(),
                        requestObj.getDataMenuCat(),
                        requestObj.getImgPath(),
                        requestObj.isActive()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateExploreMenu(ExploreModel requestObj) {
        final String title = requestObj.getTitle();
        final String dataMenuCat = requestObj.getDataMenuCat();
        final String imgPath = requestObj.getImgPath();
        final boolean active = requestObj.isActive();
        final long id = requestObj.getId();

        try {
            jdbcTemplate.update(
                    "call p_cms_update_homepage_explore_components(?,?,?,?,?)",
                    new Object[]{
                            id,
                            title,
                            dataMenuCat,
                            imgPath,
                            active
                    }
            );
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeExploreMenu(int id) {

        try{
            jdbcTemplate.update(
                    "call p_cms_remove_homepage_explore_components(?)",
                    new Object[] {
                            id
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public List<CustFavoriteModel> getAllCustomerFavorites() {
        return jdbcTemplate.query(
                "call p_cms_get_all_home_customer_favorites()",
                (rs, rowNum) -> new CustFavoriteModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getBoolean("x6")
                ),
                new Object[] {}
        );
    }
    
    public List<CustFavoriteModel> getCustomerFavoritesbyId(Map<String, Object>reqMap) {
        return jdbcTemplate.query(
                "call p_cms_get_home_customer_favorites_by_id(?)",
                (rs, rowNum) -> new CustFavoriteModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getBoolean("x6")
                ),
                new Object[] {reqMap.get("id")}
        );
    }
    
    
    public boolean delCustomerFavoritesbyId(Map<String, Object> reqMap) {

        try{
            jdbcTemplate.update(
                    "call p_cms_del_home_customer_favorites_by_id(?)",
                    new Object[] {
                    		reqMap.get("id")
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean addCustomerFavorites(CustFavoriteModel customerFavModel) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_home_customer_favorites(?,?,?,?,?)",
                    new Object[] {
                            customerFavModel.getName(),
                            customerFavModel.getContent(),
                            customerFavModel.getProducts(),
                            customerFavModel.getTemplate(),
                            customerFavModel.isActive()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateCustomerFavorites(CustFavoriteModel customerFavModel) {
        try{
            jdbcTemplate.update(
                    "call p_cms_update_home_customer_favorites(?,?,?,?,?,?)",
                    new Object[] {
                            customerFavModel.getId(),
                            customerFavModel.getName(),
                            customerFavModel.getContent(),
                            customerFavModel.getProducts(),
                            customerFavModel.getTemplate(),
                            customerFavModel.isActive()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public List<CustFavoriteModel> getAllActiveCustomerFavorites() {
        return jdbcTemplate.query(
                "call p_cms_get_all_active_home_customer_favorites()",
                (rs, rowNum) -> new CustFavoriteModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getBoolean("x6")
                ),
                new Object[] {}
        );
    }

    public Integer getVersionNumber(){
        List<Integer> ids = jdbcTemplate.query(
                "call p_cms_get_version_number()",
                (rs, rowNum) -> rs.getInt("x1"),
                new Object[] {}
        );

        if(!CollectionUtils.isEmpty(ids)){
            return ids.get(0);
        }
        return null;
    }

    public Integer setVersionNumber(int prevVersion){
        try {
            List<Integer> ids = jdbcTemplate.query(
                    "call p_cms_add_version_number(?)",
                    (rs, rowNum) -> rs.getInt("x1"),
                    new Object[]{prevVersion});
            if(!CollectionUtils.isEmpty(ids)){
                return ids.get(0);
            }
        }catch (Exception ex){
            ex.printStackTrace();
        }
        return null;
    }
    
    public boolean updateOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_explore_our_range_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean updateCarouselOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_carousel_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    

    public List<ExploreModel> getCraftPerfectMealsComponents() {
        final List<ExploreModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_all_craft_perfect_meals_options()",
                (rs, rowNum) -> new ExploreModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public List<ExploreModel> getActiveCraftPerfectMealsComponents() {
        final List<ExploreModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_active_craft_perfect_meals_options()",
                (rs, rowNum) -> new ExploreModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getBoolean("x5"),
                        rs.getInt("x6")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public boolean addCraftPerfectMeals(ExploreModel requestObj) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_craft_perfect_meals_options(?,?,?,?)",
                    new Object[] {
                        requestObj.getTitle(),
                        requestObj.getDataMenuCat(),
                        requestObj.getImgPath(),
                        requestObj.isActive()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateCraftPerfectMeals(ExploreModel requestObj) {
        final String title = requestObj.getTitle();
        final String dataMenuCat = requestObj.getDataMenuCat();
        final String imgPath = requestObj.getImgPath();
        final boolean active = requestObj.isActive();
        final long id = requestObj.getId();

        try {
            jdbcTemplate.update(
                    "call p_cms_update_craft_perfect_meals_components(?,?,?,?,?)",
                    new Object[]{
                            id,
                            title,
                            dataMenuCat,
                            imgPath,
                            active
                    }
            );
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeCraftPerfectMeals(int id) {

        try{
            jdbcTemplate.update(
                    "call p_cms_remove_craft_perfect_meals_components(?)",
                    new Object[] {
                            id
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean updateCraftPerfectMealsOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_craft_perfect_meals_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    
    public List<OurMenuModel> getOurMenuComponents() {
        final List<OurMenuModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_all_our_menu_options()",
                (rs, rowNum) -> new OurMenuModel(
                        rs.getLong("x1"),
                        rs.getString("x2"),
                        rs.getString("x3"),
                        rs.getString("x4"),
                        rs.getString("x5"),
                        rs.getString("x6"),
                        rs.getString("x7"),
                        rs.getBoolean("x8"),
                        rs.getInt("x9")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public List<OurMenuModel> getActiveOurMenuComponents() {
        final List<OurMenuModel> exploreModels = jdbcTemplate.query(
                "call p_cms_get_active_our_menu_options()",
                (rs, rowNum) -> new OurMenuModel(
                		 rs.getLong("x1"),
                         rs.getString("x2"),
                         rs.getString("x3"),
                         rs.getString("x4"),
                         rs.getString("x5"),
                         rs.getString("x6"),
                         rs.getString("x7"),
                         rs.getBoolean("x8"),
                         rs.getInt("x9")
                ),
                new Object[] {}
        );

        return exploreModels;
    }

    public boolean addOurMenuComponents(OurMenuModel requestObj) {
        try{
            jdbcTemplate.update(
                    "call p_cms_add_our_menu_options(?,?,?,?,?,?,?)",
                    new Object[] {
                        requestObj.getTitle(),
                        requestObj.getActionName(),
                        requestObj.getActionUrl(),
                        requestObj.getContents(),
                        requestObj.getProducts(),
                        requestObj.getImgPath(),
                        requestObj.isActive()
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }

    public boolean updateOurMenuComponents(OurMenuModel requestObj) {
        final String title = requestObj.getTitle();
        final String actionUrl = requestObj.getActionUrl();
        final String actionName = requestObj.getActionName();
        final String contents = requestObj.getContents();
        final String products = requestObj.getProducts();
        final String imgPath = requestObj.getImgPath();
        final boolean active = requestObj.isActive();
        final long id = requestObj.getId();

        try {
            jdbcTemplate.update(
                    "call p_cms_update_our_menu_components(?,?,?,?,?,?,?,?)",
                    new Object[]{
                            id,
                            title,
                            actionName,
                            actionUrl,
                            contents,
                            products,
                            imgPath,
                            active
                    }
            );
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public boolean removeOurMenuComponents(int id) {

        try{
            jdbcTemplate.update(
                    "call p_cms_remove_our_menu_components(?)",
                    new Object[] {
                            id
                    }
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
    
    public boolean updateOurMenuComponentsOrder(String categoryCode, int order) {
        try {
            jdbcTemplate.update(
                    "call p_cms_update_our_menu_order_numbering(?,?)",
                    new Object[]{categoryCode, order}
            );
            return true;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return false;
    }
}
