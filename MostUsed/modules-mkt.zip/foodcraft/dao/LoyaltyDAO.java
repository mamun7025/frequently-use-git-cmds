package com.ekfc.foodcraft.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.ekfc.foodcraft.model.LoyaltyEarnBurnModel;
import com.ekfc.foodcraft.model.LoyaltyUser;


@Component
public class LoyaltyDAO {
	
	@Autowired
	JdbcTemplate jdbcTemplate;

	public List<LoyaltyEarnBurnModel> getLoyaltyData() {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("call p_get_loyalty_data", 
				(rs,rowNum)-> new LoyaltyEarnBurnModel(rs.getInt("id"),rs.getString("loyalty_types"),rs.getInt("points"),rs.getDouble("price"),rs.getBoolean("active")));
	}
	public LoyaltyEarnBurnModel getLoyaltyData(String type) {
		// TODO Auto-generated method stub
		var list = jdbcTemplate.query("call p_get_loyalty_data", 
				(rs,rowNum)-> new LoyaltyEarnBurnModel(rs.getInt("id"),rs.getString("loyalty_types"),rs.getInt("points"),rs.getDouble("price"),rs.getBoolean("active")));
		for(var model : list) {
			if(model.getType().equals(type)) return model;
		}
		return null;
				
	}

	public List<LoyaltyUser> getUserLoyaltyPoints(String userId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query("call p_get_user_loyalty_points(?)", 
				(rs,rowNum)-> new LoyaltyUser(rs.getInt("id"),rs.getString("user_id"),rs.getInt("loyalty_points")),new Object[] {userId});
	
	}

}
